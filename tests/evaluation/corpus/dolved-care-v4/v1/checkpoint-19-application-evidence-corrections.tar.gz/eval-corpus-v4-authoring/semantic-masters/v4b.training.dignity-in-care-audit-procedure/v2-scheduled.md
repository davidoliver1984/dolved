<!-- v4-authoring-draft family=v4b.training.dignity-in-care-audit-procedure version=v2-scheduled -->
# Dignity in Care Audit Procedure

*SCHEDULED successor to the version effective 1 May 2025. Not yet effective; becomes authoritative on 1 November 2026, increasing audit frequency to monthly.*

## Audit frequency

A dignity in care audit will be carried out monthly (increased from quarterly) at each site using the standard observation checklist, from 1 November 2026.


<!-- freeze-correction-realism-start -->
## Audit preparation

The auditor samples different times, locations and care interactions and checks prior actions before observation begins. Residents are told the purpose in an accessible way and may decline involvement. The audit tool covers privacy, choice, communication, personal presentation, mealtime support, confidential records and the physical environment rather than relying on a single general impression.

## Evidence and escalation

Findings cite the observed or recorded evidence and distinguish an isolated lapse from a repeated or systemic concern. Immediate risk, degrading treatment or possible abuse is escalated at once through safeguarding and management routes; it is not left as a routine audit action. Positive practice is recorded specifically enough to be repeated elsewhere.

## Action and follow-up

Each shortfall receives an accountable owner, due date and completion evidence. The registered manager reviews the action plan with residents or representatives where appropriate. Follow-up tests whether practice changed in reality, and overdue or ineffective actions are escalated to the Quality Lead. Audit tools, evidence, responses and closure decisions form one retained record.

<!-- freeze-correction-realism-end -->

---
Alderbridge Care Group | Uncontrolled if printed | Confidential — internal use only
