<!-- v4-authoring-draft family=v4b.payroll.expenses-mileage-rate-schedule version=v2-scheduled -->
# Mileage Rate Schedule

*SCHEDULED successor to the version effective 1 April 2025. This version does not become effective, and is not yet authoritative, until 1 October 2026.*

| Vehicle type | Rate (first 10,000 miles), effective 1 October 2026 |
|---|---|
| Car | 48p per mile |
| Motorcycle | 26p per mile |
| Bicycle | 20p per mile |

---
Alderbridge Care Group | Uncontrolled if printed | Confidential — internal use only
