<!-- v4-authoring-draft family=v4b.hr.key-performance-indicator-reporting-policy version=v2-scheduled -->
# Key Performance Indicator Reporting Policy

*SCHEDULED successor to the version effective 1 April 2025. Not yet effective; becomes authoritative on 1 September 2026.*

| KPI | Target (from 1 September 2026) | Reported |
|---|---|---|
| Staff turnover | < 20% annualised | Monthly |
| Training compliance | > 97% | Monthly |
| Complaints per 100 beds | < 2 per quarter | Quarterly |
| New: agency usage | < 10% of total hours | Monthly |


<!-- freeze-correction-realism-start -->
## Indicator ownership

Each approved indicator has a definition, source system, reporting frequency, accountable owner and named reviewer. The definition states inclusions, exclusions, numerator, denominator and treatment of missing data so sites cannot improve a result by changing interpretation. A proposed indicator or target has no reporting authority until the scheduled successor version becomes effective.

## Validation and submission

Owners reconcile source totals, investigate material variance and record corrections before submission. Estimates are visibly labelled and replaced when verified data becomes available. Local commentary explains unusual movement without suppressing an adverse result, and access to resident or workforce detail remains limited to people who need it.

## Review and action

The governance meeting considers trend, comparison, data quality and whether existing actions are effective. A threshold breach receives an owner and due date rather than being explained away in narrative. Reports, validation evidence, corrections and meeting decisions are retained together, allowing the published position to be reproduced from its source data.

<!-- freeze-correction-realism-end -->

---
Alderbridge Care Group | Uncontrolled if printed | Confidential — internal use only
