"""V4-B batch 15: three more two-version families (6 docs), closing the gap to
exactly 60 two-version families (120 docs) for V4-B."""

DOCS = [
{
    "family_id": "v4b.hr.staff-benefits-guidance", "family_title": "Staff Benefits Guidance",
    "version_id": "v1", "version_change_type": "changed_effective_date_and_numeric_limit",
    "domain": "hr", "content_type": "faq_guidance",
    "human_title": "Staff Benefits Guidance", "filename": "staff-benefits-guidance-v1.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-04-01", "superseded_date": "2026-04-01",
    "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Discount scheme", "Staff can access a retail discount scheme offering typically 5-10% off at participating retailers."),
    ],
},
{
    "family_id": "v4b.hr.staff-benefits-guidance", "family_title": "Staff Benefits Guidance",
    "version_id": "v2", "version_change_type": "changed_effective_date_and_numeric_limit",
    "domain": "hr", "content_type": "faq_guidance",
    "human_title": "Staff Benefits Guidance", "filename": "staff-benefits-guidance-v2.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2026-04-01", "messiness_level": "clean", "messiness_axes": [],
    "front_matter": "Supersedes the version effective 1 April 2025. New provider, wider discount range.",
    "sections": [
        ("Discount scheme", "Staff can access a retail discount scheme offering typically 5-15% off at a wider range of participating retailers, following a change of scheme provider."),
    ],
},
{
    "family_id": "v4b.facilities.key-cutting-and-access-card-procedure", "family_title": "Key Cutting and Access Card Procedure",
    "version_id": "v1", "version_change_type": "added_removed_clause",
    "domain": "facilities-fleet", "content_type": "policy",
    "human_title": "Key Cutting and Access Card Procedure", "filename": "key-cutting-access-card-v1.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-03-01", "superseded_date": "2026-03-01",
    "messiness_level": "mild", "messiness_axes": ["buried_exception"],
    "sections": [
        ("Issuing keys", "Site keys are issued only to permanent staff after 4 weeks' service, logged in the key register."),
    ],
},
{
    "family_id": "v4b.facilities.key-cutting-and-access-card-procedure", "family_title": "Key Cutting and Access Card Procedure",
    "version_id": "v2", "version_change_type": "added_removed_clause",
    "domain": "facilities-fleet", "content_type": "policy",
    "human_title": "Key Cutting and Access Card Procedure", "filename": "key-cutting-access-card-v2.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2026-03-01", "messiness_level": "mild", "messiness_axes": ["buried_exception"],
    "front_matter": "Supersedes the version effective 1 March 2025. Adds a new access-card return clause on leaving; removes the prior 4-week waiting period.",
    "sections": [
        ("Issuing keys", "Site keys or access cards are issued to permanent staff from their first day (the previous 4-week waiting period has been removed), logged in the key register."),
        ("New: leaver return", "All keys and access cards must be returned to the registered manager on an employee's last working day, before their final pay is released."),
    ],
},
{
    "family_id": "v4b.training.safeguarding-champion-role-guidance", "family_title": "Safeguarding Champion Role Guidance",
    "version_id": "v1", "version_change_type": "renamed_heading",
    "domain": "safeguarding", "content_type": "faq_guidance",
    "human_title": "Safeguarding Champion Role Guidance", "filename": "safeguarding-champion-role-v1.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-06-01", "superseded_date": "2026-06-01",
    "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Who is the champion", "Each site nominates a safeguarding lead who acts as the first point of contact for safeguarding questions."),
    ],
},
{
    "family_id": "v4b.training.safeguarding-champion-role-guidance", "family_title": "Safeguarding Champion Role Guidance",
    "version_id": "v2", "version_change_type": "renamed_heading",
    "domain": "safeguarding", "content_type": "faq_guidance",
    "human_title": "Safeguarding Champion Role Guidance", "filename": "safeguarding-champion-role-v2.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2026-06-01", "messiness_level": "clean", "messiness_axes": [],
    "front_matter": "Supersedes the version effective 1 June 2025. 'Safeguarding lead' renamed to 'Safeguarding champion' throughout — the role and its responsibilities are unchanged.",
    "sections": [
        ("Who is the champion", "Each site nominates a safeguarding champion who acts as the first point of contact for safeguarding questions."),
    ],
},
]
