"""Build the bounded negative/import-fixture pack. Excluded from the primary 300 count."""
import hashlib
import json
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import render  # noqa: E402
import pikepdf

ROOT = render.ROOT
NEG = ROOT / "negative-fixtures"
NEG.mkdir(exist_ok=True)

entries = []


def record(filename, category, expected_behaviour, notes, path=None):
    p = path or (NEG / filename)
    sha = hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
    entries.append({
        "filename": filename,
        "category": category,
        "expected_import_behaviour": expected_behaviour,
        "notes": notes,
        "byte_count": p.stat().st_size if p.exists() else None,
        "sha256": sha,
    })


# 1. Corrupt PDF — a real, valid PDF with its trailer/xref truncated away.
good_pdf_bytes = (ROOT / "artifacts" / "pdf" / "annual-leave-policy-v1.pdf").read_bytes()
corrupt = good_pdf_bytes[: len(good_pdf_bytes) // 2]
(NEG / "corrupt-fire-safety-policy.pdf").write_bytes(corrupt)
record("corrupt-fire-safety-policy.pdf", "corrupt_pdf",
       "extraction fails with a typed corruption failure_category",
       "Truncated at 50% of a real PDF's byte length; not a valid PDF structure.")

# 2. Password-protected PDF — genuinely encrypted with pikepdf.
src_pdf = ROOT / "artifacts" / "pdf" / "controlled-drugs-procedure.pdf"
pdf = pikepdf.open(src_pdf)
pdf.save(NEG / "password-protected-controlled-drugs-procedure.pdf",
         encryption=pikepdf.Encryption(owner="v4-fixture-owner", user="v4-fixture-user", R=4))
pdf.close()
record("password-protected-controlled-drugs-procedure.pdf", "password_protected_pdf",
       "extraction fails with PDFPasswordIncorrect, typed failure_category",
       "Genuinely encrypted with pikepdf (RC4/AES R4). No real secret; password is a fixture-only literal.")

# 3. Unsupported extension.
(NEG / "old-policy-export.pages").write_text(
    "This file uses the .pages extension, which is not in apps/api/config/documents.php's "
    "accepted format list. Upload validation must reject it before any extraction is attempted.",
    encoding="utf-8",
)
record("old-policy-export.pages", "unsupported_extension",
       "rejected at upload validation (extension not in documents.formats)",
       "Deliberately outside the accepted pdf/docx/doc/rtf/txt/md set.")

# 4. Oversized-file simulation — described, not physically allocated at 25MB+.
oversized_meta = {
    "filename": "annual-company-report-2026-full.pdf",
    "declared_size_bytes": 30 * 1024 * 1024,
    "max_upload_bytes_at_authoring_time": 25 * 1024 * 1024,
    "note": (
        "This fixture intentionally does NOT contain a real 25MB+ binary. It is a bounded "
        "metadata-only fixture: a test harness that needs to exercise the "
        "'size_bytes exceeds max_upload_bytes' validation path should synthesise the declared "
        "size_bytes value directly in its InitializeDocumentUpload request rather than uploading "
        "an actual oversized file."
    ),
}
(NEG / "oversized-file-simulation.json").write_text(json.dumps(oversized_meta, indent=2), encoding="utf-8")
record("oversized-file-simulation.json", "oversized_file_simulation",
       "InitializeDocumentUploadRequest fails size_bytes validation",
       "Bounded fixture describing the condition; no large binary was created.")

# 5. Exact duplicate — same bytes as an existing V4-A file, different filename.
src = ROOT / "artifacts" / "docx" / "complaints-policy.docx"
dup_path = NEG / "complaints-policy-COPY.docx"
shutil.copyfile(src, dup_path)
record("complaints-policy-COPY.docx", "exact_duplicate_different_filename",
       "duplicate-content detection should flag this against v4.complaints.complaints-policy v1",
       f"Byte-identical copy of {src.relative_to(ROOT)} under a different filename.")

# 6. Near duplicate — same source content, trivially modified.
near_dup_doc = {
    "family_id": "v4.negative.near-duplicate-complaints-policy",
    "family_title": "Complaints Policy (near duplicate fixture)",
    "version_id": "v1", "domain": "complaints", "content_type": "policy",
    "human_title": "Complaints Policy", "filename": "complaints-policy-v2-draft.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-07-02", "messiness_level": "clean", "messiness_axes": [],
    "front_matter": None,
    "sections": [
        ("How to complain", "A complaint may be made verbally to any member of staff or in writing to the registered manager, by the person supported, a family member, or their representative."),
        ("Timescales", "A complaint is acknowledged within 3 working days and a full written response provided within 20 working days, or sooner where possible."),
        ("Escalation", "A complainant not satisfied with the response may escalate to the Alderbridge Quality Lead, and ultimately to the Local Government and Social Care Ombudsman or CQC."),
        ("New paragraph not in the original", "This fixture adds one extra sentence to test near-duplicate (not exact-duplicate) detection against the real Complaints Policy."),
    ],
}
data = render.render_docx(near_dup_doc)
(NEG / "complaints-policy-v2-draft.docx").write_bytes(data)
record("complaints-policy-v2-draft.docx", "near_duplicate",
       "should surface as a likely-match candidate against v4.complaints.complaints-policy, not an exact duplicate",
       "Same structure/wording as the real Complaints Policy plus one added paragraph.")

# 7. Obvious new version of an existing V4-A family (Annual Leave Policy v2).
new_version_doc = {
    "family_id": "v4.hr.annual-leave-policy", "family_title": "Annual Leave Policy",
    "version_id": "v2-fixture", "domain": "hr", "content_type": "policy",
    "human_title": "Annual Leave Policy", "filename": "annual-leave-policy-v2.pdf",
    "format": "pdf", "governance_status": "draft", "applicability_scope": "universal",
    "effective_date": "2026-06-01", "messiness_level": "mild", "messiness_axes": [],
    "front_matter": "Applies to all Alderbridge Care Group employees, all sites.",
    "sections": [
        ("Purpose", "This policy sets out how annual leave is calculated, requested and approved across Alderbridge Care Group, including the leave year, carry-over rules and notice periods for requesting leave."),
        ("Leave year and entitlement", "The leave year runs from 1 April to 31 March. Full-time employees receive 30 days' annual leave per year inclusive of bank holidays, an increase from the prior 28-day entitlement."),
        ("Requesting leave", "Leave requests must be submitted via the rota system at least 14 days before the requested dates for non-peak periods, and 28 days before the requested dates over the Christmas and New Year period."),
    ],
}
data = render.render_pdf(new_version_doc)
(NEG / "annual-leave-policy-v2.pdf").write_bytes(data)
record("annual-leave-policy-v2.pdf", "obvious_new_version",
       "should match the existing v4.hr.annual-leave-policy family and offer a version-promotion decision",
       "28->30 day entitlement change; same family, clearly a new version of an existing V4-A document.")

# 8. Obvious new family (nothing like it exists in V4-A).
new_family_doc = {
    "family_id": "v4.negative.new-family-electric-vehicle-charging", "family_title": "Electric Vehicle Charging Policy",
    "version_id": "v1", "domain": "facilities-fleet", "content_type": "policy",
    "human_title": "Electric Vehicle Charging Policy", "filename": "ev-charging-policy.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "specific",
    "applicability_locations": ["location.central-support-office"],
    "effective_date": "2026-05-01", "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Scope", "This new policy covers the two electric vehicle charging bays installed at Central Support Office in May 2026, a topic not covered by any existing Alderbridge policy."),
    ],
}
data = render.render_txt(new_family_doc, render.build_markdown(new_family_doc))
(NEG / "ev-charging-policy.txt").write_bytes(data)
record("ev-charging-policy.txt", "obvious_new_family",
       "should not match any existing family; offered as a new-family creation candidate",
       "Genuinely new topic (EV charging) with no prior Alderbridge document.")

# 9. Ambiguous possible family match.
ambiguous_doc = {
    "family_id": "v4.negative.ambiguous-leave-summary", "family_title": "Leave Summary — Ambiguous Match Fixture",
    "version_id": "v1", "domain": "hr", "content_type": "faq_guidance",
    "human_title": "Staff Leave Summary", "filename": "staff-leave-summary.docx",
    "format": "docx", "governance_status": "draft", "applicability_scope": "universal",
    "effective_date": "2026-03-01", "messiness_level": "moderate", "messiness_axes": ["similar_title_different_family"],
    "sections": [
        ("Overview", "This one-page summary briefly restates entitlements from BOTH the Annual Leave Policy and the Family and Parental Leave Policy in one document, deliberately structured so an automated matcher cannot confidently pick a single existing family."),
    ],
}
data = render.render_docx(ambiguous_doc)
(NEG / "staff-leave-summary.docx").write_bytes(data)
record("staff-leave-summary.docx", "ambiguous_possible_family_match",
       "match confidence should be low/ambiguous against two existing families rather than auto-resolved",
       "Deliberately overlaps two real V4-A families (Annual Leave Policy, Family and Parental Leave Policy).")

# 10. Interrupted/resumable batch metadata.
interrupted_batch = {
    "fixture_type": "interrupted_resumable_batch_metadata",
    "batch_reference": "v4-fixture-batch-001",
    "declared_item_count": 5,
    "items_uploaded_before_interruption": 3,
    "note": (
        "Describes the state a real ImportBatch would be in if the browser/network connection "
        "dropped after 3 of 5 declared files were staged. A test harness resumes the batch and "
        "confirms the remaining 2 items can still be added without corrupting the first 3."
    ),
}
(NEG / "interrupted-batch-metadata.json").write_text(json.dumps(interrupted_batch, indent=2), encoding="utf-8")
record("interrupted-batch-metadata.json", "interrupted_resumable_batch",
       "batch resumes cleanly; first 3 items unaffected", "Metadata-only fixture, no binary needed.")

# 11. Replacement for one failed file.
replacement_meta = {
    "fixture_type": "replacement_for_failed_file",
    "original_failed_filename": "corrupt-fire-safety-policy.pdf",
    "replacement_filename": "fire-safety-policy-REPLACEMENT.pdf",
    "note": "The replacement is a byte-for-byte copy of the real, valid Fire Safety Policy artefact.",
}
shutil.copyfile(ROOT / "artifacts" / "pdf" / "fire-safety-policy.pdf", NEG / "fire-safety-policy-REPLACEMENT.pdf")
(NEG / "replacement-for-failed-file.json").write_text(json.dumps(replacement_meta, indent=2), encoding="utf-8")
record("fire-safety-policy-REPLACEMENT.pdf", "replacement_for_failed_file",
       "should succeed where the corrupt original failed", "Valid PDF, reused from V4-A's own Fire Safety Policy content.")
record("replacement-for-failed-file.json", "replacement_for_failed_file_metadata",
       "describes the replacement scenario", "Metadata only.")

# 12. Mixed-success bulk batch manifest (3 succeed, 2 fail — references fixtures above).
mixed_batch = {
    "fixture_type": "mixed_success_bulk_batch",
    "batch_reference": "v4-fixture-batch-002",
    "items": [
        {"filename": "ev-charging-policy.txt", "expected_outcome": "success"},
        {"filename": "fire-safety-policy-REPLACEMENT.pdf", "expected_outcome": "success"},
        {"filename": "staff-leave-summary.docx", "expected_outcome": "success_ambiguous_match_requires_decision"},
        {"filename": "corrupt-fire-safety-policy.pdf", "expected_outcome": "failure_corrupt"},
        {"filename": "old-policy-export.pages", "expected_outcome": "failure_unsupported_extension"},
    ],
}
(NEG / "mixed-success-bulk-batch.json").write_text(json.dumps(mixed_batch, indent=2), encoding="utf-8")
record("mixed-success-bulk-batch.json", "mixed_success_bulk_batch",
       "3 of 5 items succeed, 2 fail with distinct typed reasons", "References fixtures already created above.")

manifest = {
    "schema_version": "v4-draft",
    "corpus_id": "dolved-care-alderbridge-v4",
    "status": "AUTHORING_DRAFT",
    "note": "Excluded from the primary 300-document count. All items are inert test fixtures.",
    "fixtures": entries,
}
(NEG / "negative-fixtures-manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
print(f"Built {len(entries)} negative-fixture manifest entries.")
