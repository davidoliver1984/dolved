"""V4-A batch 5: Information governance, data protection, IT/cyber, business continuity."""

DOCS = [
{
    "family_id": "v4.infogov.data-protection-policy", "family_title": "Data Protection Policy",
    "version_id": "v1", "domain": "information-governance", "content_type": "policy",
    "human_title": "Data Protection Policy", "filename": "data-protection-policy.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-05-25", "messiness_level": "moderate",
    "messiness_axes": ["abbreviation_heavy", "cross_reference"],
    "sections": [
        ("Our commitment", "Alderbridge Care Group processes personal data, including special category health data about people supported, in line with the UK GDPR and Data Protection Act 2018."),
        ("Data minimisation", "Staff must only access and record the personal data needed for their role. Curiosity access to a care record you are not involved in supporting is a disciplinary matter."),
        ("Subject access requests", "A subject access request (SAR) must be forwarded to the Data Protection Lead the same day it is received; see the SAR Handling Procedure for the response timescale."),
    ],
},
{
    "family_id": "v4.infogov.sar-handling-procedure", "family_title": "Subject Access Request Handling Procedure",
    "version_id": "v1", "domain": "information-governance", "content_type": "policy",
    "human_title": "Subject Access Request (SAR) Handling Procedure", "filename": "sar-handling-procedure.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-05-25", "messiness_level": "mild", "messiness_axes": ["abbreviation_heavy"],
    "sections": [
        ("Timescale", "A SAR must be responded to within one calendar month of receipt, extendable by a further two months for complex requests, with the requester informed of any extension within the first month."),
        ("Redaction", "Third-party personal data (for example, references to another person supported or a member of staff) must be redacted before disclosure unless that third party has consented."),
    ],
},
{
    "family_id": "v4.infogov.data-breach-procedure", "family_title": "Personal Data Breach Procedure",
    "version_id": "v1", "domain": "information-governance", "content_type": "policy",
    "human_title": "Personal Data Breach Procedure", "filename": "personal-data-breach-procedure.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-05-25", "messiness_level": "moderate",
    "messiness_axes": ["buried_exception", "cross_reference"],
    "sections": [
        ("Reporting", "Any suspected data breach — including a lost device, misdirected email, or unauthorised disclosure — must be reported to the Data Protection Lead within 1 hour of discovery, escalating outside office hours via the on-call manager."),
        ("ICO notification", "The Data Protection Lead assesses whether the breach must be reported to the Information Commissioner's Office within 72 hours, except where the breach is unlikely to result in a risk to individuals' rights and freedoms, in which case the assessment and reasoning is still documented internally."),
    ],
},
{
    "family_id": "v4.infogov.records-retention-schedule", "family_title": "Records Retention Schedule",
    "version_id": "v1", "domain": "information-governance", "content_type": "schedule_reference",
    "human_title": "Records Retention Schedule", "filename": "records-retention-schedule.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-05-25", "messiness_level": "moderate", "messiness_axes": ["dense_table"],
    "sections": [
        ("__table__", [
            ["Record type", "Retention period", "Basis"],
            ["Care records (adult)", "8 years after last contact", "Local authority guidance"],
            ["Employee personnel file", "6 years after employment ends", "Statute of limitations"],
            ["Medication administration records", "8 years", "Care record alignment"],
            ["CCTV footage", "31 days unless subject to an incident", "Proportionality"],
            ["Recruitment records (unsuccessful candidates)", "6 months", "Discrimination claim window"],
        ]),
    ],
},
{
    "family_id": "v4.infogov.cctv-policy", "family_title": "CCTV Policy",
    "version_id": "v1", "domain": "information-governance", "content_type": "policy",
    "human_title": "CCTV Policy", "filename": "cctv-policy.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-05-25", "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Purpose", "CCTV is used at building entrances and communal areas for the safety and security of people supported, staff and visitors. Cameras are never placed in bedrooms, bathrooms, or other private areas."),
        ("Access to footage", "Footage may only be viewed by the registered manager or their deputy, and only for a specific, recorded purpose such as investigating an incident."),
    ],
},
{
    "family_id": "v4.it.acceptable-use-policy", "family_title": "IT Acceptable Use Policy",
    "version_id": "v1", "domain": "it-security", "content_type": "policy",
    "human_title": "IT and Communications Acceptable Use Policy", "filename": "it-acceptable-use-policy.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-06-01", "messiness_level": "mild", "messiness_axes": ["abbreviation_heavy"],
    "sections": [
        ("Scope", "This policy applies to all ICT equipment, accounts and systems provided by Alderbridge Care Group, including email, the care records system, and any device used to access them."),
        ("Passwords", "Passwords must be at least 12 characters, unique to Alderbridge systems, and never shared with another person, including a colleague covering your shift."),
        ("Personal use", "Reasonable personal use of email and internet access is permitted provided it does not interfere with duties, breach any other policy, or involve inappropriate content."),
    ],
},
{
    "family_id": "v4.it.password-and-access-guidance", "family_title": "Password and Account Access Guidance",
    "version_id": "v1", "domain": "it-security", "content_type": "faq_guidance",
    "human_title": "Passwords and Account Access: Quick Guidance", "filename": "password-access-guidance.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-06-01", "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Locked out?", "Contact the IT service desk to reset your password. Never ask a colleague to log in on your behalf, even temporarily."),
        ("Leaving your desk", "Lock your screen (Windows key + L) whenever you step away from a device that can access care records."),
    ],
},
{
    "family_id": "v4.it.phishing-awareness-guidance", "family_title": "Phishing Awareness Guidance",
    "version_id": "v1", "domain": "it-security", "content_type": "faq_guidance",
    "human_title": "Phishing Awareness: Spotting a Suspicious Email", "filename": "phishing-awareness-guidance.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-06-01", "messiness_level": "mild", "messiness_axes": ["nested_bullets"],
    "sections": [
        ("__list__", [
            "Warning signs of a phishing email:",
            "  - Urgent or threatening language demanding immediate action",
            "  - A sender address that looks almost right but is subtly wrong",
            "  - A request for a password, bank detail, or gift card purchase",
            "  - An unexpected attachment or link",
        ]),
        ("What to do", "Do not click. Forward the email to the IT service desk using the 'Report Phishing' button, then delete it."),
    ],
},
{
    "family_id": "v4.it.remote-working-security-guidance", "family_title": "Remote Working Security Guidance",
    "version_id": "v1", "domain": "it-security", "content_type": "faq_guidance",
    "human_title": "Remote Working: Keeping Data Secure", "filename": "remote-working-security-guidance.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "specific",
    "applicability_locations": ["location.central-support-office"],
    "effective_date": "2026-04-06", "messiness_level": "mild", "messiness_axes": ["cross_reference"],
    "front_matter": "Applies to Central Support Office staff working under an agreed flexible working arrangement — see the Flexible Working Policy.",
    "sections": [
        ("Device security", "Only Alderbridge-issued laptops with full-disk encryption may be used to access the care records system remotely. Personal devices must not be used except for reading email via the approved mobile app."),
        ("Screen privacy", "Staff working in a shared or public space must use a privacy screen and ensure no care information is visible to others."),
    ],
},
{
    "family_id": "v4.bcp.business-continuity-plan-summary", "family_title": "Business Continuity Plan — Summary",
    "version_id": "v1", "domain": "business-continuity", "content_type": "policy",
    "human_title": "Business Continuity Plan — Summary", "filename": "business-continuity-plan-summary.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-10-01", "messiness_level": "moderate",
    "messiness_axes": ["abbreviation_heavy", "footnote_appendix"],
    "sections": [
        ("Purpose", "This BCP summary sets out how Alderbridge Care Group maintains critical care services during a major disruption such as severe weather, IT outage, utility failure, or loss of a site."),
        ("Critical services", "Medication administration, personal care, and safe staffing levels are treated as critical services that must continue in any scenario; office administrative functions may be paused."),
        ("Activation", "The on-call director may activate the BCP outside office hours; see Appendix A (site-specific continuity annexes) for site-level contact trees, not reproduced in this summary."),
    ],
},
{
    "family_id": "v4.bcp.power-outage-guidance", "family_title": "Power Outage Response Guidance",
    "version_id": "v1", "domain": "business-continuity", "content_type": "faq_guidance",
    "human_title": "Power Outage: Immediate Actions", "filename": "power-outage-guidance.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-10-01", "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Immediate actions", "Check the medication fridge and any electrically dependent care equipment first. Contact the on-call manager if power is not restored within 30 minutes, and consider whether any resident's equipment (e.g. profiling bed, hoist) requires a manual backup procedure."),
    ],
},
{
    "family_id": "v4.bcp.it-outage-contact-tree", "family_title": "IT Outage Contact Tree",
    "version_id": "v1", "domain": "business-continuity", "content_type": "schedule_reference",
    "human_title": "IT Outage: Who to Contact", "filename": "it-outage-contact-tree.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-10-01", "messiness_level": "mild", "messiness_axes": ["dense_table"],
    "sections": [
        ("__table__", [
            ["Issue", "First contact", "Escalation"],
            ["Care records system unavailable", "IT service desk", "On-call director after 1 hour"],
            ["Email/telephone unavailable", "IT service desk", "Site fallback: mobile phone tree"],
            ["Suspected cyber incident", "IT service desk immediately", "Data Protection Lead simultaneously"],
        ]),
    ],
},
]
