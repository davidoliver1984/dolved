"""V4-A batch 6: Procurement, contractors, visitors, facilities/travel/fleet, payroll/pensions/training."""

DOCS = [
{
    "family_id": "v4.procurement.procurement-policy", "family_title": "Procurement Policy",
    "version_id": "v1", "domain": "procurement", "content_type": "policy",
    "human_title": "Procurement Policy", "filename": "procurement-policy.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-04-01", "messiness_level": "moderate",
    "messiness_axes": ["dense_table", "buried_exception"],
    "sections": [
        ("Approval thresholds", "Purchases require sign-off according to value: registered manager up to £500, regional director up to £5,000, Chief Executive above £5,000, except emergency purchases directly affecting resident safety, which may proceed with retrospective approval within 48 hours."),
        ("__table__", [
            ["Value", "Approver"],
            ["Up to £500", "Registered manager"],
            ["£500.01 to £5,000", "Regional director"],
            ["Above £5,000", "Chief Executive"],
        ]),
    ],
},
{
    "family_id": "v4.procurement.supplier-due-diligence-checklist", "family_title": "Supplier Due Diligence Checklist",
    "version_id": "v1", "domain": "procurement", "content_type": "form",
    "human_title": "Supplier Due Diligence Checklist", "filename": "supplier-due-diligence-checklist.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-04-01", "messiness_level": "moderate", "messiness_axes": ["dense_table"],
    "sections": [
        ("__table__", [
            ["Check", "Confirmed"],
            ["Insurance certificate current", ""],
            ["References obtained", ""],
            ["Data processing agreement signed (if handling personal data)", ""],
            ["Modern slavery statement reviewed (if annual spend > £36m threshold applies to supplier)", ""],
        ]),
    ],
},
{
    "family_id": "v4.contractors.contractor-management-policy", "family_title": "Contractor Management Policy",
    "version_id": "v1", "domain": "contractors-visitors", "content_type": "policy",
    "human_title": "Contractor Management Policy", "filename": "contractor-management-policy.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-05-01", "messiness_level": "mild", "messiness_axes": ["cross_reference"],
    "sections": [
        ("Site induction", "Every contractor must complete a site induction and sign in/out at reception before starting work, and must be supervised or escorted in areas where people supported are present."),
        ("Permit to work", "Any work involving hot work, working at height, or isolation of services requires a completed Contractor Permit to Work before starting."),
    ],
},
{
    "family_id": "v4.contractors.visitor-sign-in-form", "family_title": "Visitor Sign-In Form",
    "version_id": "v1", "domain": "contractors-visitors", "content_type": "form",
    "human_title": "Visitor Sign-In Form", "filename": "visitor-sign-in-form.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-05-01", "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Instructions", "All visitors must sign in at reception on arrival, wear a visitor badge at all times, and sign out on departure. Fields: name, organisation (if applicable), person visiting, time in, time out."),
    ],
},
{
    "family_id": "v4.contractors.visiting-arrangements-policy", "family_title": "Visiting Arrangements Policy",
    "version_id": "v1", "domain": "contractors-visitors", "content_type": "policy",
    "human_title": "Visiting Arrangements Policy", "filename": "visiting-arrangements-policy.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-05-01", "messiness_level": "mild", "messiness_axes": ["buried_exception"],
    "sections": [
        ("Open visiting", "Alderbridge operates open visiting for family and friends, with no restriction on visiting hours, except where an outbreak management restriction is temporarily in place under the Outbreak Management Procedure."),
        ("Safeguarding", "Any visitor whose presence raises a safeguarding concern may be asked to leave, and the concern reported using the Safeguarding Referral Form."),
    ],
},
{
    "family_id": "v4.facilities.fleet-vehicle-policy", "family_title": "Fleet and Vehicle Use Policy",
    "version_id": "v1", "domain": "facilities-fleet", "content_type": "policy",
    "human_title": "Fleet and Vehicle Use Policy", "filename": "fleet-vehicle-policy.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-06-01", "messiness_level": "moderate",
    "messiness_axes": ["mixed_numbering", "dense_table"],
    "sections": [
        ("1. Eligibility to drive", "Only staff whose licence has been checked by HR within the last 12 months, and who hold appropriate business insurance cover confirmed with their own insurer where using a personal vehicle, may drive on Alderbridge business."),
        ("2. Daily checks", "Drivers of pool vehicles must complete a walkaround check before use."),
        ("__table__", [
            ["Check", "Frequency"],
            ["Tyres and lights", "Before each use"],
            ["Oil and coolant", "Weekly"],
            ["Service", "Per manufacturer schedule"],
        ]),
    ],
},
{
    "family_id": "v4.facilities.mileage-expenses-claim-form", "family_title": "Mileage and Travel Expenses Claim Form",
    "version_id": "v1", "domain": "facilities-fleet", "content_type": "form",
    "human_title": "Mileage and Travel Expenses Claim Form", "filename": "mileage-expenses-claim-form.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-04-01", "messiness_level": "mild", "messiness_axes": ["dense_table"],
    "sections": [
        ("__table__", [
            ["Date", "From", "To", "Miles", "Rate", "Total"],
            ["", "", "", "", "45p/mile (first 10,000)", ""],
        ]),
        ("Submission", "Claims must be submitted monthly, with receipts attached for any non-mileage expense over £10."),
    ],
},
{
    "family_id": "v4.payroll.expenses-policy", "family_title": "Staff Expenses Policy",
    "version_id": "v1", "domain": "payroll", "content_type": "policy",
    "human_title": "Staff Expenses Policy", "filename": "staff-expenses-policy.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-04-01", "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("What can be claimed", "Reasonable, wholly business-related travel, subsistence and mileage costs may be claimed with a receipt. Alcohol, and any expense not directly related to Alderbridge business, is never reimbursable."),
        ("Approval and payment", "Claims are approved by the line manager and paid with the following month's salary, provided they are submitted by the 20th of the month."),
    ],
},
{
    "family_id": "v4.payroll.pension-scheme-guidance", "family_title": "Pension Scheme Guidance",
    "version_id": "v1", "domain": "payroll", "content_type": "faq_guidance",
    "human_title": "Workplace Pension Scheme: What You Need to Know", "filename": "pension-scheme-guidance.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-04-01", "messiness_level": "mild", "messiness_axes": ["abbreviation_heavy"],
    "sections": [
        ("Auto-enrolment", "Eligible staff are automatically enrolled into the Alderbridge workplace pension scheme, with a minimum employee contribution of 5% and employer contribution of 3% of qualifying earnings."),
        ("Opting out", "You may opt out within one month of enrolment for a full refund of contributions made; opting out after this window stops future contributions but does not refund past ones."),
    ],
},
{
    "family_id": "v4.payroll.overtime-and-payroll-calendar", "family_title": "Overtime Procedure and Payroll Calendar",
    "version_id": "v1", "domain": "payroll", "content_type": "schedule_reference",
    "human_title": "Overtime Procedure and Payroll Calendar 2026", "filename": "overtime-payroll-calendar-2026.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2026-01-01", "messiness_level": "moderate", "messiness_axes": ["dense_table", "inconsistent_dates"],
    "sections": [
        ("Overtime approval", "Overtime must be pre-approved by the registered manager before the shift is worked, except where covering an unplanned absence at short notice."),
        ("__table__", [
            ["Pay period", "Cut-off date", "Pay date"],
            ["January 2026", "20 Jan 2026", "30/01/2026"],
            ["February 2026", "20/02/26", "27 Feb 2026"],
            ["March 2026", "20.03.2026", "31/03/2026"],
        ]),
    ],
},
{
    "family_id": "v4.training.mandatory-training-matrix", "family_title": "Mandatory Training Matrix",
    "version_id": "v1", "domain": "training", "content_type": "schedule_reference",
    "human_title": "Mandatory Training Matrix", "filename": "mandatory-training-matrix.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-09-01", "messiness_level": "severe",
    "messiness_axes": ["dense_table", "info_in_table_cell", "mixed_numbering"],
    "sections": [
        ("__table__", [
            ["Course", "Frequency", "Applies to", "Notes"],
            ["Fire safety", "Annual", "All staff", "Includes evacuation walk-through — see Fire Safety Policy"],
            ["Moving and handling", "Annual (practical) + refresher e-learning at 6 months", "Care staff", "New starters: before unsupervised handling"],
            ["Medication competency", "Initial + annual observed check", "Staff administering medication", "Controlled drugs module mandatory if site holds CDs"],
            ["Safeguarding adults level 2", "Every 3 years", "All staff", "Level 1 for non-care-facing roles"],
            ["Infection prevention and control", "Annual", "All staff", ""],
            ["Information governance", "Annual", "All staff", "Includes SAR awareness"],
        ]),
    ],
},
{
    "family_id": "v4.training.induction-programme-outline", "family_title": "New Starter Induction Programme Outline",
    "version_id": "v1", "domain": "training", "content_type": "onboarding_training",
    "human_title": "New Starter Induction Programme — Week 1 Outline", "filename": "induction-programme-week1.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-09-01", "messiness_level": "mild", "messiness_axes": ["nested_bullets"],
    "sections": [
        ("__list__", [
            "Day 1: Welcome, contract signing, ID badge, fire safety induction",
            "Day 2: Safeguarding awareness, moving and handling (theory)",
            "Day 3: Medication awareness (non-administering staff) or medication competency start (administering staff)",
            "  - Shadowing an experienced colleague begins Day 3 for all care roles",
            "Day 4: Infection prevention and control, information governance",
            "Day 5: Meet the registered manager, questions, probation review date confirmed",
        ]),
    ],
},
{
    "family_id": "v4.training.faq-training-records", "family_title": "FAQ — Training Records and Refreshers",
    "version_id": "v1", "domain": "training", "content_type": "faq_guidance",
    "human_title": "FAQ: Training Records and Refreshers", "filename": "faq-training-records.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-09-01", "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("How do I check when my training is due?", "Your training record is visible in the staff portal under 'My Training'. It shows the completion date and the next-due date for every mandatory course."),
        ("What happens if I miss a refresher deadline?", "You will be booked onto the next available session automatically and may be temporarily restricted from the task concerned (for example, medication administration) until the refresher is completed."),
    ],
},
]
