"""18-case tamper-test suite for generate/validate_version_fidelity.py.

Each test mutates the LIVE corpus in a small, precisely targeted way,
confirms the validator fails for the intended reason, then immediately
restores the original bytes and reverifies a clean baseline before moving
to the next test. Tests run strictly sequentially (never in parallel) and
every restore is verified byte-identical before continuing, so no mutation
is ever left in place and no two tests can interact.

This is a corpus-authoring governance test tool, not evaluation material.
"""
import copy
import importlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))

MANIFEST_PATH = ROOT / "source-manifest.json"
CONTRACTS_PATH = ROOT / "authoring-governance" / "version-diff-contracts.json"

results = []


def load_json(p):
    return json.loads(p.read_text(encoding="utf-8"))


def write_json(p, data):
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def run_validator():
    import validate_version_fidelity as vvf
    importlib.reload(vvf)
    return vvf.run()


def record(name, expected_substring, problems):
    joined = "\n".join(problems)
    ok = len(problems) > 0 and expected_substring.lower() in joined.lower()
    results.append((name, ok, problems[:3] if problems else ["(no failure produced)"]))
    status = "PASS" if ok else "**FAIL (test itself did not behave as expected)**"
    print(f"[{status}] {name}")
    if not ok:
        print("   expected substring:", expected_substring)
        print("   actual problems:", problems[:5])


class ArtefactBackup:
    """Backs up and restores an arbitrary file's raw bytes."""
    def __init__(self, path: Path):
        self.path = path
        self.original = path.read_bytes()

    def restore(self):
        self.path.write_bytes(self.original)
        assert self.path.read_bytes() == self.original


def with_manifest(mutate_fn):
    manifest = load_json(MANIFEST_PATH)
    original = copy.deepcopy(manifest)
    mutate_fn(manifest)
    write_json(MANIFEST_PATH, manifest)
    checked, problems = run_validator()
    write_json(MANIFEST_PATH, original)
    assert load_json(MANIFEST_PATH) == original
    return problems


def with_contracts(mutate_fn):
    contracts = load_json(CONTRACTS_PATH)
    original = copy.deepcopy(contracts)
    mutate_fn(contracts)
    write_json(CONTRACTS_PATH, contracts)
    checked, problems = run_validator()
    write_json(CONTRACTS_PATH, original)
    assert load_json(CONTRACTS_PATH) == original
    return problems


def with_artefact(path: Path, mutate_fn):
    backup = ArtefactBackup(path)
    text = backup.original.decode("utf-8")
    mutated = mutate_fn(text)
    path.write_text(mutated, encoding="utf-8")
    checked, problems = run_validator()
    backup.restore()
    return problems


def find_entry(manifest, family_id, version_id):
    return next(d for d in manifest["documents"] if d["family_id"] == family_id and d["version_id"] == version_id)


def find_contract(contracts, family_id, from_v, to_v):
    return next(c for c in contracts["comparisons"]
                if c["family_id"] == family_id and c["from_version"] == from_v and c["to_version"] == to_v)


CONT = "v4b.care.continence-care-policy"
DBS = "v4b.hr.dbs-renewal-procedure"
HANDOVER = "v4b.hr.staff-handover-procedure"
HOMELY = "v4b.medication.homely-remedies-policy"

cont_v2_path = ROOT / next(d["artefact_path"] for d in load_json(MANIFEST_PATH)["documents"]
                           if d["family_id"] == CONT and d["version_id"] == "v2")
cont_v1_path = ROOT / next(d["artefact_path"] for d in load_json(MANIFEST_PATH)["documents"]
                           if d["family_id"] == CONT and d["version_id"] == "v1")


def main():
    # baseline sanity
    checked, problems = run_validator()
    print(f"Baseline: {checked} comparisons, {len(problems)} problems (must be 0)\n")
    assert problems == [], f"corpus is not clean before tamper testing: {problems}"

    # 1. unknown type
    def mut1(m):
        find_entry(m, CONT, "v2")["version_change_type"] = "not_a_real_registry_type"
    record("1. unknown type", "not in the closed registry", with_manifest(mut1))

    # 2. manifest/contract type mismatch
    def mut2(m):
        find_entry(m, DBS, "v2")["version_change_type"] = "changed_contact_escalation"
    record("2. manifest/contract type mismatch", "does not exactly equal", with_manifest(mut2))

    # 3. missing contract
    def mut3(c):
        c["comparisons"] = [x for x in c["comparisons"]
                             if not (x["family_id"] == CONT and x["from_version"] == "v1")]
    record("3. missing contract", "no per-comparison contract found", with_contracts(mut3))

    # 4. orphan contract
    def mut4(c):
        fake = copy.deepcopy(c["comparisons"][0])
        fake["family_id"] = "v4b.does-not-exist.fake-family"
        fake["from_version"] = "v1"
        fake["to_version"] = "v2"
        c["comparisons"].append(fake)
    record("4. orphan contract", "orphan contract", with_contracts(mut4))

    # 5. incorrect before digest
    def mut5(c):
        find_contract(c, CONT, "v1", "v2")["digest_before"] = "0" * 64
    record("5. incorrect before digest", "digest_before", with_contracts(mut5))

    # 6. incorrect after digest
    def mut6(c):
        find_contract(c, CONT, "v1", "v2")["digest_after"] = "0" * 64
    record("6. incorrect after digest", "digest_after", with_contracts(mut6))

    # 7. unexpected added section
    def mut7(text):
        return text.replace(
            "Skin integrity monitoring",
            "Bogus Injected Section\n\nThis section was never reviewed or declared in any contract.\n\nSkin integrity monitoring",
            1,
        )
    record("7. unexpected added section", "allowed_changed_sections mismatch", with_artefact(cont_v2_path, mut7))

    # 8. unexpected removed section
    def mut8(text):
        return text.replace(
            "Skin integrity monitoring\n\nStaff check a resident's skin condition during "
            "continence-related care as a matter of routine, reporting any early sign of "
            "soreness or breakdown promptly, since continence care and pressure area care "
            "overlap closely and a skin concern noticed during one task is acted on "
            "immediately rather than left for a separate, later check.\n\n",
            "",
            1,
        )
    record("8. unexpected removed section", "allowed_changed_sections mismatch", with_artefact(cont_v2_path, mut8))

    # 9. altered protected content (a section NOT part of the declared
    # broader-rewrite scope for this pair, so it must be content-invariant)
    def mut9(text):
        return text.replace(
            "This policy works alongside the Care Planning Policy",
            "This policy works alongside the SECRETLY ALTERED Care Planning Policy",
            1,
        )
    record("9. altered protected content", "protected section", with_artefact(cont_v2_path, mut9))

    # 10. missing required before phrase (predecessor no longer matches contract)
    def mut10(text):
        return text.replace(
            "A continence assessment should be completed within one week of admission",
            "A continence assessment is completed within one week of admission",
            1,
        )
    record("10. missing required before phrase", "predecessor version", with_artefact(cont_v1_path, mut10))

    # 11. missing required after phrase
    def mut11(text):
        return text.replace(
            "A continence assessment must be completed within one week of admission",
            "A continence assessment is completed within one week of admission",
            1,
        )
    record("11. missing required after phrase", "required after-phrase", with_artefact(cont_v2_path, mut11))

    # 12. restored old phrase where prohibited (added alongside, not replacing)
    def mut12(text):
        return text.replace(
            "A continence assessment must be completed within one week of admission",
            "A continence assessment must (and, some feel, should) be completed within one week of admission",
            1,
        )
    record("12. restored old phrase where prohibited", "prohibited before-phrase", with_artefact(cont_v2_path, mut12))

    # 13. false renamed-heading claim
    def mut13(c):
        rc = find_contract(c, HOMELY, "v1", "v2")
        rc["renamed_headings"] = [{"before": "Something else entirely", "after": "Not a real heading"}]
    record("13. false renamed-heading claim", "renamed_headings mismatch", with_contracts(mut13))

    # 14. false reordered-section claim
    def mut14(c):
        rc = find_contract(c, CONT, "v1", "v2")
        rc["order_changed"] = not rc["order_changed"]
    record("14. false reordered-section claim", "order_changed mismatch", with_contracts(mut14))

    # 15. false applicability-only claim
    def mut15(m):
        e2 = find_entry(m, "v4b.hs.key-safe-procedure", "v2")
        e1 = find_entry(m, "v4b.hs.key-safe-procedure", "v1")
        e2["applicability_locations"] = list(e1["applicability_locations"])
        e2["applicability_scope"] = e1["applicability_scope"]
    record("15. false applicability-only claim", "applicability_scope/applicability_locations are identical",
           with_manifest(mut15))

    # 16. false numeric/date/contact/clause change (core_change after_phrase no longer present)
    def mut16(c):
        rc = find_contract(c, CONT, "v1", "v2")
        rc["core_change"]["after_phrase"] = "a phrase that will never appear in this document"
    record("16. false numeric/date/contact/clause change", "required after-phrase", with_contracts(mut16))

    # 17. false formatting-only pair
    def mut17(m):
        find_entry(m, CONT, "v2")["version_change_type"] = "formatting_only_honest_gap"

    def mut17_contract(c):
        rc = find_contract(c, CONT, "v1", "v2")
        rc["declared_type"] = "formatting_only_honest_gap"

    manifest = load_json(MANIFEST_PATH)
    original_manifest = copy.deepcopy(manifest)
    mut17(manifest)
    write_json(MANIFEST_PATH, manifest)
    contracts = load_json(CONTRACTS_PATH)
    original_contracts = copy.deepcopy(contracts)
    mut17_contract(contracts)
    write_json(CONTRACTS_PATH, contracts)
    checked, problems17 = run_validator()
    write_json(MANIFEST_PATH, original_manifest)
    write_json(CONTRACTS_PATH, original_contracts)
    assert load_json(MANIFEST_PATH) == original_manifest
    assert load_json(CONTRACTS_PATH) == original_contracts
    record("17. false formatting-only pair", "normalized EXTRACTED text differs", problems17)

    # 18. the exact Continence Care must->should reversal used by Codex
    def mut18(text):
        return text.replace(
            "A continence assessment must be completed within one week of admission and "
            "reviewed 6-monthly — no longer merely advisory —",
            "A continence assessment should be completed within one week of admission and "
            "reviewed 6-monthly — no longer merely advisory —",
            1,
        )
    record("18. exact Continence must->should reversal (Codex case)", "prohibited before-phrase",
           with_artefact(cont_v2_path, mut18))

    # final: confirm clean baseline restored
    checked, problems = run_validator()
    print(f"\nFinal baseline recheck: {checked} comparisons, {len(problems)} problems (must be 0)")
    assert problems == [], f"corpus was not fully restored after tamper testing: {problems}"

    passed = sum(1 for _, ok, _ in results if ok)
    print(f"\n{passed}/{len(results)} tamper tests behaved as expected.")
    for name, ok, sample in results:
        if not ok:
            print(f"  UNEXPECTED: {name} -> {sample}")
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
