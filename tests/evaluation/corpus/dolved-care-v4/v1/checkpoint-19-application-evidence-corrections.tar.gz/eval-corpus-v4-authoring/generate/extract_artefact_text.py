"""Shared real-artefact text extraction, used by both the per-comparison
contract builder and the fidelity validator so both operate on the actual
declared extractor's output, not semantic-master markdown structure.
"""
import re
from pathlib import Path

import pdfplumber
from docx import Document


def extract_full_text(path: Path, fmt: str) -> str:
    if fmt == "txt":
        return path.read_text(encoding="utf-8")
    if fmt == "pdf":
        with pdfplumber.open(path) as pdf:
            return "\n".join(page.extract_text() or "" for page in pdf.pages)
    doc = Document(path)
    body = "\n".join(p.text for p in doc.paragraphs)
    footer = "\n".join(p.text for section in doc.sections for p in section.footer.paragraphs)
    header = "\n".join(p.text for section in doc.sections for p in section.header.paragraphs)
    return "\n".join(x for x in (header, body, footer) if x)


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def split_into_sections(full_text: str, headings: list[str]) -> dict[str, str]:
    """Carve the extracted plain text into per-heading bodies, using the
    known heading strings (from the semantic master) as delimiters. Returns
    heading -> body text (raw, not yet normalized) for every heading found
    in the extracted text. A heading not found is absent from the returned
    dict (the caller treats that as the section being missing).

    A heading is matched either as a single standalone line, or — since a
    long heading can wrap across 2-3 lines in a PDF's reportlab Paragraph
    flowable — as the whitespace-normalized concatenation of up to 3
    consecutive lines, so a wrapped heading is still found correctly rather
    than reported as a missing/removed section."""
    lines = full_text.splitlines()

    def window_matches(start: int, window: int, target_norm: str) -> bool:
        if start + window > len(lines):
            return False
        candidate = normalize(" ".join(lines[start:start + window]))
        return candidate == target_norm

    positions: list[tuple[int, int, str]] = []  # (start_line, end_line_exclusive, heading)
    search_from = 0
    for heading in headings:
        target_norm = normalize(heading)
        found = None
        for i in range(search_from, len(lines)):
            for window in (1, 2, 3):
                if window_matches(i, window, target_norm):
                    found = (i, i + window)
                    break
            if found:
                break
        if found:
            positions.append((found[0], found[1], heading))
            search_from = found[1]
    sections: dict[str, str] = {}
    for idx, (_start, end, heading) in enumerate(positions):
        next_start = positions[idx + 1][0] if idx + 1 < len(positions) else len(lines)
        body = "\n".join(lines[end:next_start])
        sections[heading] = body
    return sections
