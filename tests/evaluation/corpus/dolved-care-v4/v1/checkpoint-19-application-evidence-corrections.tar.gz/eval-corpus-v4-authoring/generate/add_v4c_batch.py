"""Incrementally add a batch of V4-C documents to source-manifest.json and
document-family-plan.json. Designed to be run once per V4-C batch (unlike
build_v4b.py which ran once for the whole tranche), so V4-C can be built
and checkpointed in stages. Idempotent guard: refuses to re-add a
(family_id, version_id) that already exists in the manifest.
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import render  # noqa: E402

ROOT = render.ROOT


def add_batch(new_docs, planned_version_counts=None):
    """planned_version_counts: optional {family_id: int} for NEW families
    not already in document-family-plan.json. Existing families' planned
    count is read from the existing plan entry."""
    manifest_path = ROOT / "source-manifest.json"
    plan_path = ROOT / "document-family-plan.json"

    manifest = json.loads(manifest_path.read_text())
    existing_docs = manifest["documents"]
    existing_fam_ver = {(d["family_id"], d["version_id"]) for d in existing_docs}
    existing_fns = {d["filename"] for d in existing_docs}

    new_ids = [(d["family_id"], d["version_id"]) for d in new_docs]
    dup_within = [x for x in new_ids if new_ids.count(x) > 1]
    assert not dup_within, f"duplicate (family,version) within this batch: {set(dup_within)}"
    collisions = set(new_ids) & existing_fam_ver
    assert not collisions, f"V4-C batch collides with existing manifest (family,version): {collisions}"
    new_fns = [d["filename"] for d in new_docs]
    fn_collisions = set(new_fns) & existing_fns
    assert not fn_collisions, f"V4-C batch collides with existing filenames: {fn_collisions}"

    new_entries = []
    for doc in new_docs:
        entry = render.build_one(doc, tranche="V4-C")
        entry["version_change_type"] = doc.get("version_change_type")
        new_entries.append(entry)
        print(f"built {doc['family_id']}::{doc['version_id']} -> {entry['artefact_path']}")

    combined_documents = existing_docs + new_entries
    manifest["document_count"] = len(combined_documents)
    manifest["documents"] = combined_documents
    if "V4-C" not in manifest.get("tranche_history", []):
        manifest.setdefault("tranche_history", []).append("V4-C")
    manifest["tranche"] = "V4-C"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    # Update document-family-plan.json
    plan = json.loads(plan_path.read_text())
    families_by_id = {f["family_id"]: f for f in plan["families"]}

    from collections import defaultdict
    by_family = defaultdict(list)
    for doc in new_docs:
        by_family[doc["family_id"]].append(doc)

    for fam_id, docs in by_family.items():
        sample = docs[0]
        newly_built_versions = sorted(d["version_id"] for d in docs)
        if fam_id in families_by_id:
            fam = families_by_id[fam_id]
            built = set(fam.get("versions_built_this_session", [])) | set(newly_built_versions)
            fam["versions_built_this_session"] = sorted(built)
            ta = fam.get("tranche_assignment", {})
            for v in newly_built_versions:
                ta[v] = "V4-C"
            ta.pop("remaining", None)
            fam["tranche_assignment"] = ta
            vct = set(fam.get("version_change_types", []))
            vct |= {d.get("version_change_type") for d in docs}
            fam["version_change_types"] = sorted(x for x in vct if x)
        else:
            planned_count = (planned_version_counts or {}).get(fam_id, len(newly_built_versions))
            families_by_id[fam_id] = {
                "family_id": fam_id,
                "family_title": sample["family_title"],
                "domain": sample["domain"],
                "planned_version_count": planned_count,
                "tranche_assignment": {v: "V4-C" for v in newly_built_versions},
                "versions_built_this_session": newly_built_versions,
                "version_change_types": sorted({d.get("version_change_type") for d in docs if d.get("version_change_type")}),
                "born_in_tranche": "V4-C",
            }

    plan["families"] = list(families_by_id.values())
    plan["tranches"]["V4-C"]["status"] = "built_this_session"
    plan["tranches"]["V4-C"]["actual_versions"] = plan["tranches"]["V4-C"].get("actual_versions", 0) + len(new_entries)
    plan_path.write_text(json.dumps(plan, indent=2), encoding="utf-8")

    print(f"\nBatch done. {len(new_entries)} new documents built. Manifest total: {len(combined_documents)}.")
    return new_entries
