"""Canonical aggregate for the application-pipeline source-and-lock file set.

Definition (recorded identically in authoring-governance/runtime-contract.json):

  1. sort records by exact repository-relative UTF-8 path (POSIX separators);
  2. represent each record as: <path><NUL><lowercase-sha256><LF>
     i.e. UTF-8 path bytes, then a single 0x00 byte, then the 64 lowercase
     hex characters of that file's own SHA-256, then a single 0x0A byte;
  3. concatenate every record's bytes in sorted order, with no extra
     prefix, suffix, or platform newline conversion (the file is always
     opened in binary mode and the LF is a literal 0x0A, never CRLF);
  4. the aggregate is the SHA-256 of that exact concatenated byte stream.

This is read-only against the main repository (never modifies it) and is
used only to produce corpus-authoring governance evidence; it is not
evaluation material.
"""
import hashlib
import json
import sys
from pathlib import Path

SOURCE_AND_LOCK_RELATIVE_PATHS = [
    "app/chunking/__init__.py",
    "app/chunking/baseline.py",
    "app/chunking/errors.py",
    "app/chunking/models.py",
    "app/chunking/protocol.py",
    "app/chunking/tokenizer.py",
    "app/extraction/__init__.py",
    "app/extraction/docx/__init__.py",
    "app/extraction/docx/factory.py",
    "app/extraction/docx/protocol.py",
    "app/extraction/docx/python_docx.py",
    "app/extraction/errors.py",
    "app/extraction/limits.py",
    "app/extraction/models.py",
    "app/extraction/pdf/__init__.py",
    "app/extraction/pdf/factory.py",
    "app/extraction/pdf/pdfplumber.py",
    "app/extraction/pdf/protocol.py",
    "app/extraction/plain_text.py",
    "app/normalisation/__init__.py",
    "app/normalisation/artifact.py",
    "app/normalisation/models.py",
    "app/normalisation/structural.py",
    "pyproject.toml",
    "uv.lock",
]


def compute(apps_ai_root: Path):
    paths = sorted(SOURCE_AND_LOCK_RELATIVE_PATHS)
    records = []
    payload = bytearray()
    for rel in paths:
        data = (apps_ai_root / rel).read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        records.append({"path": rel, "sha256": digest})
        payload += rel.encode("utf-8") + b"\x00" + digest.encode("utf-8") + b"\x0a"
    aggregate = hashlib.sha256(bytes(payload)).hexdigest()
    return records, aggregate, bytes(payload)


def main() -> int:
    apps_ai_root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(
        "/Users/davidoliver/Desktop/RAG/apps/ai"
    )
    records, aggregate, _ = compute(apps_ai_root)
    print(json.dumps({"records": records, "aggregate_sha256": aggregate, "file_count": len(records)}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
