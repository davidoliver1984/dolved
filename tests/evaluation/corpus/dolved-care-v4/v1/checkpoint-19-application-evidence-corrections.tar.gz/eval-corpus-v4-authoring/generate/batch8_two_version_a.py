"""V4-B batch 8: ten two-version families (20 docs).
Version-change types: one_word_substantial, added_removed_clause,
reordered_sections, renamed_heading, changed_effective_date_and_numeric_limit."""

DOCS = [
# --- 1. one_word_substantial: "may" -> "must" ---
{
    "family_id": "v4b.hr.dbs-renewal-procedure", "family_title": "DBS Renewal Procedure",
    "version_id": "v1", "version_change_type": "mandatory_registration_with_consequential_rewrite",
    "domain": "hr", "content_type": "policy",
    "human_title": "DBS Renewal Procedure", "filename": "dbs-renewal-procedure-v1.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2024-06-01", "superseded_date": "2026-01-01",
    "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Renewal cycle", "Enhanced DBS checks are renewed every 3 years. Staff may register with the DBS Update Service to allow faster status checks between renewals."),
        ("Responsibility", "HR tracks renewal dates and notifies the registered manager 8 weeks before a certificate is due to expire."),
    ],
},
{
    "family_id": "v4b.hr.dbs-renewal-procedure", "family_title": "DBS Renewal Procedure",
    "version_id": "v2", "version_change_type": "mandatory_registration_with_consequential_rewrite",
    "domain": "hr", "content_type": "policy",
    "human_title": "DBS Renewal Procedure", "filename": "dbs-renewal-procedure-v2.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2026-01-01", "messiness_level": "clean", "messiness_axes": [],
    "front_matter": "Supersedes the version effective 1 June 2024. Single substantive change: 'may register' becomes 'must register'.",
    "sections": [
        ("Renewal cycle", "Enhanced DBS checks are renewed every 3 years. Staff must register with the DBS Update Service to allow faster status checks between renewals — this is now a requirement, not an option."),
        ("Responsibility", "HR tracks renewal dates and notifies the registered manager 8 weeks before a certificate is due to expire."),
    ],
},
# --- 2. added_removed_clause ---
{
    "family_id": "v4b.hr.agency-staff-usage-policy", "family_title": "Agency Staff Usage Policy",
    "version_id": "v1", "version_change_type": "added_removed_clause",
    "domain": "hr", "content_type": "policy",
    "human_title": "Agency Staff Usage Policy", "filename": "agency-staff-usage-policy-v1.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-01-01", "superseded_date": "2026-02-01",
    "messiness_level": "mild", "messiness_axes": ["abbreviation_heavy"],
    "sections": [
        ("Booking agency staff", "Agency staff may only be booked through the two approved framework agencies, and must have a current DBS check and mandatory training confirmed before their first shift."),
        ("Induction", "Agency staff receive a shortened site induction covering fire safety, safeguarding contacts and medication boundaries."),
    ],
},
{
    "family_id": "v4b.hr.agency-staff-usage-policy", "family_title": "Agency Staff Usage Policy",
    "version_id": "v2", "version_change_type": "added_removed_clause",
    "domain": "hr", "content_type": "policy",
    "human_title": "Agency Staff Usage Policy", "filename": "agency-staff-usage-policy-v2.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2026-02-01", "messiness_level": "mild", "messiness_axes": ["abbreviation_heavy"],
    "front_matter": "Supersedes the version effective 1 January 2025. Adds a new clause on agency staff medication restrictions; removes the prior clause permitting verbal booking confirmation.",
    "sections": [
        ("Booking agency staff", "Agency staff may only be booked through the two approved framework agencies, and must have a current DBS check and mandatory training confirmed before their first shift. All bookings must now be confirmed in writing by email; the previous allowance for verbal telephone confirmation in urgent cases has been removed."),
        ("Induction", "Agency staff receive a shortened site induction covering fire safety, safeguarding contacts and medication boundaries."),
        ("New: medication restriction", "Agency staff must never administer controlled drugs, even if qualified to do so at their home organisation, unless they have completed Alderbridge's own controlled drugs competency check."),
    ],
},
# --- 3. reordered_sections (unchanged meaning) ---
{
    "family_id": "v4b.hs.legionella-control-procedure", "family_title": "Legionella Control Procedure",
    "version_id": "v1", "version_change_type": "reordered_sections",
    "domain": "health-safety", "content_type": "policy",
    "human_title": "Legionella Control Procedure", "filename": "legionella-control-procedure-v1.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-03-01", "superseded_date": "2026-03-01",
    "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Water temperature monitoring", "Hot water outlets are checked monthly to confirm they reach 50°C within one minute at the tap. Cold water outlets are checked to confirm they remain below 20°C."),
        ("Flushing of little-used outlets", "Any outlet unused for more than a week is flushed for at least 2 minutes to prevent stagnation."),
        ("Responsibility", "The Facilities Lead maintains the legionella risk assessment and monitoring log for every site."),
    ],
},
{
    "family_id": "v4b.hs.legionella-control-procedure", "family_title": "Legionella Control Procedure",
    "version_id": "v2", "version_change_type": "reordered_sections",
    "domain": "health-safety", "content_type": "policy",
    "human_title": "Legionella Control Procedure", "filename": "legionella-control-procedure-v2.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2026-03-01", "messiness_level": "clean", "messiness_axes": [],
    "front_matter": "Supersedes the version effective 1 March 2025. Sections reordered for readability; no requirement changed.",
    "sections": [
        ("Responsibility", "The Facilities Lead maintains the legionella risk assessment and monitoring log for every site."),
        ("Water temperature monitoring", "Hot water outlets are checked monthly to confirm they reach 50°C within one minute at the tap. Cold water outlets are checked to confirm they remain below 20°C."),
        ("Flushing of little-used outlets", "Any outlet unused for more than a week is flushed for at least 2 minutes to prevent stagnation."),
    ],
},
# --- 4. renamed_heading ---
{
    "family_id": "v4b.medication.homely-remedies-policy", "family_title": "Homely Remedies Policy",
    "version_id": "v1", "version_change_type": "renamed_heading",
    "domain": "medication", "content_type": "policy",
    "human_title": "Homely Remedies Policy", "filename": "homely-remedies-policy-v1.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-02-01", "superseded_date": "2026-02-01",
    "messiness_level": "mild", "messiness_axes": ["late_defined_term"],
    "sections": [
        ("Over the counter medicines", "A limited list of over-the-counter remedies (paracetamol, antacid, simple cough syrup) may be given without a prescription, recorded on the MAR chart, subject to the person's care plan not excluding it."),
    ],
},
{
    "family_id": "v4b.medication.homely-remedies-policy", "family_title": "Homely Remedies Policy",
    "version_id": "v2", "version_change_type": "renamed_heading",
    "domain": "medication", "content_type": "policy",
    "human_title": "Homely Remedies Policy", "filename": "homely-remedies-policy-v2.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2026-02-01", "messiness_level": "mild", "messiness_axes": ["late_defined_term"],
    "front_matter": "Supersedes the version effective 1 February 2025. Heading renamed from 'Over the counter medicines' to 'Homely remedies list' — the underlying rule is unchanged.",
    "sections": [
        ("Homely remedies list", "A limited list of over-the-counter remedies (paracetamol, antacid, simple cough syrup) may be given without a prescription, recorded on the MAR chart, subject to the person's care plan not excluding it."),
    ],
},
# --- 5. changed_effective_date_and_numeric_limit ---
{
    "family_id": "v4b.payroll.uniform-allowance-guidance", "family_title": "Uniform Allowance Guidance",
    "version_id": "v1", "version_change_type": "changed_effective_date_and_numeric_limit",
    "domain": "payroll", "content_type": "faq_guidance",
    "human_title": "Uniform Allowance Guidance", "filename": "uniform-allowance-guidance-v1.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2024-04-01", "superseded_date": "2026-04-01",
    "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Allowance", "New starters in uniformed roles receive a one-off uniform allowance of £40 in their first month's pay, and a replacement allowance of £25 every April thereafter."),
    ],
},
{
    "family_id": "v4b.payroll.uniform-allowance-guidance", "family_title": "Uniform Allowance Guidance",
    "version_id": "v2", "version_change_type": "changed_effective_date_and_numeric_limit",
    "domain": "payroll", "content_type": "faq_guidance",
    "human_title": "Uniform Allowance Guidance", "filename": "uniform-allowance-guidance-v2.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2026-04-01", "messiness_level": "clean", "messiness_axes": [],
    "front_matter": "Supersedes the version effective 1 April 2024. Allowance amounts increased.",
    "sections": [
        ("Allowance", "New starters in uniformed roles receive a one-off uniform allowance of £55 in their first month's pay, and a replacement allowance of £35 every April thereafter."),
    ],
},
# --- 6. changed_contact_escalation ---
{
    "family_id": "v4b.bcp.gas-safety-procedure", "family_title": "Gas Safety Procedure",
    "version_id": "v1", "version_change_type": "changed_contact_escalation",
    "domain": "health-safety", "content_type": "policy",
    "human_title": "Gas Safety Procedure", "filename": "gas-safety-procedure-v1.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2024-09-01", "superseded_date": "2026-03-01",
    "messiness_level": "mild", "messiness_axes": ["dense_table"],
    "sections": [
        ("Suspected gas leak", "Evacuate the area, do not operate light switches, and call the National Gas Emergency Service on 0800 111 999. Then notify the Facilities Lead on the internal escalation line."),
    ],
},
{
    "family_id": "v4b.bcp.gas-safety-procedure", "family_title": "Gas Safety Procedure",
    "version_id": "v2", "version_change_type": "changed_contact_escalation",
    "domain": "health-safety", "content_type": "policy",
    "human_title": "Gas Safety Procedure", "filename": "gas-safety-procedure-v2.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2026-03-01", "messiness_level": "mild", "messiness_axes": ["dense_table"],
    "front_matter": "Supersedes the version effective 1 September 2024. Internal escalation contact changed from the Facilities Lead to the new 24-hour Estates Helpdesk.",
    "sections": [
        ("Suspected gas leak", "Evacuate the area, do not operate light switches, and call the National Gas Emergency Service on 0800 111 999. Then notify the 24-hour Estates Helpdesk, which has replaced the previous direct line to the Facilities Lead for out-of-hours incidents."),
    ],
},
# --- 7. local_applicability_change ---
{
    "family_id": "v4b.contractors.key-holder-procedure", "family_title": "Key Holder Procedure",
    "version_id": "v1", "version_change_type": "local_applicability_change",
    "domain": "contractors-visitors", "content_type": "policy",
    "human_title": "Key Holder Procedure", "filename": "key-holder-procedure-v1.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "specific",
    "applicability_locations": ["location.region.north-west"],
    "effective_date": "2025-01-01", "superseded_date": "2026-01-01",
    "messiness_level": "mild", "messiness_axes": ["local_vs_regional_variance"],
    "front_matter": "Applies to North West Region sites only.",
    "sections": [
        ("Key holders", "Each North West Region site nominates 2 key holders who may be called by the alarm monitoring company outside of hours."),
    ],
},
{
    "family_id": "v4b.contractors.key-holder-procedure", "family_title": "Key Holder Procedure",
    "version_id": "v2", "version_change_type": "local_applicability_change",
    "domain": "contractors-visitors", "content_type": "policy",
    "human_title": "Key Holder Procedure", "filename": "key-holder-procedure-v2.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2026-01-01", "messiness_level": "mild", "messiness_axes": ["local_vs_regional_variance"],
    "front_matter": "Supersedes the North-West-only version effective 1 January 2025. Applicability extended to all regions following a successful pilot.",
    "sections": [
        ("Key holders", "Each site, in every region, nominates 2 key holders who may be called by the alarm monitoring company outside of hours — extending the arrangement piloted in the North West Region to Midlands and South West."),
    ],
},
# --- 8. formatting_only_honest_gap ---
{
    "family_id": "v4b.hr.staff-handover-procedure", "family_title": "Staff Handover Procedure",
    "version_id": "v1", "version_change_type": "formatting_only_honest_gap",
    "domain": "hr", "content_type": "policy",
    "human_title": "Staff Handover Procedure", "filename": "staff-handover-procedure-v1.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-06-01", "superseded_date": "2026-05-01",
    "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Handover content", "Each shift handover must cover any change in a person's condition, any incident during the shift, any outstanding task, and any visitor or professional attending."),
    ],
},
{
    "family_id": "v4b.hr.staff-handover-procedure", "family_title": "Staff Handover Procedure",
    "version_id": "v2", "version_change_type": "formatting_only_honest_gap",
    "domain": "hr", "content_type": "policy",
    "human_title": "Staff Handover Procedure", "filename": "staff-handover-procedure-v2.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2026-05-01", "messiness_level": "clean", "messiness_axes": [],
    "front_matter": "Supersedes the version effective 1 June 2025. Intended as a formatting-only change (the handover content list was re-set as a bulleted list rather than a single sentence) with no wording change to the underlying requirement.",
    "sections": [
        ("Handover content", "Each shift handover must cover any change in a person's condition, any incident during the shift, any outstanding task, and any visitor or professional attending."),
    ],
},
# --- 9. wording_no_effect ---
{
    "family_id": "v4b.contractors.visitor-parking-guidance", "family_title": "Visitor Parking Guidance",
    "version_id": "v1", "version_change_type": "wording_no_effect",
    "domain": "contractors-visitors", "content_type": "faq_guidance",
    "human_title": "Visitor Parking Guidance", "filename": "visitor-parking-guidance-v1.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-05-01", "superseded_date": "2026-05-01",
    "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Parking", "Visitors should use the marked visitor bays near the main entrance and should not park in bays reserved for staff or blue badge holders."),
    ],
},
{
    "family_id": "v4b.contractors.visitor-parking-guidance", "family_title": "Visitor Parking Guidance",
    "version_id": "v2", "version_change_type": "wording_no_effect",
    "domain": "contractors-visitors", "content_type": "faq_guidance",
    "human_title": "Visitor Parking Guidance", "filename": "visitor-parking-guidance-v2.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2026-05-01", "messiness_level": "clean", "messiness_axes": [],
    "front_matter": "Supersedes the version effective 1 May 2025. Wording tidied for tone; the rule itself is unchanged.",
    "sections": [
        ("Parking", "Please park in one of the marked visitor bays close to the main entrance. Staff and blue badge bays are reserved and should be left clear for their intended users."),
    ],
},
# --- 10. scheduled_successor ---
{
    "family_id": "v4b.payroll.expenses-mileage-rate-schedule", "family_title": "Mileage Rate Schedule",
    "version_id": "v1", "version_change_type": "scheduled_successor",
    "domain": "payroll", "content_type": "schedule_reference",
    "human_title": "Mileage Rate Schedule", "filename": "mileage-rate-schedule-v1.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-04-01", "messiness_level": "mild", "messiness_axes": ["dense_table"],
    "sections": [
        ("__table__", [
            ["Vehicle type", "Rate (first 10,000 miles)"],
            ["Car", "45p per mile"],
            ["Motorcycle", "24p per mile"],
            ["Bicycle", "20p per mile"],
        ]),
    ],
},
{
    "family_id": "v4b.payroll.expenses-mileage-rate-schedule", "family_title": "Mileage Rate Schedule",
    "version_id": "v2-scheduled", "version_change_type": "scheduled_successor",
    "domain": "payroll", "content_type": "schedule_reference",
    "human_title": "Mileage Rate Schedule", "filename": "mileage-rate-schedule-v2-scheduled.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2026-10-01", "messiness_level": "mild", "messiness_axes": ["dense_table"],
    "front_matter": "SCHEDULED successor to the version effective 1 April 2025. This version does not become effective, and is not yet authoritative, until 1 October 2026.",
    "sections": [
        ("__table__", [
            ["Vehicle type", "Rate (first 10,000 miles), effective 1 October 2026"],
            ["Car", "48p per mile"],
            ["Motorcycle", "26p per mile"],
            ["Bicycle", "20p per mile"],
        ]),
    ],
},
]
