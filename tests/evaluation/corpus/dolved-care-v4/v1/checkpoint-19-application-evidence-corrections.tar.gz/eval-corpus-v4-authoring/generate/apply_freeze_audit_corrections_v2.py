"""Apply the four remaining Codex re-audit corrections on top of checkpoint 16,
and regenerate every governed artefact and manifest from corrected sources.

This is a one-time correction driver, not a permanent part of the render
pipeline. It supersedes finalize_freeze_candidate.py's RELABELLED_FAMILIES
hack: every source generator script this driver reads from has already been
edited (in this same correction pass) to declare the canonical
version_change_type directly, so this driver's own metadata pass is a
direct reflection of source, not an independent override.

Provider-free, local-only, idempotent.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import render  # noqa: E402
from apply_expansions import apply_expansions  # noqa: E402
import batch13_two_version_f  # noqa: E402
import expand_medium_d1_pair_3chunk  # noqa: E402
import expand_medium_d3_pair_3chunk  # noqa: E402
import expand_medium_d4_pair_3chunk  # noqa: E402
import finalize_freeze_candidate as ffc  # noqa: E402

ROOT = render.ROOT


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------------
# Step 1: version_change_type canonicalisation, mirroring exactly the edits
# already applied to the generate/*.py source scripts in this correction pass.
# ---------------------------------------------------------------------------

V1_OPENER_LEGACY = {"new_family_v1_of_3", "three_version_family_v1_of_3", "new_family_v1_of_4"}

RELABELLED_FAMILIES_FINAL = {
    "v4b.care.continence-care-policy": "tightened_requirement_with_broader_section_rewrite",
    "v4b.facilities.ladder-stepladder-use-guidance": "tightened_permission_with_consequential_rewrite",
    "v4b.hr.dbs-renewal-procedure": "mandatory_registration_with_consequential_rewrite",
    "v4b.hr.right-to-work-checks-procedure": "mandatory_precondition_with_consequential_rewrite",
    "v4b.training.induction-buddy-scheme-guidance": "mandatory_assignment_with_consequential_rewrite",
}

ONE_OFF_TO_CANONICAL = "added_section_with_declared_consequential_scope"
ONE_OFF_LEGACY_VALUES = {
    "added_annual_health_safety_report_appendix", "added_antimicrobial_stewardship_section",
    "added_bank_holiday_rate_and_tightened_authorisation", "added_barrier_system_and_tightened_temperature",
    "added_check_in_and_extended_eligibility", "added_clause_and_tightened_reporting", "added_clauses",
    "added_controlled_drugs_reconciliation_appendix", "added_cyber_and_data_backup_summary",
    "added_emergency_override_clause", "added_engagement_plan_reference",
    "added_equipment_specific_signoff_and_quarantine_process", "added_error_severity_appendix",
    "added_external_benchmarking", "added_fast_track_and_removed_discretion",
    "added_financial_abuse_agency_route", "added_flexible_working_and_regional_structure_section",
    "added_flexible_working_and_toil_reference", "added_immutable_backup_and_rpo",
    "added_information_sharing_appendix_and_terminology_alignment",
    "added_insurance_notification_and_board_co_approval", "added_lone_working_and_asbestos_summary",
    "added_man_down_alert_and_escalation_protocol", "added_nursing_care_registration",
    "added_nursing_care_section", "added_outbreak_decision_tree_appendix",
    "added_pandemic_and_supply_chain_annex", "added_peer_observation_and_portfolio",
    "added_peer_review_between_sites", "added_pin_release_requirement",
    "added_prevention_checklist_and_contractor_review", "added_regional_contact_section",
    "added_regional_liaison_and_review_appendix", "added_regional_structure",
    "added_regional_structure_reference", "added_religious_accommodation_and_footwear_clause",
    "added_reporting_requirement_and_tightened_kitchen_frequency", "added_resident_experience_indicator",
    "added_revalidation_and_new_specialist_competency", "added_severe_weather_and_regional_mutual_aid",
    "added_severity_appendix_and_aligned_escalation", "added_toil_option",
    "added_tracking_log_and_ppe_protocol", "added_weight_check_and_tightened_inspection",
    "added_wellbeing_and_benefits_summary_section", "added_wellbeing_benefits_reference",
    "digitised_records_and_added_clause", "expanded_severity_tiers_and_tightened_notification",
    "expanded_suite_and_added_appendix", "extended_pin_release_and_added_end_of_life_wipe",
    "tightened_numeric_limit_and_added_clause", "tightened_test_frequency_and_added_rto",
    "updated_involvement_process_after_cqc_feedback",
}


def canonicalise_version_change_types(manifest: dict) -> int:
    changed = 0
    for entry in manifest["documents"]:
        current = entry.get("version_change_type")
        if current == "one_word_substantial":
            fam = entry["family_id"]
            new_value = None if entry["version_id"] == "v1" else RELABELLED_FAMILIES_FINAL[fam]
            if entry.get("version_change_type") != new_value:
                entry["version_change_type"] = new_value
                changed += 1
        elif current in V1_OPENER_LEGACY:
            entry["version_change_type"] = None
            changed += 1
        elif current in ONE_OFF_LEGACY_VALUES:
            entry["version_change_type"] = ONE_OFF_TO_CANONICAL
            changed += 1
    return changed


# ---------------------------------------------------------------------------
# Step 2: rebuild the medication fridge-breakdown family from its corrected
# source (batch13's fixed "If the fridge fails" text), then reapply the
# realism-additions overlay exactly as finalize_freeze_candidate.py does.
# ---------------------------------------------------------------------------

def rebuild_fridge_breakdown(manifest: dict) -> None:
    by_key = {(d["family_id"], d["version_id"]): d for d in manifest["documents"]}
    for doc in batch13_two_version_f.DOCS:
        if doc["family_id"] != "v4b.medication.fridge-breakdown-procedure":
            continue
        key = (doc["family_id"], doc["version_id"])
        entry = by_key[key]
        full_doc = dict(doc)
        full_doc["tranche"] = entry["tranche"]
        new_entry = render.build_one(full_doc, tranche=entry["tranche"])
        new_entry["version_change_type"] = entry.get("version_change_type")
        by_key[key] = new_entry
        print(f"rebuilt base master for {key[0]}::{key[1]}")

    manifest["documents"] = [by_key[(d["family_id"], d["version_id"])] for d in manifest["documents"]]

    # Reapply the realism-additions overlay on top of the freshly-rebuilt base.
    additions = ffc.REALISM_ADDITIONS["v4b.medication.fridge-breakdown-procedure"]
    family_dir = ROOT / "semantic-masters" / "v4b.medication.fridge-breakdown-procedure"
    for master in sorted(family_dir.glob("*.md")):
        ffc.replace_realism_sections(master, additions)
        print(f"reapplied realism-additions overlay to {master.relative_to(ROOT)}")

    # Rerender every artefact for this family from the now-final master text.
    by_key = {(d["family_id"], d["version_id"]): d for d in manifest["documents"]}
    for version_id in ("v1", "v2"):
        key = ("v4b.medication.fridge-breakdown-procedure", version_id)
        entry = by_key[key]
        master_path = ROOT / entry["semantic_master_path"]
        doc = ffc.master_to_doc(entry, master_path, "Alderbridge Care Group")
        md = master_path.read_text(encoding="utf-8")
        fmt = entry["format"]
        data = {"pdf": render.render_pdf, "docx": render.render_docx,
                "txt": lambda d: render.render_txt(d, md)}[fmt](doc)
        artefact = ROOT / entry["artefact_path"]
        artefact.write_bytes(data)
        entry["sha256"] = hashlib.sha256(data).hexdigest()
        entry["byte_count"] = len(data)
        entry["renderer_tool"] = render.RENDERER_VERSION[fmt]
        entry["renderer_version"] = render.RENDERER_LIBRARY_VERSION[fmt]
        entry["word_count_approx"] = len(render.markdown_to_plaintext(md).split())
        print(f"rerendered final artefact for {key[0]}::{key[1]} ({fmt}, {entry['byte_count']} bytes)")


# ---------------------------------------------------------------------------
# Step 3: restore the unrelated sections in the three remaining families via
# the existing apply_expansions() tool, now that their source DOCS lists
# have been corrected to include the previously-dropped sections.
# ---------------------------------------------------------------------------

def restore_unrelated_sections() -> None:
    apply_expansions([
        expand_medium_d1_pair_3chunk,
        expand_medium_d3_pair_3chunk,
        expand_medium_d4_pair_3chunk,
    ])


# ---------------------------------------------------------------------------
# Step 4: backfill renderer_version onto every entry not already covered by
# a full rebuild above (the vast majority of the corpus, whose bytes are not
# otherwise changing) by keying off the already-correct renderer_tool.
# ---------------------------------------------------------------------------

TOOL_TO_LIBRARY_VERSION = {
    "v4-authoring-txt-renderer-1.0": "cpython-3.13.7",
    "python-docx-render-1.0": "python-docx-1.2.0",
    "reportlab-render-1.0": "reportlab-5.0.1",
}


def backfill_renderer_version(manifest: dict) -> int:
    n = 0
    for entry in manifest["documents"]:
        if "renderer_version" in entry:
            continue
        tool = entry.get("renderer_tool")
        if tool in TOOL_TO_LIBRARY_VERSION:
            entry["renderer_version"] = TOOL_TO_LIBRARY_VERSION[tool]
            n += 1
    return n


def main() -> None:
    manifest_path = ROOT / "source-manifest.json"
    manifest = read_json(manifest_path)

    n_relabelled = canonicalise_version_change_types(manifest)
    print(f"Canonicalised version_change_type on {n_relabelled} manifest entries.")

    rebuild_fridge_breakdown(manifest)

    n_rv = backfill_renderer_version(manifest)
    print(f"Backfilled renderer_version on {n_rv} manifest entries not otherwise rebuilt.")

    write_json(manifest_path, manifest)

    restore_unrelated_sections()

    # Re-load and backfill renderer_version again for the 3 just-restored
    # families (apply_expansions() calls render.build_one(), which already
    # sets renderer_version natively — this is a no-op safety net).
    manifest = read_json(manifest_path)
    n_rv2 = backfill_renderer_version(manifest)
    if n_rv2:
        write_json(manifest_path, manifest)
        print(f"Backfilled renderer_version on {n_rv2} additional entries after restoration.")

    # Extend renderer_version to the two auxiliary packs.
    for pack_dir in ("foreign-tenant", "prompt-injection-pack"):
        pack_manifest_path = ROOT / pack_dir / "source-manifest.json"
        pack_manifest = read_json(pack_manifest_path)
        n = backfill_renderer_version(pack_manifest)
        if n:
            write_json(pack_manifest_path, pack_manifest)
        print(f"{pack_dir}: backfilled renderer_version on {n} entries.")

    print("\nFreeze-audit correction pass (round 2) complete.")


if __name__ == "__main__":
    main()
