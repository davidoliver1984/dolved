"""Content-depth expansion helpers. Takes an existing document's real,
already-authored core facts and assembles a realistically structured,
substantially longer document around them — never generic filler repeated
verbatim across documents. Every section below is written to consume
document-specific facts supplied by the caller (see expand_batch_*.py).
"""

APPROVAL_HISTORY_TEMPLATE = (
    "This document was originally approved by {approver} on {approved_date} "
    "and is scheduled for its next full review on {review_date}. Version "
    "history and superseded wording are held by the Quality Team and are "
    "available on request; this current version reflects all agreed "
    "amendments up to the effective date on the front of this document."
)

RECORD_RETENTION_TEMPLATE = (
    "Records created under this {doc_kind} are retained in line with the "
    "Records Retention Schedule. {specific_retention}"
)

MONITORING_TEMPLATE = (
    "Compliance with this {doc_kind} is monitored through {monitoring_mechanism}. "
    "Findings are reported to {reporting_body} at {reporting_frequency}, and any "
    "recurring gap is escalated as an action on the site's own improvement plan "
    "rather than treated as a one-off correction."
)


def build_purpose_scope(title: str, purpose: str, scope: str) -> tuple[str, str]:
    return (
        "Purpose and scope",
        f"{purpose} This {('policy' if 'Policy' in title or 'Procedure' in title else 'document')} "
        f"applies to {scope}. It sits alongside, and does not replace, professional "
        "judgement in an individual situation — where this document and a person's "
        "individual care or support plan appear to conflict, the more person-specific "
        "plan is followed and the conflict is reported to the registered manager so "
        "the underlying document can be reviewed."
    )


def build_definitions(defs: list[tuple[str, str]]) -> tuple[str, str]:
    lines = [f"**{term}**: {meaning}" for term, meaning in defs]
    body = " ".join(lines)
    return ("Definitions", body)


def build_roles(roles: list[tuple[str, str]]) -> tuple[str, str]:
    lines = [f"**{role}** {duty}" for role, duty in roles]
    body = " ".join(lines)
    return ("Roles and responsibilities", body)


def build_procedure(steps: list[str]) -> tuple[str, list[str]]:
    return ("__numbered__", steps)


def build_exceptions(exceptions: list[str]) -> tuple[str, str]:
    body = " ".join(exceptions)
    return ("Exceptions and professional judgement", body)


def build_local_variations(text: str) -> tuple[str, str]:
    return ("Local and regional variations", text)


def build_escalation(text: str) -> tuple[str, str]:
    return ("Escalation", text)


def build_monitoring(doc_kind: str, mechanism: str, body_name: str, frequency: str) -> tuple[str, str]:
    text = MONITORING_TEMPLATE.format(
        doc_kind=doc_kind, monitoring_mechanism=mechanism,
        reporting_body=body_name, reporting_frequency=frequency,
    )
    return ("Monitoring and compliance", text)


def build_record_retention(doc_kind: str, specific: str) -> tuple[str, str]:
    text = RECORD_RETENTION_TEMPLATE.format(doc_kind=doc_kind, specific_retention=specific)
    return ("Record keeping and retention", text)


def build_related_documents(related: list[str]) -> tuple[str, str]:
    body = ("This document is read alongside " + ", ".join(related) +
            ". Where any apparent inconsistency is found between this document and "
            "one of those listed, it is reported to the Quality Team for reconciliation "
            "rather than resolved informally by an individual member of staff.")
    return ("Related documents", body)


def build_faq(pairs: list[tuple[str, str]]) -> tuple[str, str]:
    lines = [f"**{q}** {a}" for q, a in pairs]
    body = " ".join(lines)
    return ("Frequently asked questions", body)


def build_approval_history(approver: str, approved_date: str, review_date: str) -> tuple[str, str]:
    text = APPROVAL_HISTORY_TEMPLATE.format(
        approver=approver, approved_date=approved_date, review_date=review_date
    )
    return ("Approval and review history", text)


def build_worked_example(text: str) -> tuple[str, str]:
    return ("Worked example", text)


def build_appendix_table(title: str, rows: list[list[str]]) -> tuple[str, list]:
    return ("__table__", rows)
