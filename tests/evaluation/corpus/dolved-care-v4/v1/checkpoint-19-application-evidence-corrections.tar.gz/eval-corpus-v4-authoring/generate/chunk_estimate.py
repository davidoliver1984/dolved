"""Chunk-count estimation using the REAL configured tokenizer and thresholds
(apps/ai/app/chunking/{tokenizer.py,models.py}): tiktoken o200k_base,
target_tokens=400, max_tokens=512, overlap_tokens=64, preferred_min_tokens=100.

This simulates the token-budget behaviour of BaselineStructuralChunker
(apps/ai/app/chunking/baseline.py) closely: each chunk after the first
consumes ~target_tokens of NEW content (overlap tokens are prepended context,
not new-content budget); a final remainder below preferred_min_tokens is
merged into the previous chunk rather than becoming its own tiny chunk.

This is NOT a full re-implementation of the heading/table-aware structural
splitting logic (that requires the real NormalisedDocument pipeline, which
needs Python >=3.14 and the full apps/ai dependency set — impractical to
stand up here). It uses the real tokenizer and the real configured
thresholds, which is what determines chunk COUNT for prose-heavy content;
it may differ from the true structural chunker by at most one chunk at a
heading/table boundary.
"""
import tiktoken

TARGET_TOKENS = 400
MAX_TOKENS = 512
OVERLAP_TOKENS = 64
PREFERRED_MIN_TOKENS = 100

_enc = tiktoken.get_encoding("o200k_base")


def token_count(text: str) -> int:
    return len(_enc.encode(text))


def estimate_chunks(text: str) -> int:
    tokens = token_count(text)
    if tokens <= TARGET_TOKENS:
        return 1
    n_chunks = 1
    remaining = tokens - TARGET_TOKENS
    while remaining > 0:
        if remaining <= PREFERRED_MIN_TOKENS:
            # merged into the previous chunk rather than forming a tiny final chunk
            break
        n_chunks += 1
        remaining -= TARGET_TOKENS
    return n_chunks


def bucket(n_chunks: int) -> str:
    if n_chunks == 1:
        return "1"
    if 2 <= n_chunks <= 3:
        return "2-3"
    if 4 <= n_chunks <= 8:
        return "4-8"
    return "9+"
