"""Build the per-comparison version-diff contract for every adjacent version
pair in the primary manifest, from REAL EXTRACTED ARTEFACT TEXT (the actual
rendered PDF/DOCX/TXT bytes, via the declared extractor for each format) —
not from semantic-master markdown structure.

This is corpus-authoring governance evidence, not evaluation material: it
records, for each of the 115 adjacent comparisons, exactly which sections
are allowed to differ, a normalized-content digest per protected section, a
declared core-change (exact section + required before/after phrase) for the
types that have one, and full-document digests computed from the same real
extraction the fidelity validator itself will use. It must not be read by,
or moved into, any evaluation-question-authoring input path.
"""
import difflib
import hashlib
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import extract_artefact_text as ex  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]

ADMIN_HEADINGS = {"Approval and review history", "Closing note"}

CORE_CHANGE_TYPES = {
    "tightened_requirement_with_broader_section_rewrite",
    "tightened_permission_with_consequential_rewrite",
    "mandatory_registration_with_consequential_rewrite",
    "mandatory_precondition_with_consequential_rewrite",
    "mandatory_assignment_with_consequential_rewrite",
    "changed_effective_date_and_numeric_limit",
    "changed_contact_escalation",
    "wording_no_effect",
}

# Manual override for the 5 explicitly-named broader-semantic families,
# where the exact before/after wording is known precisely from this
# correction round's own review (more reliable than an automated word-diff
# for the specific, load-bearing marker each of these pairs turns on).
MANUAL_CORE_CHANGE: dict[tuple[str, str, str], dict] = {
    ("v4b.care.continence-care-policy", "v1", "v2"): {
        "section": "Policy statement", "before_phrase": "should", "after_phrase": "must",
        "before_must_be_absent_after": True,
        "identity": "advisory-to-mandatory wording change (continence assessment timing)",
    },
    ("v4b.facilities.ladder-stepladder-use-guidance", "v1", "v2"): {
        "section": "Policy statement", "before_phrase": "can use", "after_phrase": "must only use",
        "before_must_be_absent_after": True,
        "identity": "permission narrowed from 'can' to 'must only'",
    },
    ("v4b.hr.dbs-renewal-procedure", "v1", "v2"): {
        "section": "Policy statement", "before_phrase": "able to register",
        "after_phrase": "staff must register", "before_must_be_absent_after": True,
        "identity": "DBS Update Service registration made mandatory",
    },
    ("v4b.hr.right-to-work-checks-procedure", "v1", "v2"): {
        "section": "Policy statement", "before_phrase": "hr should check",
        "after_phrase": "hr must check", "before_must_be_absent_after": True,
        "identity": "advisory-to-mandatory wording change (right-to-work check timing)",
    },
    ("v4b.training.induction-buddy-scheme-guidance", "v1", "v2"): {
        "section": "Policy statement", "before_phrase": "should be assigned",
        "after_phrase": "must be assigned", "before_must_be_absent_after": True,
        "identity": "buddy assignment made mandatory",
    },
}


def parse_headings(md_text: str) -> list[str]:
    md_text = re.sub(r"^<!--.*?-->\n", "", md_text)
    return re.findall(r"^## (.+)$", md_text, flags=re.MULTILINE)


def sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def auto_core_change(section: str, before_body: str, after_body: str) -> dict | None:
    """Best-effort word-level diff to find the single most significant
    replaced span within a section's normalized before/after text."""
    before_words = ex.normalize(before_body).split()
    after_words = ex.normalize(after_body).split()
    sm = difflib.SequenceMatcher(a=before_words, b=after_words, autojunk=False)
    replace_ops = [op for op in sm.get_opcodes() if op[0] == "replace"]
    if not replace_ops:
        return None
    # pick the longest replace span as the "core" one
    op = max(replace_ops, key=lambda o: (o[2] - o[1]) + (o[4] - o[3]))
    _, i1, i2, j1, j2 = op
    before_phrase = " ".join(before_words[i1:i2])
    after_phrase = " ".join(after_words[j1:j2])
    if not before_phrase or not after_phrase:
        return None
    absent_after = before_phrase.lower() not in ex.normalize(after_body).lower()
    return {
        "section": section, "before_phrase": before_phrase, "after_phrase": after_phrase,
        "before_must_be_absent_after": absent_after,
        "identity": "auto-derived word-level diff (longest replaced span)",
    }


def main() -> None:
    manifest = json.loads((ROOT / "source-manifest.json").read_text())
    docs = manifest["documents"]
    by_family = defaultdict(list)
    for d in docs:
        by_family[d["family_id"]].append(d)

    contracts = []
    for fam_id, versions in sorted(by_family.items()):
        if len(versions) < 2:
            continue
        versions_sorted = sorted(versions, key=lambda v: v["version_id"])
        for i in range(len(versions_sorted) - 1):
            a, b = versions_sorted[i], versions_sorted[i + 1]

            headings_a = parse_headings((ROOT / a["semantic_master_path"]).read_text(encoding="utf-8"))
            headings_b = parse_headings((ROOT / b["semantic_master_path"]).read_text(encoding="utf-8"))

            text_a = ex.extract_full_text(ROOT / a["artefact_path"], a["format"])
            text_b = ex.extract_full_text(ROOT / b["artefact_path"], b["format"])
            sec_a = ex.split_into_sections(text_a, headings_a)
            sec_b = ex.split_into_sections(text_b, headings_b)

            set_a, set_b = set(headings_a), set(headings_b)
            added = [h for h in headings_b if h not in set_a]
            removed = [h for h in headings_a if h not in set_b]
            common = [h for h in headings_a if h in set_b]

            changed_common = [h for h in common if ex.normalize(sec_a.get(h, "")) != ex.normalize(sec_b.get(h, ""))]
            changed_non_admin = [h for h in changed_common if h not in ADMIN_HEADINGS]

            # renamed-heading detection: exactly one add + one remove, with
            # highly similar body content, is treated as a rename rather
            # than an independent add/remove pair.
            renamed_headings = []
            if len(added) == 1 and len(removed) == 1:
                old_h, new_h = removed[0], added[0]
                old_body = ex.normalize(sec_a.get(old_h, ""))
                new_body = ex.normalize(sec_b.get(new_h, ""))
                if old_body and new_body:
                    ratio = difflib.SequenceMatcher(a=old_body, b=new_body, autojunk=False).ratio()
                    if ratio > 0.6:
                        renamed_headings = [{"before": old_h, "after": new_h, "body_similarity_ratio": round(ratio, 3)}]

            allowed_changed_sections = sorted(set(added) | set(removed) | set(changed_non_admin))
            protected_sections = sorted(h for h in common if h not in changed_non_admin and h not in ADMIN_HEADINGS)

            order_a = [h for h in headings_a if h in set_b]
            order_b = [h for h in headings_b if h in set_a]
            order_changed = order_a != order_b

            full_norm_a = ex.normalize(text_a)
            full_norm_b = ex.normalize(text_b)
            text_identical = full_norm_a == full_norm_b

            protected_digests = {
                h: {"before": sha(ex.normalize(sec_a.get(h, ""))), "after": sha(ex.normalize(sec_b.get(h, "")))}
                for h in protected_sections
            }

            declared_type = b.get("version_change_type")

            core_change = None
            key = (fam_id, a["version_id"], b["version_id"])
            if key in MANUAL_CORE_CHANGE:
                core_change = MANUAL_CORE_CHANGE[key]
            elif declared_type in CORE_CHANGE_TYPES and allowed_changed_sections:
                candidate_section = "Policy statement" if "Policy statement" in allowed_changed_sections else \
                    next((h for h in allowed_changed_sections if h not in ADMIN_HEADINGS), None)
                if candidate_section and candidate_section in sec_a and candidate_section in sec_b:
                    core_change = auto_core_change(candidate_section, sec_a[candidate_section], sec_b[candidate_section])

            applicability_only = (
                a.get("applicability_scope") != b.get("applicability_scope")
                or a.get("applicability_locations") != b.get("applicability_locations")
            )

            contracts.append({
                "family_id": fam_id,
                "from_version": a["version_id"],
                "to_version": b["version_id"],
                "declared_type": declared_type,
                "added_sections": added,
                "removed_sections": removed,
                "renamed_headings": renamed_headings,
                "allowed_changed_sections": allowed_changed_sections,
                "protected_sections": protected_sections,
                "protected_section_digests": protected_digests,
                "administrative_exempt_sections": sorted(h for h in common if h in ADMIN_HEADINGS),
                "order_changed": order_changed,
                "text_identical": text_identical,
                "digest_before": sha(full_norm_a),
                "digest_after": sha(full_norm_b),
                "applicability_only": applicability_only,
                "applicability_scope_a": a.get("applicability_scope"),
                "applicability_scope_b": b.get("applicability_scope"),
                "applicability_locations_a": a.get("applicability_locations"),
                "applicability_locations_b": b.get("applicability_locations"),
                "core_change": core_change,
                "digest_source": "real rendered artefact text via generate/extract_artefact_text.py "
                                  "(pdfplumber for PDF, python-docx for DOCX, direct read for TXT), "
                                  "not semantic-master markdown",
            })

    out = {
        "schema_version": "v4-version-diff-contract-2",
        "purpose": (
            "Corpus-authoring governance evidence. Records the declared, reviewed "
            "allowed-changed-section set, protected-section digests (from REAL "
            "extracted artefact text, not semantic-master structure), and a "
            "precise core-change (exact section + required before/after phrase) "
            "for every adjacent version comparison in the primary corpus that has "
            "one. Consumed by generate/validate_version_fidelity.py. Not "
            "evaluation material; must not be read by or moved into any "
            "evaluation-question-authoring input path."
        ),
        "comparison_count": len(contracts),
        "comparisons": contracts,
    }
    out_path = ROOT / "authoring-governance" / "version-diff-contracts.json"
    out_path.write_text(json.dumps(out, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Wrote {len(contracts)} per-comparison contracts to {out_path.relative_to(ROOT)}")
    with_core_change = sum(1 for c in contracts if c["core_change"])
    print(f"Comparisons with a declared core_change: {with_core_change}")
    with_rename = sum(1 for c in contracts if c["renamed_headings"])
    print(f"Comparisons with a detected renamed heading: {with_rename}")


if __name__ == "__main__":
    main()
