"""Shared rendering toolchain for Dolved Evaluation Corpus V4 (authoring draft).

Deterministic: given the same document dict, always produces the same
markdown master, .txt, .docx and .pdf bytes. No randomness, no network,
no provider calls.
"""
from __future__ import annotations

import hashlib
import json
import re
import zipfile
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path

from docx import Document as DocxDocument
from docx.shared import Pt
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak,
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

ROOT = Path(__file__).resolve().parents[1]
MASTERS = ROOT / "semantic-masters"
ARTIFACTS = ROOT / "artifacts"
CHECKSUMS = ROOT / "checksums"

RENDERER_VERSION = {
    "txt": "v4-authoring-txt-renderer-1.0",
    "docx": "python-docx-render-1.0",
    "pdf": "reportlab-render-1.0",
}

# The actual installed third-party library version used to produce the
# rendered bytes for each format, distinct from RENDERER_TOOL above (which
# is this repo's own internal script identifier). This is a genuine,
# checkable fact about the toolchain that ran, not a placeholder: it must
# match runtime-contract.json's pinned dependency lock and the real
# installed version reported by `pip freeze` in .corpus-venv. TXT rendering
# uses no third-party library, so its identity is the CPython interpreter
# version itself.
RENDERER_LIBRARY_VERSION = {
    "txt": "cpython-3.13.7",
    "docx": "python-docx-1.2.0",
    "pdf": "reportlab-5.0.1",
}

DEFAULT_BRAND_IDENTITY = "Alderbridge Care Group"
FIXED_DOCUMENT_TIME = datetime(2026, 9, 1, 0, 0, 0, tzinfo=timezone.utc)


def footer_boilerplate(doc: dict) -> str:
    """Return the closed, explicit synthetic tenant footer for this document."""
    brand = doc.get("brand_identity", DEFAULT_BRAND_IDENTITY)
    return f"{brand} | Uncontrolled if printed | Confidential — internal use only"


def _canonicalize_docx(data: bytes) -> bytes:
    """Rewrite an OOXML package with sorted members and fixed ZIP timestamps."""
    source = BytesIO(data)
    target = BytesIO()
    fixed_zip_time = (2026, 1, 1, 0, 0, 0)
    with zipfile.ZipFile(source, "r") as zin, zipfile.ZipFile(
        target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as zout:
        for name in sorted(zin.namelist()):
            info = zipfile.ZipInfo(name, fixed_zip_time)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o600 << 16
            zout.writestr(info, zin.read(name))
    return target.getvalue()


def slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return re.sub(r"-+", "-", text).strip("-")


def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def build_markdown(doc: dict) -> str:
    """Compose the semantic-master markdown from a document dict's sections."""
    lines: list[str] = []
    lines.append(f"<!-- v4-authoring-draft family={doc['family_id']} version={doc['version_id']} -->")
    lines.append(f"# {doc['human_title']}")
    lines.append("")
    fm = doc.get("front_matter")
    if fm:
        lines.append(f"*{fm}*")
        lines.append("")
    for section in doc["sections"]:
        kind = section[0]
        if kind == "__list__":
            _, items = section
            for item in items:
                lines.append(f"- {item}")
            lines.append("")
        elif kind == "__numbered__":
            _, items = section
            for i, item in enumerate(items, 1):
                lines.append(f"{i}. {item}")
            lines.append("")
        elif kind == "__table__":
            _, rows = section
            header = rows[0]
            lines.append("| " + " | ".join(header) + " |")
            lines.append("|" + "|".join(["---"] * len(header)) + "|")
            for row in rows[1:]:
                lines.append("| " + " | ".join(row) + " |")
            lines.append("")
        else:
            heading, body = section
            if heading:
                lines.append(f"## {heading}")
                lines.append("")
            if body:
                lines.append(body)
                lines.append("")
    if doc.get("footer_boilerplate", True):
        lines.append("---")
        lines.append(footer_boilerplate(doc))
    return "\n".join(lines) + "\n"


def markdown_to_plaintext(md: str) -> str:
    text = re.sub(r"<!--.*?-->", "", md)
    text = re.sub(r"^#+\s*", "", text, flags=re.MULTILINE)
    text = text.replace("|", " ")
    text = re.sub(r"^-+\|.*$", "", text, flags=re.MULTILINE)
    return text


def render_txt(doc: dict, md: str) -> bytes:
    return markdown_to_plaintext(md).encode("utf-8")


def render_docx(doc: dict) -> bytes:
    d = DocxDocument()
    style = d.styles["Normal"]
    style.font.size = Pt(11)
    d.core_properties.author = doc.get("brand_identity", DEFAULT_BRAND_IDENTITY)
    d.core_properties.creator = "Dolved V4 deterministic corpus renderer"
    d.core_properties.title = doc["human_title"]
    d.core_properties.created = FIXED_DOCUMENT_TIME
    d.core_properties.modified = FIXED_DOCUMENT_TIME

    if doc.get("presentation_variant") == "formatting-only-v2":
        style.font.name = "Aptos"
        style.font.size = Pt(10)
        d.styles["Title"].font.size = Pt(20)
        d.styles["Heading 1"].font.name = "Aptos Display"

    if doc.get("header_boilerplate"):
        section = d.sections[0]
        header = section.header
        header.paragraphs[0].text = doc.get("header_boilerplate", "")

    d.add_heading(doc["human_title"], level=0)
    if doc.get("front_matter"):
        p = d.add_paragraph(doc["front_matter"])
        p.italic = True

    for section in doc["sections"]:
        kind = section[0]
        if kind == "__list__":
            _, items = section
            for item in items:
                d.add_paragraph(item, style="List Bullet")
        elif kind == "__numbered__":
            _, items = section
            for item in items:
                d.add_paragraph(item, style="List Number")
        elif kind == "__table__":
            _, rows = section
            table = d.add_table(rows=len(rows), cols=len(rows[0]))
            table.style = "Light Grid Accent 1"
            for r, row in enumerate(rows):
                for c, cell in enumerate(row):
                    table.cell(r, c).text = cell
        else:
            heading, body = section
            level = doc.get("heading_level_override", 1)
            if heading:
                d.add_heading(heading, level=level)
            if body:
                d.add_paragraph(body)

    if doc.get("footer_boilerplate", True):
        section = d.sections[0]
        footer = section.footer
        footer.paragraphs[0].text = footer_boilerplate(doc)

    buf = BytesIO()
    d.save(buf)
    return _canonicalize_docx(buf.getvalue())


def render_pdf(doc: dict) -> bytes:
    buf = BytesIO()

    def _footer(canvas, pdfdoc):
        canvas.saveState()
        canvas.setAuthor(doc.get("brand_identity", DEFAULT_BRAND_IDENTITY))
        canvas.setCreator("Dolved V4 deterministic corpus renderer")
        canvas.setTitle(doc["human_title"])
        canvas.setSubject("Fictional evaluation corpus document")
        canvas.setFont("Helvetica", 7)
        canvas.drawString(20 * mm, 12 * mm, footer_boilerplate(doc))
        canvas.drawRightString(190 * mm, 12 * mm, f"Page {pdfdoc.page}")
        canvas.restoreState()

    pdfdoc = SimpleDocTemplate(
        buf, pagesize=A4,
        topMargin=22 * mm, bottomMargin=22 * mm,
        leftMargin=20 * mm, rightMargin=20 * mm,
        invariant=1,
    )
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("V4Title", parent=styles["Title"], fontSize=16)
    heading_style = ParagraphStyle("V4Heading", parent=styles["Heading2"])
    body_style = styles["BodyText"]

    story = [Paragraph(doc["human_title"], title_style), Spacer(1, 6)]
    if doc.get("front_matter"):
        story.append(Paragraph(f"<i>{doc['front_matter']}</i>", body_style))
        story.append(Spacer(1, 8))

    for section in doc["sections"]:
        kind = section[0]
        if kind == "__list__":
            _, items = section
            for item in items:
                story.append(Paragraph(f"&bull; {item}", body_style))
            story.append(Spacer(1, 6))
        elif kind == "__numbered__":
            _, items = section
            for i, item in enumerate(items, 1):
                story.append(Paragraph(f"{i}. {item}", body_style))
            story.append(Spacer(1, 6))
        elif kind == "__table__":
            _, rows = section
            t = Table(rows, hAlign="LEFT")
            t.setStyle(TableStyle([
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("BACKGROUND", (0, 0), (-1, 0), colors.whitesmoke),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
            ]))
            story.append(t)
            story.append(Spacer(1, 8))
        else:
            heading, body = section
            if heading:
                story.append(Paragraph(heading, heading_style))
            if body:
                story.append(Paragraph(body.replace("\n", "<br/>"), body_style))
            story.append(Spacer(1, 6))

    pdfdoc.build(story, onFirstPage=_footer, onLaterPages=_footer)
    return buf.getvalue()


def build_one(doc: dict, tranche: str) -> dict:
    """Build markdown master + primary artefact for one document. Returns a manifest entry."""
    family_dir = MASTERS / doc["family_id"]
    family_dir.mkdir(parents=True, exist_ok=True)
    md = build_markdown(doc)
    md_path = family_dir / f"{doc['version_id']}.md"
    md_path.write_text(md, encoding="utf-8")

    fmt = doc["format"]
    ARTIFACTS.joinpath(fmt).mkdir(parents=True, exist_ok=True)
    artefact_path = ARTIFACTS / fmt / doc["filename"]

    if fmt == "txt":
        data = render_txt(doc, md)
    elif fmt == "docx":
        data = render_docx(doc)
    elif fmt == "pdf":
        data = render_pdf(doc)
    else:
        raise ValueError(f"unsupported format {fmt}")

    artefact_path.write_bytes(data)
    checksum = hashlib.sha256(data).hexdigest()

    plaintext = markdown_to_plaintext(md)
    word_count = len(plaintext.split())

    return {
        "family_id": doc["family_id"],
        "family_title": doc["family_title"],
        "version_id": doc["version_id"],
        "human_title": doc["human_title"],
        "filename": doc["filename"],
        "domain": doc["domain"],
        "content_type": doc["content_type"],
        "format": fmt,
        "media_type": {"txt": "text/plain",
                        "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        "pdf": "application/pdf"}[fmt],
        "renderer_tool": RENDERER_VERSION[fmt],
        "renderer_version": RENDERER_LIBRARY_VERSION[fmt],
        "governance_status": doc["governance_status"],
        "applicability_scope": doc["applicability_scope"],
        "applicability_locations": doc.get("applicability_locations", []),
        "effective_date": doc.get("effective_date"),
        "superseded_date": doc.get("superseded_date"),
        "messiness_level": doc["messiness_level"],
        "messiness_axes": doc["messiness_axes"],
        "prompt_injection": doc.get("prompt_injection", False),
        "sha256": checksum,
        "byte_count": len(data),
        "word_count_approx": word_count,
        "tranche": tranche,
        "expected_ingestible": True,
        "semantic_master_path": str(md_path.relative_to(ROOT)),
        "artefact_path": str(artefact_path.relative_to(ROOT)),
    }
