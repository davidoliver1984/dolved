"""Generate final authoring documentation from manifests and measured chunks."""
from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("chunk_audit", type=Path)
    args = parser.parse_args()
    audit = load(args.chunk_audit)
    primary_manifest = load(ROOT / "source-manifest.json")
    primary = primary_manifest["documents"]
    foreign = load(ROOT / "foreign-tenant/source-manifest.json")["documents"]
    injections = load(ROOT / "prompt-injection-pack/source-manifest.json")["documents"]
    fixtures = load(ROOT / "negative-fixtures/negative-fixtures-manifest.json")["fixtures"]
    by_family: dict[str, list[dict]] = defaultdict(list)
    for document in primary:
        by_family[document["family_id"]].append(document)
    version_distribution = Counter(len(items) for items in by_family.values())
    formats = Counter(document["format"] for document in primary)
    v4c_formats = Counter(document["format"] for document in primary if document["tranche"] == "V4-C")
    tiers = audit["chunk_tiers"]
    exact = audit["chunk_distribution_exact"]
    chunk_profile = {
        "schema_version": "v4-freeze-chunk-profile-3",
        "pipeline": audit["chunk_configuration"],
        "primary_document_count": len(primary),
        "exact_chunk_count_distribution": exact,
        "tier_distribution": tiers,
        "extraction_warnings": audit["warning_counts"],
        "physical_errors": audit["physical_errors"],
        "measurement_provenance": {
            "status": (
                "Independently reproduced this session by directly running the real "
                "extraction -> structural normalisation -> BaselineStructuralChunker "
                "pipeline inside the precisely identified, already-locally-cached "
                "application image, with networking disabled. Not carried forward, not "
                "estimated, not copied from a supplied expected value."
            ),
            "cached_image_tag": "rag-platform-ai:development",
            "cached_image_id": "sha256:c5ab90de8d23e73d5b6cf78b4987189947957513c5531be8d8db5895e2509202",
            "network_mode": "--network none",
            "date_time_utc": "2026-09-02T11:56:28Z",
            "repository_commit": "f27ff1b1d49b6eb7c555ffce3e278e22ad2eb6a4",
            "full_evidence": "authoring-governance/runtime-contract.json application_pipeline_profile "
                              "(reproduction_run, cached_image_identity, measured_output_evidence_identity)",
        },
        "correction_note": (
            "Supersedes the v4-freeze-chunk-profile-1 distribution (91/42/62/75/30, historical, "
            "predated the restoration of unrelated sections to continence-care-policy, "
            "dbs-renewal-procedure and right-to-work-checks-procedure v2) and the "
            "v4-freeze-chunk-profile-2 distribution (91/42/62/75/30 with a since-corrected "
            "below_preferred_minimum warning count of 22, historical, recorded before this "
            "session's own independent container reproduction). "
            "v4b.care.continence-care-policy::v2 moved from 3 to 4 chunks, and "
            "v4b.hr.staff-supervision-appraisal-policy::v2 moved from 4 to 5 chunks, each as a "
            "direct, expected consequence of a restoration adding back real, load-bearing "
            "content that had been dropped by an earlier expansion/reordering pass. "
            "v4b.facilities.energy-utilities-policy and v4b.care.end-of-life-care-policy, also "
            "corrected this checkpoint, were independently confirmed NOT to shift tier "
            "(3/3 and 4/4 chunks respectively, both versions)."
        ),
    }
    (ROOT / "chunk-profile.json").write_text(
        json.dumps(chunk_profile, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    readme = f"""# Dolved Evaluation Corpus V4 — Corrected Freeze Candidate

**Status: authoring candidate. Not frozen, accepted, calibrated or approved.**

This is fictional benchmark-source material for a later independently authored
evaluation. It contains no evaluation questions, expected answers, relevance
judgements, scoring thresholds or provider outputs.

## Candidate identity

- Internal checkpoint identity: `checkpoint-19-application-evidence-corrections`
  (supersedes `checkpoint-18-archive-and-fidelity-corrections`; checkpoints
  1-18 remain archived unchanged as historical evidence).
- The archive SHA-256 is recorded externally after archive creation because an
  archive cannot truthfully contain its own hash.
- `checksums/checksums.sha256` covers every ordinary archived file except
  itself; the external archive SHA covers the checksum inventory too.
- The archive itself is built by `generate/build_checkpoint_archive.py`, a
  pinned, versioned Python implementation — **not** the system `tar` command.
  Checkpoint 17's archive was found, on raw tar-member inspection (not
  post-extraction filesystem checks), to contain 969 macOS AppleDouble
  (`._*`) sidecar members, a duplicate top-level root directory entry, and
  1715 raw regular-file members instead of 746 — a defect invisible to
  `tar -tzvf`'s own listing and to extraction-based diffing. This checkpoint's
  archive is verified directly against its raw member stream by
  `generate/validate_archive_raw.py`, not only by extracting it.

## Reproducibility contract

`authoring-governance/runtime-contract.json` declares two separate, explicitly
named runtime profiles, because they do not share a dependency set:

- **`corpus_local_profile`** — rendering, local extraction, tokenizer-based
  chunk estimation, corpus validation, and deterministic checkpoint archive
  creation. Fully reconstructible offline from a fully pinned dependency lock
  (`authoring-governance/requirements.lock`). **Byte-reproducible output is
  claimed only under that exact locked runtime and dependency set** run
  against the same source document definitions — this corpus is not
  self-contained and does not vendor its dependencies; the pinned packages
  must be installed first. True PyPI-canonical package hashes were not
  produced (would require a network call); a locally-observed dist-info
  integrity fingerprint is provided instead in
  `authoring-governance/local-dist-info-fingerprints.json`, explicitly
  labelled as not equivalent to a PyPI wheel hash.
- **`application_pipeline_profile`** — the real Dolved application chunking
  pipeline (pydantic-based extraction/normalisation/`BaselineStructuralChunker`)
  that produced the measured chunk profile below. Its dependency stack
  (`pydantic`, `pydantic-core`, and a genuine Python 3.14 language-level
  feature the application source relies on) is explicitly **not** covered by
  `corpus_local_profile`'s lock. This checkpoint **successfully reproduced it**
  inside the precisely identified, already-locally-cached
  `rag-platform-ai:development` image (image ID
  `sha256:c5ab90de8d23e73d5b6cf78b4987189947957513c5531be8d8db5895e2509202`),
  run with `--network none` and the corpus bind-mounted read-only — see that
  profile's `reproduction_run`, `cached_image_identity` and
  `measured_output_evidence_identity` for the full command, image identity
  and result. A prior session's two failed offline reconstruction attempts
  (Python 3.13's missing PEP 649 support; the main repository's own
  pre-release Python 3.14.0rc2's pydantic incompatibility) are retained,
  clearly labelled historical, in `historical_reconstruction_attempts_prior_session`.
  The cached image is not vendored in this archive and must already be
  present in the verifier's own local Docker cache to re-run this
  reproduction; no cross-platform byte reproduction is claimed.

`generate/validate_freeze.py` enforces both profiles' presence and required
sections, that the archive builder is named (not the system `tar` binary),
dependency-lock agreement with the live environment,
`renderer_tool`/`renderer_version` coverage on every governed manifest entry,
independent reconstruction of the application-source aggregate from its own
recorded per-file hashes, and basic documentation/data agreement.

## Final inventory

- {len(primary)} primary versions across {len(by_family)} families.
- Family distribution: {version_distribution[1]} one-version,
  {version_distribution[2]} two-version, {version_distribution[3]}
  three-version and {version_distribution[4]} four-version families.
- Primary formats: {formats['pdf']} PDF, {formats['docx']} DOCX and
  {formats['txt']} TXT.
- V4-C is complete with 75 versions: {v4c_formats['pdf']} PDF,
  {v4c_formats['docx']} DOCX and {v4c_formats['txt']} TXT.
- {len(foreign)} physically separate Thornfield foreign-tenant documents.
- 9 prompt-injection documents: 3 inside the primary corpus and
  {len(injections)} in the separate neutral synthetic-security pack.
- {len(fixtures)} negative/import fixtures, including deliberately corrupt,
  encrypted and unsupported inputs.

## Measured chunk distribution

The real repository extraction/normalisation/chunking pipeline measured:

- one chunk: {tiers['1']}
- exactly two chunks: {tiers['2']}
- exactly three chunks: {tiers['3']}
- four to eight chunks: {tiers['4-8']}
- nine or more chunks: {tiers['9+']}

The complete exact distribution and tokenizer fingerprint are in
`chunk-profile.json`. This measured distribution replaces earlier author
estimates and is not a quota claim.

**Corrected this checkpoint**: this supersedes the prior 91/42/62/75/30
distribution (historical). `v4b.care.continence-care-policy::v2` moved from 3
to 4 chunks, and `v4b.hr.staff-supervision-appraisal-policy::v2` moved from 4
to 5 chunks — each a direct, expected consequence of restoring real,
load-bearing content a prior expansion or reordering pass had dropped.
`v4b.facilities.energy-utilities-policy` and `v4b.care.end-of-life-care-policy`
were also corrected this checkpoint and independently confirmed NOT to shift
tier. The measured `below_preferred_minimum` warning count is now 20
(historical prior figure: 22).

**Provenance**: this distribution was **independently reproduced this
session**, not carried forward and not copied from a supplied expected value.
It was measured by directly running the real extraction ->
structural-normalisation -> `BaselineStructuralChunker` sequence inside the
precisely identified, already-locally-cached `rag-platform-ai:development`
Docker image (image ID
`sha256:c5ab90de8d23e73d5b6cf78b4987189947957513c5531be8d8db5895e2509202`,
stable Python 3.14.6), with `--network none` and the corpus bind-mounted
read-only, at 2026-09-02T11:56:28Z, against application source at main-
repository commit `f27ff1b1d49b6eb7c555ffce3e278e22ad2eb6a4`. See
`authoring-governance/runtime-contract.json`'s `application_pipeline_profile`
for the exact command, the full per-document result, and the historical
record of a prior session's two failed offline reconstruction attempts
(superseded, not currently applicable — the cached image's stable Python
3.14.6 does not exhibit either failure).

## Reproducibility and tenant boundary

`generate/finalize_freeze_candidate.py` is the corpus-content build step;
`generate/build_checkpoint_archive.py` is the sole normative checkpoint
archive builder (see Candidate identity above — the system `tar` command is
retired from this claim). PDFs use ReportLab invariant output and stable
metadata; DOCX packages use fixed metadata, member ordering and ZIP
timestamps. Primary artefacts carry the Alderbridge identity, foreign
artefacts the Thornfield identity, and the separate injection pack a neutral
synthetic-security identity.

## Version-change-type governance

`authoring-governance/version-change-type-registry.json` is the closed,
versioned vocabulary for the `version_change_type` manifest field: a bounded
set of canonical values, each with a stated meaning, a machine-verifiable vs.
broader-semantic classification, and required invariants. It replaces
~89 previously free-text values (55 of them single-use, family-specific
labels carrying no information beyond what a per-comparison contract already
records) with 17 reusable canonical values plus null.
`authoring-governance/version-diff-contracts.json` records, for every one of
the 115 adjacent version comparisons in the primary corpus, the specific
declared allowed-changed-section set and a content digest per protected
section. `generate/validate_version_fidelity.py` checks every comparison's
*actual* current diff against its contract — rejecting an unknown type, a
missing contract, or any changed section outside the declared set — replacing
the previous "any non-identical pair passes" behaviour. Both governance files
are corpus-authoring evidence, not evaluation material, and are not inputs to
evaluation-question authoring.

This correction also fixed a genuine content defect found by re-audit:
`v4b.medication.fridge-breakdown-procedure` had a top-line instruction to
"move stock to the backup cool box immediately" that contradicted its own
detailed containment section ("keep the door closed... stock is not moved on
assumption"). Both versions now open with a single coherent sequence: keep
closed, do not move on assumption, escalate, then use a validated alternative
only once authorised. Three other families
(`continence-care-policy`, `dbs-renewal-procedure`,
`right-to-work-checks-procedure`) had an unrelated section silently dropped
from v2 during an earlier expansion pass; both sections were restored
verbatim in each, alongside the family's own intended tightened-requirement
change. The two other families sharing the same bounded canonical
"...with_consequential_rewrite" vocabulary
(`ladder-stepladder-use-guidance`, `induction-buddy-scheme-guidance`) were
re-checked against the same failure pattern and found already coherent, with
no unrelated removal.

## Formatting-only boundary

`v4b.hr.staff-handover-procedure` has identical normalized extracted text in
both versions but different deterministic DOCX presentation bytes. The current
accepted structured-extraction contract does not promise semantic detection of
presentation-only changes. It therefore remains an honest unavailable or
non-provable comparison case unless a future reviewed ADR extends extraction
and defines a re-extraction strategy.

## Safety

Everything is fictional. Prompt-injection strings are inert document content.
Negative fixtures are bounded test inputs, not malware. Do not ingest this
candidate outside the approved evaluation workflow, and do not author cases
from it until the exact archive has passed independent freeze review.
"""
    (ROOT / "README.md").write_text(readme, encoding="utf-8")

    exact_rows = "\n".join(f"| {count} | {total} |" for count, total in exact.items())
    report = f"""# Validation Report — Dolved Evaluation Corpus V4

Status: **corrected authoring candidate; awaiting independent freeze review**.

## Inventory

| Measure | Result |
|---|---:|
| Primary versions | {len(primary)} |
| Families | {len(by_family)} |
| PDF / DOCX / TXT | {formats['pdf']} / {formats['docx']} / {formats['txt']} |
| V4-C versions | 75 |
| Foreign-tenant documents | {len(foreign)} |
| Prompt-injection documents | 9 (3 primary + {len(injections)} separate) |
| Negative fixtures | {len(fixtures)} |

Family versions: {version_distribution[1]} × 1, {version_distribution[2]} × 2,
{version_distribution[3]} × 3 and {version_distribution[4]} × 4.

## Real pipeline chunk results

| Exact chunks | Documents |
|---:|---:|
{exact_rows}

Tier totals: 1={tiers['1']}, 2={tiers['2']}, 3={tiers['3']},
4–8={tiers['4-8']}, 9+={tiers['9+']}.

The run used the repository's real extractor, structural normaliser,
`BaselineStructuralChunker` and tokenizer configuration captured in
`chunk-profile.json`. Physical failures: {len(audit['physical_errors'])}.

## Freeze-audit corrections

### Checkpoint 16 (prior round)

- Expanded every genuine policy/procedure below approximately 100 words found
  by the full sweep: 30 versions across 15 families. The short Overtime
  Procedure and Payroll Calendar remains a truthful schedule/reference.
- Replaced five false `one_word_substantial` labels with change types that
  truthfully declare their consequential section rewrites.
- Made the staff-handover pair semantically identical while retaining a real,
  deterministic presentation-only DOCX difference.
- Made PDF and DOCX generation byte-deterministic across complete builds.
- Separated Alderbridge, Thornfield and neutral injection-pack branding.
- Rebuilt the exact-duplicate fixture from the current Complaints Policy.
- Normalized the health-and-safety domain identifier.
- Added `version-diff-report.json`, complete checksum authority and freeze
  hygiene validation.

### Checkpoint 17 (this round — Codex re-audit follow-up)

- Added an enforceable reproducibility contract (`authoring-governance/
  runtime-contract.json`), a fully pinned dependency lock, `renderer_version`
  on every relevant manifest entry, and reproducibility checks in
  `generate/validate_freeze.py`.
- Fixed a genuine contradiction in `fridge-breakdown-procedure` (an
  unconditional "move stock immediately" instruction against its own "keep
  the fridge closed" containment section); both versions now open with one
  coherent sequence.
- Restored two sections each, silently dropped from v2 during an earlier
  expansion pass, in `continence-care-policy`, `dbs-renewal-procedure` and
  `right-to-work-checks-procedure`, while preserving each family's intended
  tightened-requirement change; re-checked the two other families sharing the
  same canonical vocabulary and found them already coherent.
- Replaced the free-text `version_change_type` field with a closed, versioned
  17-value registry plus a per-comparison contract for all 115 adjacent
  version pairs, and a real fidelity validator that rejects an unexpected
  changed section instead of passing any non-identical pair.
- Fixed the previously-inconsistent `version_change_type` convention so a
  two-version family's v1 mirrors its v2 (the corpus-wide norm for 60 of 60
  such families) and a three/four-version family's opening version is null.

### Checkpoint 18 (this round — remaining freeze blockers)

- Replaced the checkpoint archive mechanism entirely:
  `generate/build_checkpoint_archive.py` (a pinned, versioned Python
  implementation) replaces the system `tar` command, which was found to
  write 969 macOS AppleDouble sidecar members, a duplicate top-level root,
  and 1715 raw regular-file members instead of 746 into checkpoint 17's
  archive — invisible to `tar -tzvf` and to post-extraction diffing, visible
  only via raw tar-member inspection. `generate/validate_archive_raw.py`
  checks the raw member stream of every archive going forward.
  Two independent builds from the same source produce byte-identical
  archives.
- Corrected the measured chunk distribution to 91/42/61/76/30 (previously
  91/42/62/75/30), recording `continence-care-policy::v2`'s move from 3 to 4
  chunks as the expected consequence of its restored sections, and swept
  README/validation-report/chunk-profile for the stale prior figures.
- Split `authoring-governance/runtime-contract.json` into two explicitly
  named runtime profiles (`corpus_local_profile`, `application_pipeline_profile`)
  since their dependency sets genuinely differ; documented a fully offline,
  good-faith reconstruction attempt of the application pipeline and the two
  independent, precisely diagnosed reasons it could not succeed this session.
- Strengthened `generate/validate_version_fidelity.py` so a contract's
  declared markers, digests and section sets are checked against REAL
  EXTRACTED ARTEFACT TEXT (not semantic-master structure) exactly, rather
  than by generic presence, and added an 18-case tamper-test suite proving
  the validator rejects each specific defect class it is meant to catch,
  including the exact Continence Care `must`→`should` reversal.
- While building that real-extraction-based validator, independently
  discovered and fixed the same unrelated-section-removal defect class in
  three further families beyond the three named for this correction:
  `energy-utilities-policy`, `staff-supervision-appraisal-policy`, and
  `end-of-life-care-policy` v2, each restoring content dropped during an
  earlier expansion or reordering pass. This checkpoint's own local-estimate
  guess that none of the three would shift chunk tier was corrected at
  checkpoint 19: `staff-supervision-appraisal-policy::v2` did shift (4→5),
  confirmed by the real pipeline; the other two did not.

### Checkpoint 19 (this round — application-pipeline evidence corrections)

- **Independently reproduced the real application-pipeline measurement**
  inside the precisely identified, already-locally-cached
  `rag-platform-ai:development` image (image ID
  `sha256:c5ab90de8d23e73d5b6cf78b4987189947957513c5531be8d8db5895e2509202`,
  stable Python 3.14.6 — not the pre-release 3.14.0rc2 that previously
  blocked reconstruction), with `--network none` and the corpus mounted
  read-only. Matched the task-supplied expected values exactly: the full
  12-bucket exact chunk distribution, the 91/42/61/76/30 tier totals, the
  `staff-supervision-appraisal-policy::v2` 4→5 move, and the
  `below_preferred_minimum` warning count of 20 — not copied, independently
  computed.
- Corrected every exact-count and warning-count claim across
  `chunk-profile.json`, this report, `README.md` and `authoring-spec.md` to
  the newly measured values, replacing the prior (now clearly historical)
  91/42/62/75/30-with-22-warnings figures and the earlier claim that no
  cached application image identity was available.
- Rebuilt `authoring-governance/runtime-contract.json`'s
  `application_pipeline_profile` with the cached image identity, the
  successful network-disabled run's full command and result, the exact
  commit and per-file SHA-256 for all 25 source-and-lock files, and a fully
  defined, executable canonical aggregation algorithm
  (`generate/compute_application_source_aggregate.py`) replacing the prior
  checkpoint's unexplained concatenation hash. `generate/validate_freeze.py`
  now independently reconstructs that aggregate from the recorded per-file
  hashes and verifies it.
- Preserved the truthful `corpus_local_profile` / `application_pipeline_profile`
  split; no claim is made that the corpus-local lock alone reconstructs the
  application pipeline, that the cached image is vendored in the corpus,
  or that byte reproduction holds cross-platform.
- No semantic master, rendered artefact, manifest document identity, version
  contract, fixture or product source was modified this checkpoint — this is
  a documentation/runtime-evidence-only correction.

## Negative and security packs

The corrupt and password-protected PDFs fail extraction deliberately. The
exact-duplicate fixture is byte-identical to its governed primary source under
a different filename. Foreign canary facts and family identities are separate
from the primary tenant. All nine injection cases are inert and explicitly
labelled.

## Known honest boundary

The staff-handover formatting-only difference is not semantically provable by
the accepted structured-extraction contract. It is retained as an explicit
unavailable/non-provable comparison case rather than reported as a detectable
semantic change.
"""
    (ROOT / "validation-report.md").write_text(report, encoding="utf-8")
    print("Generated README.md, validation-report.md and chunk-profile.json from final data.")


if __name__ == "__main__":
    main()
