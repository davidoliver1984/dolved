"""V4-B batch 14: first version (v1 only) of 5 three-version families.
v2/v3 for these families are explicitly deferred to V4-C — not authored here."""

DOCS = [
{
    "family_id": "v4c.hs.fire-risk-assessment-methodology", "family_title": "Fire Risk Assessment Methodology",
    "version_id": "v1", "version_change_type": None,
    "domain": "fire-safety", "content_type": "policy",
    "human_title": "Fire Risk Assessment Methodology", "filename": "fire-risk-assessment-methodology-v1.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2024-04-01", "superseded_date": "2025-04-01",
    "messiness_level": "moderate", "messiness_axes": ["mixed_numbering"],
    "front_matter": "First of a planned three-version family. v2 and v3 are deferred to a later authoring tranche (V4-C).",
    "sections": [
        ("1. Methodology", "Fire risk assessments use the standard 5-step PAS 79 methodology: identify hazards, identify people at risk, evaluate and act, record findings, review."),
        ("2. Reviewer competency", "Assessments are completed by a competent person who has completed the Level 3 fire risk assessment course."),
    ],
},
{
    "family_id": "v4c.it.cyber-incident-response-plan", "family_title": "Cyber Incident Response Plan",
    "version_id": "v1", "version_change_type": None,
    "domain": "it-security", "content_type": "policy",
    "human_title": "Cyber Incident Response Plan", "filename": "cyber-incident-response-plan-v1.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2024-10-01", "superseded_date": "2025-10-01",
    "messiness_level": "moderate", "messiness_axes": ["abbreviation_heavy", "dense_table"],
    "front_matter": "First of a planned three-version family. v2 and v3 are deferred to a later authoring tranche (V4-C).",
    "sections": [
        ("Detection and containment", "Suspected ransomware or unauthorised access is reported to the IT service desk immediately; affected devices are isolated from the network, not powered off, to preserve evidence."),
        ("__table__", [
            ["Severity", "Response"],
            ["Low (single device)", "IT service desk handles directly"],
            ["High (network-wide)", "On-call director activates the Business Continuity Plan"],
        ]),
    ],
},
{
    "family_id": "v4c.hr.recruitment-and-selection-policy", "family_title": "Recruitment and Selection Policy",
    "version_id": "v1", "version_change_type": None,
    "domain": "hr", "content_type": "policy",
    "human_title": "Recruitment and Selection Policy", "filename": "recruitment-selection-policy-v1.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2024-02-01", "superseded_date": "2025-02-01",
    "messiness_level": "mild", "messiness_axes": ["cross_reference"],
    "front_matter": "First of a planned three-version family. v2 and v3 are deferred to a later authoring tranche (V4-C).",
    "sections": [
        ("Selection panel", "Every interview panel has at least 2 members, one of whom has completed safer recruitment training; see the Safer Recruitment Guidance for the detailed checklist."),
        ("Right to work and DBS", "No conditional offer is confirmed as unconditional until right-to-work and DBS checks are satisfactorily completed."),
    ],
},
{
    "family_id": "v4c.medication.medication-policy-overarching", "family_title": "Medication Policy (Overarching)",
    "version_id": "v1", "version_change_type": None,
    "domain": "medication", "content_type": "policy",
    "human_title": "Medication Policy (Overarching Statement)", "filename": "medication-policy-overarching-v1.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2023-11-01", "superseded_date": "2024-11-01",
    "messiness_level": "clean", "messiness_axes": [],
    "front_matter": "First of a planned three-version family. v2 and v3 are deferred to a later authoring tranche (V4-C).",
    "sections": [
        ("Scope statement", "This overarching statement sits above the detailed Safe Administration of Medication Policy, Controlled Drugs Procedure and Homely Remedies Policy, confirming they form one connected medication governance framework rather than independent documents."),
    ],
},
{
    "family_id": "v4c.safeguarding.safeguarding-policy-overarching", "family_title": "Safeguarding Policy (Overarching)",
    "version_id": "v1", "version_change_type": None,
    "domain": "safeguarding", "content_type": "policy",
    "human_title": "Safeguarding Policy (Overarching Statement)", "filename": "safeguarding-policy-overarching-v1.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2024-01-01", "superseded_date": "2025-01-01",
    "messiness_level": "clean", "messiness_axes": [],
    "front_matter": "First of a planned three-version family. v2 and v3 are deferred to a later authoring tranche (V4-C).",
    "sections": [
        ("Scope statement", "This overarching statement confirms Alderbridge's zero-tolerance position on abuse and neglect, and that the detailed Safeguarding Adults Policy, Allegations Against Staff Procedure, Missing Person Procedure and Mental Capacity Act Guidance together form one connected safeguarding framework."),
    ],
},
]
