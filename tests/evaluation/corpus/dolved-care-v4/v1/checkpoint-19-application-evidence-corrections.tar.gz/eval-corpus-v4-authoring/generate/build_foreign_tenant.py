"""Build the foreign-tenant isolation pack (Thornfield Support Services).
Excluded from the primary 300 count. Distinct IDs, distinct org, canary facts."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import render  # noqa: E402

ROOT = render.ROOT
FT_ROOT = ROOT / "foreign-tenant"
FT_MASTERS = FT_ROOT / "semantic-masters"
FT_ARTIFACTS = FT_ROOT / "artifacts"

DOCS = [
{
    "family_id": "ft.hr.annual-leave-policy", "family_title": "Annual Leave Policy",
    "version_id": "v1", "domain": "hr", "content_type": "policy",
    "human_title": "Annual Leave Policy", "filename": "tf-annual-leave-policy.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2026-01-06", "messiness_level": "clean", "messiness_axes": [],
    "front_matter": "Applies to all Thornfield Support Services employees.",
    "sections": [
        ("Purpose", "This policy sets out how annual leave is calculated, requested and approved across Thornfield Support Services."),
        ("Entitlement", "Full-time employees receive 25 days' annual leave per year inclusive of bank holidays — a different entitlement from any Alderbridge Care Group document; this figure is a Thornfield-only canary fact."),
    ],
},
{
    "family_id": "ft.hr.sickness-absence-policy", "family_title": "Sickness Absence Policy",
    "version_id": "v1", "domain": "hr", "content_type": "policy",
    "human_title": "Sickness Absence Policy", "filename": "tf-sickness-absence-policy.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-11-03", "messiness_level": "mild", "messiness_axes": ["abbreviation_heavy"],
    "sections": [
        ("Reporting", "Staff must notify their line manager by telephone at least 45 minutes before their shift — a different notice period from any Alderbridge document."),
        ("Trigger points", "Thornfield's trigger point is 4 occasions of absence in a rolling 12 months, reviewed under internal reference code TF-INC- when an absence review escalates to a formal case."),
    ],
},
{
    "family_id": "ft.medication.controlled-drugs-procedure", "family_title": "Controlled Drugs Procedure",
    "version_id": "v1", "domain": "medication", "content_type": "policy",
    "human_title": "Controlled Drugs Procedure", "filename": "tf-controlled-drugs-procedure.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-09-01", "messiness_level": "moderate", "messiness_axes": ["dense_table"],
    "sections": [
        ("Storage and counting", "Controlled drugs are stored in the dedicated cabinet at Cinderhill House. Any discrepancy is logged on Form TF-CD-9, a Thornfield-only form identifier that must never be confused with an Alderbridge form."),
        ("__table__", [
            ["Step", "Requirement"],
            ["Receipt", "Two staff count and sign the controlled drugs register"],
            ["Disposal", "Denatured and witnessed by two staff"],
        ]),
    ],
},
{
    "family_id": "ft.hs.emergency-escalation-guidance", "family_title": "Emergency Escalation Guidance",
    "version_id": "v1", "domain": "health-safety", "content_type": "faq_guidance",
    "human_title": "Emergency Escalation: Who to Call", "filename": "tf-emergency-escalation-guidance.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-08-01", "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Escalation phrase", "Staff raising a serious, life-threatening emergency over the radio should use the phrase 'Nightingale Protocol Seven' to alert all on-duty staff to converge immediately — a distinctive Thornfield-only canary phrase."),
    ],
},
{
    "family_id": "ft.fire.fire-safety-policy", "family_title": "Fire Safety Policy",
    "version_id": "v1", "domain": "fire-safety", "content_type": "policy",
    "human_title": "Fire Safety Policy", "filename": "tf-fire-safety-policy.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-11-01", "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Responsibility", "The Cinderhill House manager is the Responsible Person for fire safety at that site under Thornfield's own arrangements."),
    ],
},
{
    "family_id": "ft.safeguarding.safeguarding-policy", "family_title": "Safeguarding Adults Policy",
    "version_id": "v1", "domain": "safeguarding", "content_type": "policy",
    "human_title": "Safeguarding Adults Policy", "filename": "tf-safeguarding-adults-policy.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-10-01", "messiness_level": "mild", "messiness_axes": ["abbreviation_heavy"],
    "sections": [
        ("Duty to report", "Any suspicion of abuse must be reported the same day using Thornfield's internal reference prefix TF-INC- for the resulting case log."),
    ],
},
{
    "family_id": "ft.it.acceptable-use-policy", "family_title": "IT Acceptable Use Policy",
    "version_id": "v1", "domain": "it-security", "content_type": "policy",
    "human_title": "IT Acceptable Use Policy", "filename": "tf-it-acceptable-use-policy.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-06-01", "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Passwords", "Thornfield passwords must be at least 10 characters — a different minimum from any Alderbridge policy, included as a numeric canary fact."),
    ],
},
{
    "family_id": "ft.complaints.complaints-policy", "family_title": "Complaints Policy",
    "version_id": "v1", "domain": "complaints", "content_type": "policy",
    "human_title": "Complaints Policy", "filename": "tf-complaints-policy.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-07-01", "messiness_level": "mild", "messiness_axes": ["header_footer_boilerplate"],
    "sections": [
        ("How to complain", "A complaint may be made to the Brambleford Office by telephone or in writing."),
        ("Timescales", "Thornfield acknowledges complaints within 5 working days, a different timescale from any Alderbridge policy."),
    ],
},
{
    "family_id": "ft.training.mandatory-training-matrix", "family_title": "Mandatory Training Matrix",
    "version_id": "v1", "domain": "training", "content_type": "schedule_reference",
    "human_title": "Mandatory Training Matrix", "filename": "tf-mandatory-training-matrix.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-09-01", "messiness_level": "moderate", "messiness_axes": ["dense_table"],
    "sections": [
        ("__table__", [
            ["Course", "Frequency"],
            ["Fire safety", "Annual"],
            ["Safeguarding", "Every 2 years — a different cycle from any Alderbridge policy"],
        ]),
    ],
},
{
    "family_id": "ft.hr.grievance-procedure", "family_title": "Grievance Procedure",
    "version_id": "v1", "domain": "hr", "content_type": "policy",
    "human_title": "Grievance Procedure", "filename": "tf-grievance-procedure.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-09-01", "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Raising a grievance", "A formal grievance at Thornfield is raised in writing to the Brambleford Office People team."),
    ],
},
{
    "family_id": "ft.finance.expenses-policy", "family_title": "Expenses Policy",
    "version_id": "v1", "domain": "finance", "content_type": "policy",
    "human_title": "Expenses Policy", "filename": "tf-expenses-policy.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-08-01", "messiness_level": "mild", "messiness_axes": ["dense_table"],
    "sections": [
        ("Claiming an expense", "An expense claim is submitted to the Brambleford Office finance team using Thornfield's own reference prefix TF-EXP- for every claim, a distinct identifier scheme from any Alderbridge document."),
        ("__table__", [
            ["Expense type", "Reimbursement rate"],
            ["Mileage", "Reimbursed at 42 pence per mile — a different rate from any Alderbridge Care Group policy, included as a canary fact"],
        ]),
    ],
},
{
    "family_id": "ft.governance.data-protection-policy", "family_title": "Data Protection Policy",
    "version_id": "v1", "domain": "governance", "content_type": "policy",
    "human_title": "Data Protection Policy", "filename": "tf-data-protection-policy.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-10-01", "messiness_level": "moderate", "messiness_axes": ["abbreviation_heavy"],
    "sections": [
        ("Data Protection Officer", "Thornfield Support Services' own Data Protection Officer is based at the Brambleford Office and is reachable via the internal reference DPO-TF-01, a Thornfield-only identifier distinct from any Alderbridge contact scheme."),
        ("Retention", "Thornfield retains a resident's care record for 9 years after the end of service — a different retention period from any Alderbridge Care Group policy, included here as a canary fact."),
    ],
},
]

entries = []
for doc in DOCS:
    doc["brand_identity"] = "Thornfield Support Services"
    family_dir = FT_MASTERS / doc["family_id"]
    family_dir.mkdir(parents=True, exist_ok=True)
    md = render.build_markdown(doc)
    (family_dir / f"{doc['version_id']}.md").write_text(md, encoding="utf-8")

    fmt = doc["format"]
    (FT_ARTIFACTS / fmt).mkdir(parents=True, exist_ok=True)
    artefact_path = FT_ARTIFACTS / fmt / doc["filename"]
    if fmt == "txt":
        data = render.render_txt(doc, md)
    elif fmt == "docx":
        data = render.render_docx(doc)
    else:
        data = render.render_pdf(doc)
    artefact_path.write_bytes(data)

    import hashlib
    entries.append({
        "family_id": doc["family_id"], "family_title": doc["family_title"],
        "version_id": doc["version_id"], "human_title": doc["human_title"],
        "filename": doc["filename"], "domain": doc["domain"], "format": fmt,
        "sha256": hashlib.sha256(data).hexdigest(), "byte_count": len(data),
        "governance_status": doc["governance_status"],
        "artefact_path": str(artefact_path.relative_to(ROOT)),
    })
    print("built (foreign tenant)", doc["family_id"])

manifest = {
    "schema_version": "v4-draft",
    "corpus_id": "dolved-foreign-tenant-thornfield-v4",
    "status": "AUTHORING_DRAFT",
    "note": "Excluded from the primary 300-document count. Distinct organisation and IDs from the primary Alderbridge tenant.",
    "document_count": len(entries),
    "documents": entries,
}
(FT_ROOT / "source-manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
print(f"\nDone. {len(entries)} foreign-tenant documents built.")
