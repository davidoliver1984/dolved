"""Medium tier batch C1: 4 two-version family pairs targeting 2 real
chunks per version. Each pair's existing meaningful diff (read from the
current live content before expansion) is preserved exactly:
- compliments-escalation-guidance: 4h -> 2h escalation window
- visitor-parking-guidance: wording tidied, rule unchanged
- ladder-stepladder-use-guidance: 'can' -> 'must only', narrowing
- uniform-allowance-guidance: allowance amounts increased (£40->£55, £25->£35)
"""

DOCS = [
{
    "family_id": "v4b.complaints.compliments-escalation-guidance", "version_id": "v1",
    "front_matter": None,
    "sections": [
        ("Purpose and scope", "This guidance explains how a serious complaint is escalated at Alderbridge Care Group, distinct from the routine complaints timescale used for a general concern. It applies to every site."),
        ("Policy statement", "A complaint alleging abuse, or involving a serious injury, bypasses the normal complaints timescale entirely and is escalated to the Quality Lead within 4 hours, reflecting the urgency this category of complaint genuinely warrants."),
        ("Definitions", "**Serious complaint** a complaint alleging abuse, or involving a serious injury, as distinct from a general service concern handled under the routine complaints process. **Escalation window** the maximum time allowed between the complaint being received and the Quality Lead being informed."),
        ("__numbered__", [
            "Identify whether a complaint meets the serious complaint threshold as soon as it is received, escalating an unclear case rather than defaulting to the routine timescale.",
            "Escalate a serious complaint to the Quality Lead within 4 hours of it being received, regardless of the time of day.",
            "Continue to acknowledge the complainant promptly using the routine complaints process's normal courtesy steps, alongside the separate urgent escalation.",
            "Record the time the complaint was received and the time it was escalated, supporting a clear audit of whether the window was met.",
        ]),
        ("Interaction with other Alderbridge policies", "This guidance works alongside the Adult Safeguarding Policy (a serious complaint alleging abuse is also a safeguarding concern) and the CQC Notification Procedure (relevant where the underlying event is also notifiable)."),
        ("Worked example", "A worked example illustrates the escalation window. A family member telephones on a Sunday evening alleging a resident was treated roughly during personal care. This is immediately recognised as a serious complaint, and the on-call structure ensures the Quality Lead is informed well within the 4-hour window, rather than waiting until the next working day simply because it was received outside office hours."),
        ("Frequently asked questions", "**Does a serious complaint also need to go through the routine complaints process?** Yes, the urgent escalation runs alongside, not instead of, the normal complaints process, which still handles the wider investigation and response to the complainant. **Who decides if a complaint meets the serious threshold?** Any member of staff receiving it makes an initial judgement, escalating to the registered manager immediately if genuinely unsure."),
        ("Training and competency", "All staff who might receive a complaint, including reception, are shown how to recognise a serious complaint and the escalation route during induction."),
        ("Monitoring and compliance", "Escalation timing is reviewed by the Quality Lead for every serious complaint, with any breach of the window investigated as its own compliance matter."),
        ("Closing note", "A fast, reliable escalation route for a serious complaint protects a resident and reassures a worried family, and this guidance exists to make that speed consistent regardless of when the complaint arrives."),
    ],
},
{
    "family_id": "v4b.complaints.compliments-escalation-guidance", "version_id": "v2",
    "front_matter": "Supersedes the version effective 1 July 2025. Escalation window tightened from 4 hours to 2 hours.",
    "sections": [
        ("Purpose and scope", "This guidance explains how a serious complaint is escalated at Alderbridge Care Group, distinct from the routine complaints timescale used for a general concern. It applies to every site."),
        ("Policy statement", "A complaint alleging abuse, or involving a serious injury, bypasses the normal complaints timescale entirely and is escalated to the Quality Lead within 2 hours, reflecting the urgency this category of complaint genuinely warrants."),
        ("Definitions", "**Serious complaint** a complaint alleging abuse, or involving a serious injury, as distinct from a general service concern handled under the routine complaints process. **Escalation window** the maximum time allowed between the complaint being received and the Quality Lead being informed, tightened in this version from 4 hours to 2 hours."),
        ("__numbered__", [
            "Identify whether a complaint meets the serious complaint threshold as soon as it is received, escalating an unclear case rather than defaulting to the routine timescale.",
            "Escalate a serious complaint to the Quality Lead within 2 hours of it being received, a tightening from the previous 4-hour window, regardless of the time of day.",
            "Continue to acknowledge the complainant promptly using the routine complaints process's normal courtesy steps, alongside the separate urgent escalation.",
            "Record the time the complaint was received and the time it was escalated, supporting a clear audit of whether the 2-hour window was met.",
        ]),
        ("Interaction with other Alderbridge policies", "This guidance works alongside the Adult Safeguarding Policy (a serious complaint alleging abuse is also a safeguarding concern) and the CQC Notification Procedure (relevant where the underlying event is also notifiable)."),
        ("Worked example", "A worked example illustrates the tightened window. A family member telephones on a Sunday evening alleging a resident was treated roughly during personal care. This is immediately recognised as a serious complaint, and the on-call structure ensures the Quality Lead is informed within the new 2-hour window, a noticeably faster standard than the previous version's 4-hour allowance for exactly this kind of out-of-hours scenario."),
        ("Frequently asked questions", "**Why was the escalation window shortened?** A review found that a 4-hour window occasionally meant the Quality Lead learned of a serious complaint later than ideal for coordinating an immediate response; 2 hours closes that gap. **Does a serious complaint also need to go through the routine complaints process?** Yes, the urgent escalation runs alongside, not instead of, the normal complaints process."),
        ("Training and competency", "All staff who might receive a complaint, including reception, are shown how to recognise a serious complaint and the tightened 2-hour escalation route during induction."),
        ("Monitoring and compliance", "Escalation timing is reviewed by the Quality Lead for every serious complaint against the new 2-hour standard, with any breach investigated as its own compliance matter."),
        ("Closing note", "A fast, reliable escalation route for a serious complaint protects a resident and reassures a worried family, and the tightened window in this version exists to make that speed even more dependable."),
    ],
},
{
    "family_id": "v4b.contractors.visitor-parking-guidance", "version_id": "v1",
    "front_matter": None,
    "sections": [
        ("Purpose and scope", "This guidance explains where a visitor should park when visiting an Alderbridge site. It applies to every visitor arriving by car."),
        ("Policy statement", "Visitors should use the marked visitor bays near the main entrance and should not park in bays reserved for staff or blue badge holders, keeping those reserved bays available for the people they are set aside for."),
        ("Definitions", "**Visitor bay** a car parking space marked and reserved specifically for a visitor's use. **Reserved bay** a staff or blue badge bay, not available for general visitor parking regardless of how full the visitor bays appear."),
        ("__numbered__", [
            "Park in a marked visitor bay near the main entrance on arrival.",
            "Do not park in a bay reserved for staff or a blue badge holder, even if a visitor bay is not immediately available.",
            "Speak to reception if every visitor bay is genuinely full, and staff will advise on an alternative rather than a visitor using a reserved bay.",
            "Follow any temporary parking sign displayed during a specific event, such as a fire drill or a delivery, which takes precedence over the standard arrangement for that period.",
        ]),
        ("Interaction with other Alderbridge policies", "This guidance works alongside the Visiting Arrangements Policy (the wider standard for how a visitor is welcomed) and the Fleet and Vehicle Use Policy (governing an Alderbridge vehicle's own parking, distinct from visitor parking)."),
        ("Worked example", "A worked example illustrates the reserved-bay standard. A family member arrives to find the visitor bays full during a particularly busy afternoon. Rather than parking in an empty-looking staff bay, they check with reception, who directs them to an overflow area kept for exactly this situation."),
        ("Frequently asked questions", "**Can a visitor park in a blue badge bay if they display their own blue badge?** No, a blue badge bay at an Alderbridge site is reserved for a resident or visitor already accounted for under that arrangement; a general visitor with a blue badge is directed to a visitor bay unless a specific accessible visitor bay is provided. **Is there a time limit on visitor parking?** No, a visitor may park for the full duration of their visit."),
        ("Training and competency", "Reception staff are shown the overflow parking arrangement during induction, so they can direct a visitor confidently when the marked bays are full."),
        ("Closing note", "Simple, clearly marked parking arrangements make a visitor's arrival easier and keep a reserved bay available for the person who genuinely needs it, and this guidance exists to keep both of those things true."),
    ],
},
{
    "family_id": "v4b.contractors.visitor-parking-guidance", "version_id": "v2",
    "front_matter": "Supersedes the version effective 1 May 2025. Wording tidied for tone; the underlying rule is unchanged.",
    "sections": [
        ("Purpose and scope", "This guidance explains where a visitor should park when visiting an Alderbridge site. It applies to every visitor arriving by car."),
        ("Policy statement", "Please park in one of the marked visitor bays close to the main entrance. Staff and blue badge bays are reserved and should be left clear for their intended users, keeping those reserved bays available for the people they are set aside for."),
        ("Definitions", "**Visitor bay** a car parking space marked and reserved specifically for a visitor's use. **Reserved bay** a staff or blue badge bay, left clear for its intended users regardless of how full the visitor bays appear."),
        ("__numbered__", [
            "Please park in a marked visitor bay near the main entrance on arrival.",
            "Staff and blue badge bays are reserved and should be left clear, even if a visitor bay is not immediately available.",
            "Please speak to reception if every visitor bay is genuinely full, and staff will be happy to advise on an alternative.",
            "Please follow any temporary parking sign displayed during a specific event, such as a fire drill or a delivery, which takes precedence over the standard arrangement for that period.",
        ]),
        ("Interaction with other Alderbridge policies", "This guidance works alongside the Visiting Arrangements Policy (the wider standard for how a visitor is welcomed) and the Fleet and Vehicle Use Policy (governing an Alderbridge vehicle's own parking, distinct from visitor parking)."),
        ("Worked example", "A worked example illustrates the reserved-bay standard, unchanged in substance from the previous version though expressed more warmly here. A family member arrives to find the visitor bays full during a particularly busy afternoon. Rather than parking in an empty-looking staff bay, they check with reception, who directs them to an overflow area kept for exactly this situation."),
        ("Frequently asked questions", "**Has the parking rule itself changed in this version?** No, only the wording has been tidied for a friendlier tone; the actual arrangement is identical to the previous version. **Can a visitor park in a blue badge bay if they display their own blue badge?** No, a blue badge bay at an Alderbridge site is reserved for a resident or visitor already accounted for under that arrangement."),
        ("Training and competency", "Reception staff are shown the overflow parking arrangement during induction, so they can direct a visitor confidently when the marked bays are full."),
        ("Closing note", "Simple, clearly marked parking arrangements make a visitor's arrival easier and keep a reserved bay available for the person who genuinely needs it, and this guidance exists to keep both of those things true."),
    ],
},
{
    "family_id": "v4b.facilities.ladder-stepladder-use-guidance", "version_id": "v1",
    "front_matter": None,
    "sections": [
        ("Purpose and scope", "This guidance explains stepladder use for a low-level task at an Alderbridge site. It applies to every member of staff."),
        ("Policy statement", "Staff can use the site's own 2-step stool for a task below 1 metre; anything higher requires a contractor, keeping the low-level task achievable for staff while a genuinely higher task stays with a properly equipped, trained contractor."),
        ("Definitions", "**2-step stool** the specific, approved low-level equipment kept at each site for a task below 1 metre. **Contractor-only task** a task above 1 metre, or otherwise beyond what the 2-step stool safely reaches."),
        ("__numbered__", [
            "Use the site's approved 2-step stool for a task below 1 metre, such as changing a lightbulb or accessing a low shelf.",
            "Have a second person present when using the 2-step stool, to steady it and respond if needed.",
            "Arrange a contractor for any task above 1 metre; this is never attempted using the 2-step stool or another improvised item.",
            "Report a recurring low-level task to facilities if it happens often, since a recurring need may indicate a fixture that should be relocated instead.",
        ]),
        ("Interaction with other Alderbridge policies", "This guidance works alongside the Contractor Management Policy (governing how a contractor-only task is arranged) and the Health and Safety Policy (the wider risk assessment framework this guidance sits within)."),
        ("Worked example", "A worked example illustrates the 1-metre boundary. A member of staff notices a light fitting has failed in a stairwell, higher than the 2-step stool safely reaches. Rather than improvising with a taller item, this is reported to facilities, who arrange a contractor to complete the repair safely."),
        ("Frequently asked questions", "**Can a taller stepladder be brought in from home for a specific task?** No, only the site's own approved 2-step stool is used; a personal or borrowed item is never substituted. **Who decides whether a task is below or above 1 metre if it is genuinely borderline?** Facilities, and any genuine doubt is resolved by treating the task as contractor-only."),
        ("Training and competency", "Staff are shown correct 2-step stool use during induction, including the 1-metre boundary and when a task must instead go to a contractor."),
        ("Closing note", "Most low-level task risk in a care home setting is genuinely manageable with the right simple equipment, and this guidance exists to keep the boundary with contractor-only work clear and consistent."),
    ],
},
{
    "family_id": "v4b.facilities.ladder-stepladder-use-guidance", "version_id": "v2",
    "front_matter": "Supersedes the version effective 1 May 2025. 'Can' becomes 'must only' — narrowing what is permitted.",
    "sections": [
        ("Purpose and scope", "This guidance explains stepladder use for a low-level task at an Alderbridge site. It applies to every member of staff."),
        ("Policy statement", "Staff must only use the site's own 2-step stool for a task below 1 metre; anything higher requires a contractor — no other stepladder or improvised aid may be used, a narrower standard than the previous version's more permissive wording."),
        ("Definitions", "**2-step stool** the specific, approved low-level equipment kept at each site for a task below 1 metre, now the only permitted equipment for such a task. **Contractor-only task** a task above 1 metre, or otherwise beyond what the 2-step stool safely reaches."),
        ("__numbered__", [
            "Use only the site's approved 2-step stool for a task below 1 metre, such as changing a lightbulb or accessing a low shelf; no other stepladder or improvised aid may be used, a change from the previous version's wording.",
            "Have a second person present when using the 2-step stool, to steady it and respond if needed.",
            "Arrange a contractor for any task above 1 metre; this is never attempted using the 2-step stool or another improvised item.",
            "Report a recurring low-level task to facilities if it happens often, since a recurring need may indicate a fixture that should be relocated instead.",
        ]),
        ("Interaction with other Alderbridge policies", "This guidance works alongside the Contractor Management Policy (governing how a contractor-only task is arranged) and the Health and Safety Policy (the wider risk assessment framework this guidance sits within)."),
        ("Worked example", "A worked example illustrates the narrowed standard. A member of staff considers using a small folding step they keep in a nearby cupboard for a quick low-level task, rather than fetching the site's approved 2-step stool. Under this version, that substitution is no longer permitted at all — only the approved 2-step stool may be used, whereas the previous wording was less explicit about ruling out an alternative like this."),
        ("Frequently asked questions", "**Why was the wording changed from 'can' to 'must only'?** A review found the previous wording was occasionally read as allowing a similar improvised alternative; 'must only' removes that ambiguity entirely. **Can a taller stepladder be brought in from home for a specific task?** No, only the site's own approved 2-step stool is used under any circumstance for a task below 1 metre."),
        ("Training and competency", "Staff are shown correct 2-step stool use during induction, including the 1-metre boundary and the tightened 'must only' standard introduced in this version."),
        ("Closing note", "Most low-level task risk in a care home setting is genuinely manageable with the right simple equipment, and the tightened wording in this version exists to close a small ambiguity rather than to change the underlying 1-metre boundary itself."),
    ],
},
{
    "family_id": "v4b.payroll.uniform-allowance-guidance", "version_id": "v1",
    "front_matter": None,
    "sections": [
        ("Purpose and scope", "This guidance explains the uniform allowance available to a staff member in a uniformed role at Alderbridge Care Group. It applies to every site."),
        ("Policy statement", "A new starter in a uniformed role receives a one-off uniform allowance in their first month's pay, with a smaller replacement allowance paid every April thereafter, supporting a staff member to maintain their uniform to a good standard without cost falling entirely on them."),
        ("Definitions", "**Uniformed role** a role for which Alderbridge specifies a uniform standard, such as a care assistant or catering role. **Initial allowance** the one-off payment made in a new starter's first month. **Replacement allowance** the smaller annual payment made every April to support ongoing uniform upkeep and replacement."),
        ("__numbered__", [
            "Pay a new starter in a uniformed role a one-off uniform allowance of £40 in their first month's pay.",
            "Pay every staff member in a uniformed role a replacement allowance of £25 every April thereafter.",
            "Confirm a staff member's uniformed role status at the point payroll is set up, so the correct allowance is applied from the first pay run.",
            "Review the allowance amount periodically to ensure it remains reasonable against actual uniform costs.",
        ]),
        ("Interaction with other Alderbridge policies", "This guidance works alongside the Staff Handbook's uniform standard (specifying what a uniformed role is expected to wear) and the Staff Benefits Guidance (the wider set of benefits this allowance sits alongside)."),
        ("Worked example", "A worked example illustrates the two-part allowance. A new care assistant starts in March, receiving the £40 initial allowance in their first month's pay to purchase their starting uniform; the following April, they receive the £25 replacement allowance alongside every other uniformed staff member, supporting ongoing upkeep rather than a one-off payment being expected to last indefinitely."),
        ("Frequently asked questions", "**Does an agency worker receive this allowance?** No, it applies to a direct Alderbridge employee in a uniformed role; an agency worker's own uniform arrangement sits with their agency. **What happens if a staff member starts partway through the year, close to the April payment date?** They still receive the full initial allowance in their first month, and the following April's replacement allowance in the normal way, regardless of how close the two dates fall."),
        ("Closing note", "A fair uniform allowance recognises that looking professional has a real cost, and this guidance exists to make sure that cost does not fall unfairly on the staff member alone."),
    ],
},
{
    "family_id": "v4b.payroll.uniform-allowance-guidance", "version_id": "v2",
    "front_matter": "Supersedes the version effective 1 April 2024. Allowance amounts increased.",
    "sections": [
        ("Purpose and scope", "This guidance explains the uniform allowance available to a staff member in a uniformed role at Alderbridge Care Group. It applies to every site."),
        ("Policy statement", "A new starter in a uniformed role receives a one-off uniform allowance in their first month's pay, with a smaller replacement allowance paid every April thereafter, supporting a staff member to maintain their uniform to a good standard without cost falling entirely on them."),
        ("Definitions", "**Uniformed role** a role for which Alderbridge specifies a uniform standard, such as a care assistant or catering role. **Initial allowance** the one-off payment made in a new starter's first month, increased in this version. **Replacement allowance** the smaller annual payment made every April to support ongoing uniform upkeep and replacement, also increased in this version."),
        ("__numbered__", [
            "Pay a new starter in a uniformed role a one-off uniform allowance of £55 in their first month's pay, increased from the previous £40.",
            "Pay every staff member in a uniformed role a replacement allowance of £35 every April thereafter, increased from the previous £25.",
            "Confirm a staff member's uniformed role status at the point payroll is set up, so the correct, increased allowance is applied from the first pay run.",
            "Review the allowance amount periodically to ensure it remains reasonable against actual uniform costs.",
        ]),
        ("Interaction with other Alderbridge policies", "This guidance works alongside the Staff Handbook's uniform standard (specifying what a uniformed role is expected to wear) and the Staff Benefits Guidance (the wider set of benefits this allowance sits alongside)."),
        ("Worked example", "A worked example illustrates the increased amounts. A new care assistant starts in March, receiving the increased £55 initial allowance in their first month's pay to purchase their starting uniform, £15 more than the previous version provided; the following April, they receive the increased £35 replacement allowance alongside every other uniformed staff member."),
        ("Frequently asked questions", "**Why were the allowance amounts increased?** A review of typical uniform costs found the previous amounts had fallen behind actual replacement cost; the increase brings the allowance back in line. **Does a staff member who received the previous £40 initial allowance get the difference backdated?** No, the increase applies from this version's effective date forward, not retrospectively to an allowance already paid."),
        ("Closing note", "A fair uniform allowance recognises that looking professional has a real cost, and the increase in this version exists to keep that allowance genuinely adequate rather than allowing it to quietly fall behind actual cost over time."),
    ],
},
]
