"""Build V4-B: render the 125 new documents (60 two-version families' 120 versions
+ 5 three-version families' first version), then extend source-manifest.json and
document-family-plan.json to reflect the combined V4-A+V4-B state (225 total)."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import render  # noqa: E402

import batch8_two_version_a as b8
import batch9_two_version_b as b9
import batch10_two_version_c as b10
import batch11_two_version_d as b11
import batch12_two_version_e as b12
import batch13_two_version_f as b13
import batch14_three_version_v1_only as b14
import batch15_two_version_g as b15

ROOT = render.ROOT

NEW_DOCS = (
    b8.DOCS + b9.DOCS + b10.DOCS + b11.DOCS + b12.DOCS + b13.DOCS + b14.DOCS + b15.DOCS
)

assert len(NEW_DOCS) == 125, f"expected 125 new V4-B docs, got {len(NEW_DOCS)}"
new_ids = [d["family_id"] + "::" + d["version_id"] for d in NEW_DOCS]
assert len(set(new_ids)) == len(new_ids), "duplicate (family,version) in V4-B batch"
new_fns = [d["filename"] for d in NEW_DOCS]
assert len(set(new_fns)) == len(new_fns), "duplicate filename in V4-B batch"

# Load existing V4-A manifest to check no collision with V4-B and to extend it.
existing_manifest = json.loads((ROOT / "source-manifest.json").read_text())
existing_docs = existing_manifest["documents"]
existing_fam_ver = {d["family_id"] + "::" + d["version_id"] for d in existing_docs}
existing_fns = {d["filename"] for d in existing_docs}

collisions = set(new_ids) & existing_fam_ver
assert not collisions, f"V4-B collides with existing V4-A (family,version): {collisions}"
fn_collisions = set(new_fns) & existing_fns
assert not fn_collisions, f"V4-B collides with existing V4-A filenames: {fn_collisions}"

new_entries = []
for doc in NEW_DOCS:
    entry = render.build_one(doc, tranche="V4-B")
    entry["version_change_type"] = doc.get("version_change_type")
    new_entries.append(entry)
    print(f"built {doc['family_id']}::{doc['version_id']} -> {entry['artefact_path']}")

combined_documents = existing_docs + new_entries
combined_manifest = {
    "schema_version": "v4-draft",
    "corpus_id": "dolved-care-alderbridge-v4",
    "status": "AUTHORING_DRAFT",
    "tranche": "V4-B",
    "tranche_history": ["V4-A", "V4-B"],
    "document_count": len(combined_documents),
    "documents": combined_documents,
}
(ROOT / "source-manifest.json").write_text(json.dumps(combined_manifest, indent=2), encoding="utf-8")

# Rebuild document-family-plan.json to reflect actual state.
existing_plan = json.loads((ROOT / "document-family-plan.json").read_text())
existing_families = {f["family_id"]: f for f in existing_plan["families"]}

# Group new docs by family to record planned_version_count and built versions.
from collections import defaultdict
by_family = defaultdict(list)
for doc in NEW_DOCS:
    by_family[doc["family_id"]].append(doc)

three_version_family_ids = {d["family_id"] for d in b14.DOCS}

for fam_id, docs in by_family.items():
    sample = docs[0]
    built_versions = sorted(d["version_id"] for d in docs)
    planned_count = 3 if fam_id in three_version_family_ids else 2
    existing_families[fam_id] = {
        "family_id": fam_id,
        "family_title": sample["family_title"],
        "domain": sample["domain"],
        "planned_version_count": planned_count,
        "tranche_assignment": {v: "V4-B" for v in built_versions} if planned_count == len(built_versions) else
                              {**{v: "V4-B" for v in built_versions}, "remaining": "V4-C"},
        "versions_built_this_session": built_versions,
        "version_change_types": sorted({d.get("version_change_type") for d in docs}),
    }

combined_plan = {
    "schema_version": "v4-draft",
    "corpus_id": "dolved-care-alderbridge-v4",
    "status": "AUTHORING_DRAFT",
    "target": existing_plan["target"],
    "tranches": {
        "V4-A": {"target_versions": 100, "status": "built"},
        "V4-B": {"target_versions": 225, "status": "built_this_session", "actual_versions": len(combined_documents)},
        "V4-C": {"target_versions": 300, "status": "not_started"},
    },
    "families": list(existing_families.values()),
}
(ROOT / "document-family-plan.json").write_text(json.dumps(combined_plan, indent=2), encoding="utf-8")

print(f"\nDone. {len(new_entries)} new documents built. Combined total: {len(combined_documents)}.")
