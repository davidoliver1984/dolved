"""Compute the deterministic aggregate build hash used by the reproducibility
contract: sha256 over the sorted (artefact_path, sha256) pairs of every
governed artefact across the primary manifest and the two auxiliary packs
(foreign-tenant, prompt-injection-pack). Negative fixtures are excluded
since several are deliberately non-reproducible corrupt/encrypted inputs
by design, not renderer output.

Running this twice against two independently rendered copies of the same
corrected source content, in two separate output directories, and comparing
the printed hash is the proof required by the reproducibility contract.
"""
import json
import hashlib
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]


def load(p):
    return json.loads((ROOT / p).read_text(encoding="utf-8"))["documents"]


def main():
    entries = []
    entries += load("source-manifest.json")
    entries += load("foreign-tenant/source-manifest.json")
    entries += load("prompt-injection-pack/source-manifest.json")

    pairs = sorted((e["artefact_path"], e["sha256"]) for e in entries)
    concat = "\n".join(f"{p}  {h}" for p, h in pairs)
    aggregate = hashlib.sha256(concat.encode("utf-8")).hexdigest()
    print(f"Governed artefacts: {len(pairs)}")
    print(f"Aggregate build SHA-256: {aggregate}")
    return aggregate


if __name__ == "__main__":
    main()
