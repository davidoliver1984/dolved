"""Raw archive-member validator: inspects the actual tar member stream via
Python's tarfile module, NOT extracted filesystem contents and NOT `tar
-tzvf`'s listing (bsdtar's own listing silently reconciles an AppleDouble
sidecar with its companion file, hiding exactly the defect this validator
exists to catch).

Usage: validate_archive_raw.py <archive.tar.gz> <expected_regular_file_count>
"""
import sys
import tarfile
from collections import Counter

ARCHIVE_ROOT_NAME = "eval-corpus-v4-authoring"
FIXED_MTIME = 0
FIXED_MODE_FILE = 0o644
FIXED_UID = 0
FIXED_GID = 0


def main() -> int:
    archive_path = sys.argv[1]
    expected_count = int(sys.argv[2])

    problems: list[str] = []
    t = tarfile.open(archive_path, "r:gz")
    members = t.getmembers()

    top_levels = Counter(m.name.split("/")[0] for m in members)
    if list(top_levels) != [ARCHIVE_ROOT_NAME]:
        problems.append(f"expected exactly one top-level directory {ARCHIVE_ROOT_NAME!r}, found {dict(top_levels)}")

    names = [m.name for m in members]
    if len(names) != len(set(names)):
        dupes = [n for n, c in Counter(names).items() if c > 1]
        problems.append(f"duplicate member name(s): {dupes}")

    applesingle = [m.name for m in members if m.name.split("/")[-1].startswith("._")]
    if applesingle:
        problems.append(f"{len(applesingle)} AppleDouble ('._*') member(s) present: {applesingle[:10]}{'...' if len(applesingle) > 10 else ''}")

    dsstore = [m.name for m in members if m.name.split("/")[-1] == ".DS_Store"]
    if dsstore:
        problems.append(f"{len(dsstore)} .DS_Store member(s) present: {dsstore}")

    pycache = [m.name for m in members if "__pycache__" in m.name.split("/")]
    if pycache:
        problems.append(f"{len(pycache)} __pycache__ member(s) present: {pycache[:10]}{'...' if len(pycache) > 10 else ''}")

    pyc = [m.name for m in members if m.name.endswith(".pyc")]
    if pyc:
        problems.append(f"{len(pyc)} .pyc member(s) present: {pyc[:10]}{'...' if len(pyc) > 10 else ''}")

    links = [m.name for m in members if m.issym() or m.islnk()]
    if links:
        problems.append(f"{len(links)} link member(s) present (forbidden): {links}")

    devices = [m.name for m in members if m.ischr() or m.isblk() or m.isfifo()]
    if devices:
        problems.append(f"{len(devices)} device/fifo member(s) present (forbidden): {devices}")

    traversal = [m.name for m in members if ".." in m.name.split("/")]
    if traversal:
        problems.append(f"{len(traversal)} traversal-path member(s) present (forbidden): {traversal}")

    regular = [m for m in members if m.isreg()]
    dirs = [m for m in members if m.isdir()]
    other = [m for m in members if not m.isreg() and not m.isdir() and not m.issym() and not m.islnk()
             and not m.ischr() and not m.isblk() and not m.isfifo()]

    if len(regular) != expected_count:
        problems.append(f"expected exactly {expected_count} regular-file members, found {len(regular)}")

    if dirs:
        problems.append(f"expected zero explicit directory members (paths are implied by name prefixes), found {len(dirs)}")

    if other:
        problems.append(f"{len(other)} member(s) of an unexpected type present: {[m.name for m in other]}")

    non_deterministic = []
    for m in regular:
        if m.mtime != FIXED_MTIME or m.mode != FIXED_MODE_FILE or m.uid != FIXED_UID or m.gid != FIXED_GID:
            non_deterministic.append((m.name, m.mtime, oct(m.mode), m.uid, m.gid))
    if non_deterministic:
        problems.append(f"{len(non_deterministic)} member(s) with non-fixed mtime/mode/uid/gid: {non_deterministic[:5]}")

    checksum_inventory_members = [m for m in regular if m.name == f"{ARCHIVE_ROOT_NAME}/checksums/checksums.sha256"]
    if len(checksum_inventory_members) != 1:
        problems.append("checksums/checksums.sha256 must appear exactly once among regular-file members")

    print(f"Archive: {archive_path}")
    print(f"Total members: {len(members)}")
    print(f"Regular-file members: {len(regular)}")
    print(f"Directory members: {len(dirs)}")
    print(f"Top-level entries: {list(top_levels)}")
    print(f"Problems: {len(problems)}")
    for p in problems:
        print(" ", p)
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
