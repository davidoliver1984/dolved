"""Run the REAL Dolved application chunking pipeline (extraction ->
structural normalisation -> BaselineStructuralChunker) against every
primary-corpus document, inside the cached rag-platform-ai:development
image, network-disabled, with the corpus mounted read-only.

Intended invocation (from the host):

  docker run --rm --network none \
    -v <corpus-authoring-dir>:/corpus:ro \
    rag-platform-ai:development \
    python3 /corpus/generate/run_real_chunking_pipeline.py /corpus > result.json

Writes nothing inside the container; the complete machine-readable result
is printed to stdout as one JSON object, captured by the host's shell
redirect. No network access is made or required.
"""
import json
import sys
from collections import Counter
from pathlib import Path
from uuid import NAMESPACE_URL, UUID, uuid5

from app.chunking.baseline import BaselineStructuralChunker
from app.chunking.tokenizer import TiktokenTokenizer
from app.extraction.docx.factory import create_docx_extractor
from app.extraction.models import ExtractionContext
from app.extraction.pdf.factory import create_pdf_extractor
from app.extraction.plain_text import PlainTextExtractor
from app.normalisation.structural import StructuralNormaliser


def extractor_for(media_type: str):
    if media_type == "application/pdf":
        return create_pdf_extractor()
    if media_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        return create_docx_extractor()
    if media_type.startswith("text/"):
        return PlainTextExtractor()
    raise ValueError(f"unsupported media type: {media_type}")


def main() -> int:
    corpus_root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("/corpus")
    manifest = json.loads((corpus_root / "source-manifest.json").read_text(encoding="utf-8"))
    docs = manifest["documents"]

    tokenizer = TiktokenTokenizer()
    chunker = BaselineStructuralChunker(tokenizer=tokenizer)
    normaliser = StructuralNormaliser()

    per_document = []
    exact_distribution: Counter = Counter()
    extraction_warning_counts: Counter = Counter()
    chunking_warning_counts: Counter = Counter()
    physical_errors = []

    for doc in docs:
        family_id = doc["family_id"]
        version_id = doc["version_id"]
        artefact_path = corpus_root / doc["artefact_path"]
        media_type = doc["media_type"]
        try:
            source_bytes = artefact_path.read_bytes()
            workspace_id = uuid5(NAMESPACE_URL, "dolved-v4-corpus")
            document_id = uuid5(NAMESPACE_URL, f"{family_id}::{version_id}")
            context = ExtractionContext(
                workspace_id=workspace_id,
                document_id=document_id,
                source_media_type=media_type,
            )
            extracted = extractor_for(media_type).extract(source_bytes, context=context)
            normalised = normaliser.normalise(extracted)
            result = chunker.chunk(normalised)

            n_chunks = len(result.chunks)
            exact_distribution[n_chunks] += 1
            for w in extracted.warnings:
                extraction_warning_counts[w.code] += 1
            for w in result.warnings:
                chunking_warning_counts[w.code] += 1

            per_document.append({
                "family_id": family_id, "version_id": version_id,
                "format": doc["format"], "chunk_count": n_chunks,
                "extraction_warning_codes": [w.code for w in extracted.warnings],
                "chunking_warning_codes": [w.code for w in result.warnings],
            })
        except Exception as exc:  # noqa: BLE001
            physical_errors.append({
                "family_id": family_id, "version_id": version_id,
                "error_type": type(exc).__name__, "error_message": str(exc),
            })

    tiers = {"1": 0, "2": 0, "3": 0, "4-8": 0, "9+": 0}
    for count, freq in exact_distribution.items():
        if count == 1:
            tiers["1"] += freq
        elif count == 2:
            tiers["2"] += freq
        elif count == 3:
            tiers["3"] += freq
        elif 4 <= count <= 8:
            tiers["4-8"] += freq
        else:
            tiers["9+"] += freq

    combined_warning_counts = dict(extraction_warning_counts)
    for k, v in chunking_warning_counts.items():
        combined_warning_counts[k] = combined_warning_counts.get(k, 0) + v

    output = {
        "schema_version": "v4-real-pipeline-run-1",
        "documents_processed": len(docs),
        "physical_errors": physical_errors,
        "exact_chunk_count_distribution": {str(k): v for k, v in sorted(exact_distribution.items())},
        "tier_distribution": tiers,
        "extraction_warning_counts": dict(extraction_warning_counts),
        "chunking_warning_counts": dict(chunking_warning_counts),
        "combined_warning_counts": combined_warning_counts,
        "chunk_configuration": {
            "target_tokens": chunker.configuration.target_tokens,
            "max_tokens": chunker.configuration.max_tokens,
            "overlap_tokens": chunker.configuration.overlap_tokens,
            "preferred_min_tokens": chunker.configuration.preferred_min_tokens,
            "tokenizer": {
                "library": tokenizer.identity.library,
                "library_version": tokenizer.identity.library_version,
                "encoding": tokenizer.identity.encoding,
                "vocabulary_fingerprint": tokenizer.identity.vocabulary_fingerprint,
            },
        },
        "per_document": per_document,
    }
    print(json.dumps(output, indent=2, sort_keys=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
