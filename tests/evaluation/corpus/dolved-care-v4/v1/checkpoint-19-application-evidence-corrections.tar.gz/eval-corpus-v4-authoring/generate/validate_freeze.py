"""Provider-free freeze-candidate validation beyond the primary validator."""
from __future__ import annotations

import hashlib
import json
import re
import tempfile
from pathlib import Path

import pdfplumber
from docx import Document

import render

ROOT = render.ROOT
INVENTORY = ROOT / "checksums/checksums.sha256"
EVAL_MARKERS = ("expected_answer", "gold_answer", "relevance_judgement", "relevance_label")
SECRET_MARKERS = ("OPENAI_API_KEY", "VOYAGE_API_KEY", "sk-proj-", "AKIA", "BEGIN PRIVATE KEY")


def load(path: str) -> dict:
    return json.loads((ROOT / path).read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def extract(path: Path, fmt: str) -> str:
    if fmt == "txt":
        return path.read_text(encoding="utf-8")
    if fmt == "pdf":
        with pdfplumber.open(path) as pdf:
            return "\n".join(page.extract_text() or "" for page in pdf.pages)
    doc = Document(path)
    body = "\n".join(p.text for p in doc.paragraphs)
    footer = "\n".join(p.text for section in doc.sections for p in section.footer.paragraphs)
    return body + "\n" + footer


def normalized_master(path: Path) -> str:
    text = path.read_text(encoding="utf-8")
    text = re.sub(r"^<!--.*?-->\s*", "", text, count=1, flags=re.DOTALL)
    text = re.sub(r"\n---\n[^\n]+\s*$", "", text)
    return re.sub(r"\s+", " ", text).strip()


def main() -> int:
    errors: list[str] = []
    ordinary = []
    for path in ROOT.rglob("*"):
        if path.is_symlink():
            errors.append(f"link forbidden: {path.relative_to(ROOT)}")
        if path.is_file():
            ordinary.append(path)
            if path.name == ".DS_Store" or path.name.startswith("._") or path.suffix == ".pyc" or "__pycache__" in path.parts:
                errors.append(f"transient artefact forbidden: {path.relative_to(ROOT)}")

    expected: dict[str, str] = {}
    for line in INVENTORY.read_text(encoding="utf-8").splitlines():
        digest, rel = line.split("  ", 1)
        if rel in expected:
            errors.append(f"duplicate checksum entry: {rel}")
        expected[rel] = digest
    actual_paths = {p.relative_to(ROOT).as_posix() for p in ordinary if p != INVENTORY}
    if set(expected) != actual_paths:
        errors.append(f"checksum coverage mismatch missing={sorted(actual_paths-set(expected))} stale={sorted(set(expected)-actual_paths)}")
    for rel, digest in expected.items():
        path = ROOT / rel
        if path.is_file() and sha(path) != digest:
            errors.append(f"checksum mismatch: {rel}")
    if INVENTORY.relative_to(ROOT).as_posix() in expected:
        errors.append("checksum inventory must not include itself")

    primary = load("source-manifest.json")["documents"]
    foreign = load("foreign-tenant/source-manifest.json")["documents"]
    injections = load("prompt-injection-pack/source-manifest.json")["documents"]
    fixtures = load("negative-fixtures/negative-fixtures-manifest.json")["fixtures"]
    if len(primary) != 300 or len({d["family_id"] for d in primary}) != 185:
        errors.append("primary count/family count mismatch")
    if len(foreign) != 12 or len(injections) != 6 or len(fixtures) != 13:
        errors.append("auxiliary count mismatch")
    if sum(bool(d.get("prompt_injection")) for d in primary) + len(injections) != 9:
        errors.append("prompt-injection count mismatch")
    if any(d["domain"] == "health" + "_safety" for d in primary + injections):
        errors.append("split health-and-safety domain remains")

    for fixture in fixtures:
        path = ROOT / "negative-fixtures" / fixture["filename"]
        if not path.is_file():
            errors.append(f"negative fixture missing: {fixture['filename']}")
            continue
        if sha(path) != fixture["sha256"] or path.stat().st_size != fixture["byte_count"]:
            errors.append(f"negative fixture identity mismatch: {fixture['filename']}")
        category = fixture["category"]
        if path.suffix == ".pdf" and not path.read_bytes().startswith(b"%PDF-"):
            errors.append(f"negative PDF signature mismatch: {fixture['filename']}")
        if category in {"corrupt_pdf", "password_protected_pdf"}:
            try:
                with pdfplumber.open(path) as pdf:
                    _ = "".join(page.extract_text() or "" for page in pdf.pages)
            except Exception:  # Expected typed-invalid physical fixture.
                pass
            else:
                errors.append(f"invalid PDF unexpectedly extracted: {fixture['filename']}")

    for documents in (primary, foreign, injections):
        for item in documents:
            path = ROOT / item["artefact_path"]
            if sha(path) != item["sha256"] or path.stat().st_size != item["byte_count"]:
                errors.append(f"manifest identity mismatch: {item['artefact_path']}")
            try:
                extract(path, item["format"])
            except Exception as exc:  # noqa: BLE001
                errors.append(f"physical extraction failed: {item['artefact_path']}:{type(exc).__name__}")

    for item in foreign:
        text = extract(ROOT / item["artefact_path"], item["format"])
        if "Alderbridge Care Group | Uncontrolled if printed" in text:
            errors.append(f"primary branding leaked into foreign artefact: {item['artefact_path']}")
        if not re.search(r"Thornfield Support Services\s+(?:\|\s*)?Uncontrolled if printed", text):
            errors.append(f"foreign footer missing: {item['artefact_path']}")
    for item in injections:
        text = extract(ROOT / item["artefact_path"], item["format"])
        if not re.search(r"Dolved Synthetic Security Fixture\s+(?:\|\s*)?Uncontrolled if printed", text):
            errors.append(f"neutral injection footer missing: {item['artefact_path']}")

    thin = [
        f"{d['family_id']}:{d['version_id']}"
        for d in primary
        if d["word_count_approx"] < 100 and d["content_type"] == "policy"
    ]
    if thin:
        errors.append(f"genuine policies remain under 100 words: {thin}")

    v1m = ROOT / "semantic-masters/v4b.hr.staff-handover-procedure/v1.md"
    v2m = ROOT / "semantic-masters/v4b.hr.staff-handover-procedure/v2.md"
    if normalized_master(v1m) != normalized_master(v2m):
        errors.append("formatting-only semantic masters differ")
    pair = [d for d in primary if d["family_id"] == "v4b.hr.staff-handover-procedure"]
    if len({d["sha256"] for d in pair}) != 2:
        errors.append("formatting-only rendered DOCX bytes do not differ")

    source = ROOT / "artifacts/docx/complaints-policy.docx"
    duplicate = ROOT / "negative-fixtures/complaints-policy-COPY.docx"
    if sha(source) != sha(duplicate):
        errors.append("exact-duplicate fixture is not byte-identical")

    diff_report = load("version-diff-report.json")
    if diff_report["comparison_count"] != 115 or diff_report["failure_count"] != 0:
        errors.append("version-diff report incomplete or failing")

    # --- Reproducibility contract checks -----------------------------------
    contract_path = ROOT / "authoring-governance" / "runtime-contract.json"
    if not contract_path.is_file():
        errors.append("runtime-contract.json is missing")
    else:
        contract = load("authoring-governance/runtime-contract.json")
        if set(contract.get("corpus_local_profile", {})) == set() or "application_pipeline_profile" not in contract:
            errors.append("runtime-contract.json must declare both corpus_local_profile and "
                           "application_pipeline_profile as separate named runtime profiles")
        else:
            clp = contract["corpus_local_profile"]
            required_clp_keys = {
                "python_runtime", "platform", "dependency_lock", "rendering_entry_points",
                "environment_variables_and_locale", "deterministic_metadata_and_timestamp_inputs",
                "expected_complete_build_aggregate_sha256",
            }
            missing_keys = required_clp_keys - set(clp)
            if missing_keys:
                errors.append(f"runtime-contract.json corpus_local_profile missing section(s): {sorted(missing_keys)}")
            checkpointing = clp.get("rendering_entry_points", {}).get("checkpointing", {})
            archive_builder = checkpointing.get("archive_builder", "")
            if "tar" == archive_builder.strip().lower() or archive_builder.strip() == "":
                errors.append("runtime-contract.json's checkpointing.archive_builder must name the "
                               "deterministic Python builder, not the system tar binary")
            app_profile = contract["application_pipeline_profile"]
            required_app_keys = {"scope", "status", "application_source_identity",
                                  "chunker_configuration_identity", "measured_output_evidence_identity",
                                  "cached_image_identity"}
            missing_app_keys = required_app_keys - set(app_profile)
            if missing_app_keys:
                errors.append(f"runtime-contract.json application_pipeline_profile missing section(s): {sorted(missing_app_keys)}")
            status_text = str(app_profile.get("status", "")).lower()
            success_claimed = any(w in status_text for w in ("reproduced", "succeeded", "successful"))
            if success_claimed:
                if "measured_output_evidence_identity" not in app_profile:
                    errors.append("application_pipeline_profile claims a successful reproduction but has "
                                   "no measured_output_evidence_identity recording what was actually run")
            elif "could not" not in status_text and "reconstruct" not in status_text and "external" not in status_text:
                if "reconstruction_attempt_this_session" not in app_profile:
                    errors.append("application_pipeline_profile claims a status without disclosing whether "
                                   "this session actually reconstructed/ran it")

            # --- Canonical source-and-lock aggregate: independently reconstruct
            # the exact byte stream from the RECORDED per-file hashes (portable,
            # does not require the main repository to be present) and verify it
            # hashes to the recorded aggregate.
            src_identity = app_profile.get("application_source_identity", {})
            records = src_identity.get("source_and_lock_files")
            recorded_aggregate = src_identity.get("source_and_lock_aggregate_sha256")
            if not records or not recorded_aggregate:
                errors.append("application_source_identity is missing source_and_lock_files or "
                               "source_and_lock_aggregate_sha256")
            else:
                sorted_records = sorted(records, key=lambda r: r["path"])
                if [r["path"] for r in sorted_records] != [r["path"] for r in records]:
                    errors.append("application_source_identity.source_and_lock_files is not recorded in "
                                   "sorted path order")
                payload = b"".join(
                    r["path"].encode("utf-8") + b"\x00" + r["sha256"].encode("utf-8") + b"\x0a"
                    for r in sorted_records
                )
                reconstructed = hashlib.sha256(payload).hexdigest()
                if reconstructed != recorded_aggregate:
                    errors.append(f"application_source_identity aggregate mismatch: reconstructing the "
                                   f"canonical byte stream from the recorded per-file hashes yields "
                                   f"{reconstructed}, not the recorded {recorded_aggregate}")
                if len(records) != 25:
                    errors.append(f"application_source_identity.source_and_lock_files has {len(records)} "
                                   f"entries, expected 25")
        claim = contract.get("reproducibility_claim", {})
        if "byte-reproducible" not in claim.get("claim", "").lower():
            errors.append("runtime-contract.json does not state a byte-reproducibility claim")
        if not any("self-contained" in n or "vendor" in n for n in claim.get("not_claimed", [])):
            errors.append("runtime-contract.json does not explicitly disclaim self-containment/vendoring")
        if not any("application chunking pipeline" in n or "application_pipeline_profile" in n for n in claim.get("not_claimed", [])):
            errors.append("runtime-contract.json does not disclaim corpus_local_profile reproducing the application pipeline")

    lock_path = ROOT / "authoring-governance" / "requirements.lock"
    if not lock_path.is_file():
        errors.append("requirements.lock is missing")
    else:
        import subprocess
        import sys as _sys
        venv_pip = Path(_sys.executable).parent / "pip"
        try:
            current_freeze = subprocess.run(
                [str(venv_pip), "freeze"], capture_output=True, text=True, check=True
            ).stdout.strip().splitlines()
            locked = lock_path.read_text(encoding="utf-8").strip().splitlines()
            if sorted(current_freeze) != sorted(locked):
                errors.append("requirements.lock does not match the currently installed environment (drift)")
        except Exception as exc:  # noqa: BLE001
            errors.append(f"could not verify requirements.lock against live environment: {exc}")

    # renderer_tool / renderer_version coverage and identity on every relevant entry
    for label, documents in (("primary", primary), ("foreign", foreign), ("injections", injections)):
        for item in documents:
            fmt = item["format"]
            expected_tool = render.RENDERER_VERSION.get(fmt)
            expected_version = render.RENDERER_LIBRARY_VERSION.get(fmt)
            if item.get("renderer_tool") != expected_tool:
                errors.append(f"{label} {item['family_id']}::{item['version_id']}: renderer_tool "
                               f"missing or mismatched (expected {expected_tool!r}, found "
                               f"{item.get('renderer_tool')!r})")
            if not item.get("renderer_version") or item.get("renderer_version") != expected_version:
                errors.append(f"{label} {item['family_id']}::{item['version_id']}: renderer_version "
                               f"missing, placeholder, or mismatched (expected {expected_version!r}, "
                               f"found {item.get('renderer_version')!r})")

    # no unrecorded rendering dependency: every top-level import in the core
    # pipeline scripts must be declared somewhere in requirements.lock or be
    # a standard-library module.
    import importlib.util as _ilu
    locked_names = set()
    if lock_path.is_file():
        for line in lock_path.read_text(encoding="utf-8").splitlines():
            if "==" in line:
                locked_names.add(line.split("==")[0].strip().lower().replace("_", "-"))
    pipeline_scripts = [
        "render.py", "validate.py", "validate_version_fidelity.py",
        "validate_freeze.py", "chunk_estimate.py", "apply_expansions.py",
    ]
    import_name_to_dist = {
        "docx": "python-docx", "pptx": "python-pptx", "PIL": "pillow",
        "reportlab": "reportlab", "pdfplumber": "pdfplumber", "tiktoken": "tiktoken",
        "pikepdf": "pikepdf", "lxml": "lxml",
    }
    for script_name in pipeline_scripts:
        script_path = ROOT / "generate" / script_name
        if not script_path.is_file():
            continue
        text = script_path.read_text(encoding="utf-8")
        for m in re.finditer(r"^\s*(?:import|from)\s+([A-Za-z_][A-Za-z0-9_]*)", text, flags=re.MULTILINE):
            top_module = m.group(1)
            if _ilu.find_spec(top_module) is not None and top_module in _sys.stdlib_module_names:
                continue
            if top_module in ("render", "generate", "app"):
                continue
            if (ROOT / "generate" / f"{top_module}.py").is_file():
                continue  # local sibling module (e.g. an expand_*/batch* module), not a pip package
            dist_name = import_name_to_dist.get(top_module, top_module).lower()
            if dist_name not in locked_names:
                errors.append(f"unrecorded rendering dependency: {script_name} imports "
                               f"{top_module!r}, not declared in requirements.lock")

    # documentation agreement: README.md / validation-report.md numeric claims
    # must match the live manifests, not a stale snapshot.
    by_family_doc: dict[str, int] = {}
    for d in primary:
        by_family_doc[d["family_id"]] = by_family_doc.get(d["family_id"], 0) + 1
    doc_checks = {
        f"{len(primary)} primary versions": len(primary) == 300,
        f"{len(by_family_doc)} families": len(by_family_doc) == 185,
    }
    readme_text = (ROOT / "README.md").read_text(encoding="utf-8") if (ROOT / "README.md").is_file() else ""
    for claim, ok in doc_checks.items():
        if not ok:
            errors.append(f"internal consistency check failed for claim basis: {claim}")
    if readme_text and str(len(primary)) not in readme_text:
        errors.append(f"README.md does not mention the current primary document count ({len(primary)})")

    for path in ordinary:
        if path.suffix.lower() not in {".json", ".md", ".txt", ".py", ".sha256"}:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for marker in EVAL_MARKERS:
            if marker in text and path.name not in {"validate.py", "validate_freeze.py"}:
                errors.append(f"evaluation marker {marker} in {path.relative_to(ROOT)}")
        for marker in SECRET_MARKERS:
            if marker in text and path.name not in {"validate.py", "validate_freeze.py"}:
                errors.append(f"credential marker {marker} in {path.relative_to(ROOT)}")

    representative = {
        "human_title": "Deterministic PDF Proof",
        "brand_identity": "Alderbridge Care Group",
        "sections": [("Purpose", "Identical input must produce identical output bytes.")],
    }
    if render.render_pdf(representative) != render.render_pdf(representative):
        errors.append("representative PDF rendering is nondeterministic")

    stale = []
    for path in (ROOT / "README.md", ROOT / "validation-report.md", ROOT / "chunk-profile.json",
                 ROOT / "authoring-spec.md"):
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8")
        for claim in ("V4-C does not exist", "V4-C (300) was not started", "10 of 12",
                      "62 three-chunk", "75 four-to-eight", "exactly three chunks: 62",
                      "four to eight chunks: 75"):
            if claim in text:
                stale.append(f"{path.name}:{claim}")
        # the old 91/42/62/75/30 figure is legitimate ONLY as explicit historical
        # context (e.g. "supersedes ... 91/42/62/75/30"); flag it appearing on its
        # own as if it were a live claim.
        import re as _re
        for m in _re.finditer(r"91/42/62/75/30", text):
            window = text[max(0, m.start() - 120):m.end() + 120].lower()
            if not any(w in window for w in ("supersedes", "predated", "prior", "previous", "old", "historical")):
                stale.append(f"{path.name}:91/42/62/75/30 (not framed as historical)")
    if stale:
        errors.append(f"stale documentation claims: {stale}")

    # the corrected, measured final chunk tier distribution must appear consistently
    chunk_profile_path = ROOT / "chunk-profile.json"
    if chunk_profile_path.is_file():
        cp = load("chunk-profile.json")
        expected_tiers = {"1": 91, "2": 42, "3": 61, "4-8": 76, "9+": 30}
        if cp.get("tier_distribution") != expected_tiers:
            errors.append(f"chunk-profile.json tier_distribution does not match the corrected measured "
                           f"distribution {expected_tiers}, found {cp.get('tier_distribution')}")

    print(f"Freeze validation problems: {len(errors)}")
    for error in errors:
        print(f"FAIL: {error}")
    print(f"Checksum entries: {len(expected)}")
    print(f"Ordinary archived files excluding checksum inventory: {len(actual_paths)}")
    print("Checksum inventory self-reference: deliberately excluded")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
