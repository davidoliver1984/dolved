"""Build the complete, deliberately non-self-referential checksum authority."""
from __future__ import annotations

import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INVENTORY = ROOT / "checksums/checksums.sha256"
FORBIDDEN_NAMES = {".DS_Store"}


def governed_files() -> list[Path]:
    files = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path == INVENTORY:
            continue
        if path.name in FORBIDDEN_NAMES or path.name.startswith("._") or path.suffix == ".pyc":
            raise ValueError(f"transient file cannot enter checksum authority: {path.relative_to(ROOT)}")
        if "__pycache__" in path.parts:
            raise ValueError(f"cache file cannot enter checksum authority: {path.relative_to(ROOT)}")
        files.append(path)
    return sorted(files, key=lambda p: p.relative_to(ROOT).as_posix())


def main() -> None:
    lines = []
    for path in governed_files():
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        lines.append(f"{digest}  {path.relative_to(ROOT).as_posix()}")
    INVENTORY.parent.mkdir(parents=True, exist_ok=True)
    INVENTORY.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Checksum authority written: {len(lines)} governed files; inventory self-excluded.")


if __name__ == "__main__":
    main()
