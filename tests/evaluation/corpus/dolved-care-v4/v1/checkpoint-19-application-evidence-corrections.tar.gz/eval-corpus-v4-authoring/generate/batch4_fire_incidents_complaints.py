"""V4-A batch 4: Fire safety, incident reporting, complaints."""

DOCS = [
{
    "family_id": "v4.fire.fire-safety-policy", "family_title": "Fire Safety Policy",
    "version_id": "v1", "domain": "fire-safety", "content_type": "policy",
    "human_title": "Fire Safety Policy", "filename": "fire-safety-policy.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-11-01", "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Responsibility", "Each registered manager is the site's Responsible Person for fire safety under the Regulatory Reform (Fire Safety) Order 2005, supported by a nominated fire warden on every shift."),
        ("Fire risk assessment", "A fire risk assessment is completed annually and reviewed after any structural change or near miss, and is available in the site fire file."),
    ],
},
{
    "family_id": "v4.fire.evacuation-procedure-riverside", "family_title": "Fire Evacuation Procedure — Riverside House",
    "version_id": "v1", "domain": "fire-safety", "content_type": "policy",
    "human_title": "Fire Evacuation Procedure — Riverside House", "filename": "riverside-evacuation-procedure.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "specific",
    "applicability_locations": ["location.riverside-house"],
    "effective_date": "2025-11-01", "messiness_level": "mild", "messiness_axes": ["local_vs_regional_variance"],
    "front_matter": "Site-specific procedure for Riverside House only, reflecting its progressive horizontal evacuation layout.",
    "sections": [
        ("Evacuation strategy", "Riverside House uses a progressive horizontal evacuation strategy: on the fire alarm, residents are first moved to the adjoining fire compartment via the nearest fire door, not directly outside, unless the fire is confirmed in that compartment or a full evacuation is ordered."),
        ("Assembly point", "The assembly point is the car park at the front of the building, away from the fire access route."),
    ],
},
{
    "family_id": "v4.fire.evacuation-procedure-oakfield", "family_title": "Fire Evacuation Procedure — Oakfield Lodge",
    "version_id": "v1", "domain": "fire-safety", "content_type": "policy",
    "human_title": "Fire Evacuation Procedure — Oakfield Lodge", "filename": "oakfield-evacuation-procedure.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "specific",
    "applicability_locations": ["location.oakfield-lodge"],
    "effective_date": "2025-11-01", "messiness_level": "mild", "messiness_axes": ["local_vs_regional_variance"],
    "front_matter": "Site-specific procedure for Oakfield Lodge only, a single-storey building using simultaneous evacuation.",
    "sections": [
        ("Evacuation strategy", "Oakfield Lodge is single storey and uses simultaneous evacuation: on the fire alarm, all residents, staff and visitors evacuate directly to the assembly point without delay."),
        ("Assembly point", "The assembly point is the garden patio area, at least 20 metres from the building."),
    ],
},
{
    "family_id": "v4.fire.peep-form", "family_title": "Personal Emergency Evacuation Plan (PEEP) Form",
    "version_id": "v1", "domain": "fire-safety", "content_type": "form",
    "human_title": "Personal Emergency Evacuation Plan (PEEP)", "filename": "peep-form.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-11-01", "messiness_level": "moderate", "messiness_axes": ["dense_table", "abbreviation_heavy"],
    "sections": [
        ("Purpose", "A PEEP is completed for every person supported on admission and reviewed every 6 months or after any change in mobility, to record how they will be assisted to evacuate."),
        ("__table__", [
            ["Field", "Detail"],
            ["Mobility level", "Independent / needs assistance / needs equipment"],
            ["Equipment required", "e.g. evac chair, wheelchair"],
            ["Number of staff needed to assist", ""],
            ["Cognitive considerations", "e.g. may need reassurance, may resist evacuation"],
        ]),
    ],
},
{
    "family_id": "v4.fire.drill-record-schedule", "family_title": "Fire Drill Record and Schedule",
    "version_id": "v1", "domain": "fire-safety", "content_type": "schedule_reference",
    "human_title": "Fire Drill Record and Schedule", "filename": "fire-drill-record.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-11-01", "messiness_level": "mild", "messiness_axes": ["dense_table"],
    "sections": [
        ("Frequency", "A fire drill is held at each site at least quarterly, at varying times including at least one night-time simulated drill per year."),
        ("__table__", [
            ["Site", "Last drill", "Evacuation time achieved"],
            ["Riverside House", "12/11/2025", "4 min 40 sec"],
            ["Moorland View", "18/11/2025", "3 min 55 sec"],
            ["Oakfield Lodge", "20/11/2025", "3 min 10 sec"],
        ]),
    ],
},
{
    "family_id": "v4.fire.warden-training-record", "family_title": "Fire Warden Training Record",
    "version_id": "v1", "domain": "fire-safety", "content_type": "onboarding_training",
    "human_title": "Fire Warden Training Record", "filename": "fire-warden-training-record.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-11-01", "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Requirement", "Every site must have at least 2 trained fire wardens on duty at all times, retrained every 2 years, with records kept on the training matrix."),
    ],
},
{
    "family_id": "v4.incident.incident-reporting-policy", "family_title": "Incident Reporting Policy",
    "version_id": "v1", "domain": "incident-reporting", "content_type": "policy",
    "human_title": "Incident Reporting Policy", "filename": "incident-reporting-policy.pdf",
    "format": "pdf", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-08-01", "messiness_level": "moderate",
    "messiness_axes": ["abbreviation_heavy", "cross_reference"],
    "sections": [
        ("Reportable incidents", "All accidents, near misses, safeguarding concerns, medication errors and property damage must be reported using the appropriate form (see the Accident and Incident Report Form, Safeguarding Referral Form, or Medication Error Report Form as applicable) within 24 hours."),
        ("RIDDOR", "Incidents meeting the RIDDOR threshold — death, specified injury, over-7-day incapacitation, or certain dangerous occurrences — are reported to the HSE within the statutory timescale by the Health and Safety Lead."),
        ("Learning from incidents", "All incidents are reviewed monthly at the Health and Safety Committee to identify trends and required actions."),
    ],
},
{
    "family_id": "v4.complaints.complaints-policy", "family_title": "Complaints Policy",
    "version_id": "v1", "domain": "complaints", "content_type": "policy",
    "human_title": "Complaints Policy", "filename": "complaints-policy.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-07-01", "messiness_level": "mild", "messiness_axes": ["header_footer_boilerplate"],
    "sections": [
        ("How to complain", "A complaint may be made verbally to any member of staff or in writing to the registered manager, by the person supported, a family member, or their representative."),
        ("Timescales", "A complaint is acknowledged within 3 working days and a full written response provided within 20 working days, or sooner where possible."),
        ("Escalation", "A complainant not satisfied with the response may escalate to the Alderbridge Quality Lead, and ultimately to the Local Government and Social Care Ombudsman or CQC."),
    ],
},
{
    "family_id": "v4.complaints.duty-of-candour-guidance", "family_title": "Duty of Candour Guidance",
    "version_id": "v1", "domain": "complaints", "content_type": "faq_guidance",
    "human_title": "Duty of Candour: What Staff Need to Know", "filename": "duty-of-candour-guidance.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-07-01", "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("What it means", "When something goes wrong that causes harm, we must be open and honest with the person affected and their family, apologise, and explain what will be done to prevent it happening again."),
        ("Who leads this", "The registered manager leads the duty of candour conversation, though any member of staff involved may be asked to contribute factual detail."),
    ],
},
{
    "family_id": "v4.complaints.compliments-and-feedback-log", "family_title": "Compliments and Feedback Log",
    "version_id": "v1", "domain": "complaints", "content_type": "schedule_reference",
    "human_title": "Compliments and Feedback Log — Template", "filename": "compliments-feedback-log-template.docx",
    "format": "docx", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-07-01", "messiness_level": "mild", "messiness_axes": ["dense_table"],
    "sections": [
        ("__table__", [
            ["Date", "Source", "Summary", "Shared with team?"],
            ["", "", "", ""],
        ]),
        ("Purpose", "Positive feedback is logged alongside complaints to give a balanced picture at the quarterly Quality Committee."),
    ],
},
{
    "family_id": "v4.incident.near-miss-briefing-memo", "family_title": "Near Miss Briefing Memo — Wet Floor Signage",
    "version_id": "v1", "domain": "incident-reporting", "content_type": "minutes_memo",
    "human_title": "Staff Briefing Memo: Wet Floor Signage Near Miss", "filename": "briefing-memo-wet-floor.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "specific",
    "applicability_locations": ["location.meadow-court"],
    "effective_date": "2026-01-20", "messiness_level": "mild", "messiness_axes": ["inconsistent_dates"],
    "sections": [
        ("Memo", "Following a near miss on 18/01/26 where a visitor almost slipped on a wet corridor floor at Meadow Court, all housekeeping staff are reminded to place warning signage at BOTH ends of any wet area, not just one, until the floor is fully dry. This briefing supplements, and does not replace, the Slips, Trips and Falls Prevention Procedure."),
    ],
},
{
    "family_id": "v4.complaints.advocacy-contacts", "family_title": "Independent Advocacy Contacts",
    "version_id": "v1", "domain": "complaints", "content_type": "schedule_reference",
    "human_title": "Independent Advocacy Contacts", "filename": "advocacy-contacts.txt",
    "format": "txt", "governance_status": "approved", "applicability_scope": "universal",
    "effective_date": "2025-07-01", "messiness_level": "clean", "messiness_axes": [],
    "sections": [
        ("Purpose", "People supported and their families may wish to contact an independent advocate rather than raise a concern directly. A current list of local advocacy providers is held at reception at every site and is provided proactively when a complaint is raised."),
    ],
},
]
