"""Apply bounded freeze-audit corrections and rebuild governed V4 artefacts.

Provider-free, local-only and idempotent. This is the final reproducibility
step after the historical tranche builders have populated the authoring tree.
"""
from __future__ import annotations

import difflib
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path

import render

ROOT = render.ROOT

REALISM_ADDITIONS: dict[str, list[tuple[str, str]]] = {
    "v4b.hs.legionella-control-procedure": [
        ("Control programme", "The responsible person maintains a written scheme covering hot and cold-water temperatures, sentinel outlets, little-used outlets, shower-head cleaning and the response to an out-of-range result. Maintenance staff record each check against the asset and outlet identifier so a missed check can be distinguished from a compliant reading. A room closure, plumbing alteration or prolonged vacancy triggers a fresh assessment before the outlet returns to use."),
        ("Out-of-range response", "A temperature or hygiene result outside the written scheme is reported to the registered manager and facilities lead on the same working day. The outlet is isolated where continued use could expose a resident or staff member, remedial flushing or engineering work is commissioned, and reopening requires a documented satisfactory recheck. A suspected case of legionellosis is escalated immediately through infection-control and public-health routes rather than managed as routine maintenance."),
        ("Assurance and records", "The registered manager reviews the log monthly for missed checks and repeated marginal readings. The facilities lead reviews contractor reports, corrective actions and trend data quarterly. Risk assessments, schematics, monitoring records, laboratory results and remedial-work evidence are retained together so an auditor can reconstruct the control history for each water system."),
    ],
    "v4b.medication.homely-remedies-policy": [
        ("Authorisation and stock", "Only remedies listed on the current approved homely-remedies schedule may be held. A pharmacist or prescriber-approved protocol states the indication, dose, interval, maximum duration, contraindications and escalation point for each remedy. Stock is obtained through the normal pharmacy route, stored securely, checked monthly for expiry and never transferred between residents as though it were prescribed medication."),
        ("Assessment and administration", "Before administration, trained staff assess the resident's symptoms, allergies, prescribed medicines and relevant conditions and check that the presentation remains suitable for self-limiting treatment. The resident's agreement is obtained and the dose, time, reason and effect are recorded on the medication record. A second dose is not given outside the protocol simply because symptoms persist."),
        ("Escalation and review", "Unexpected, severe or worsening symptoms, repeated requests, possible interaction, or use beyond the stated duration require clinical advice. The registered manager reviews use monthly for patterns that could indicate an untreated condition or inappropriate routine administration. Errors, adverse reactions and stock discrepancies follow the Medication Error Reporting Procedure and are not concealed within routine notes."),
    ],
    "v4b.hr.hybrid-working-trial-policy": [
        ("Eligibility and agreement", "Hybrid working under the trial was available only where duties, service coverage, information security and supervision could be maintained. Each agreement identified the normal workplace, permitted remote days, core availability, equipment and review date. It did not create a permanent contractual entitlement, and a manager documented the operational reason where a role or request could not participate."),
        ("Working safely and securely", "Staff used managed equipment, private connections and approved storage, kept paper records out of shared household areas and reported loss or suspected compromise immediately. Working time, sickness reporting, confidentiality and performance standards remained unchanged. A home workstation assessment was completed before regular remote working and repeated after a material change."),
        ("Trial closure and records", "At the stated trial end, managers reviewed service impact, attendance, staff feedback and any security or health-and-safety incidents. Existing arrangements ended or continued only under an explicitly approved successor decision. Requests, assessments, review notes and closure decisions were retained with the employment record so the absence of current authority could not be mistaken for an informal extension."),
    ],
    "v4b.training.apprenticeship-programme-policy": [
        ("Programme controls", "An apprenticeship place required an approved role, funding confirmation, a named training provider and protected learning time. The line manager, apprentice and provider agreed the standard, expected duration, workplace evidence and review cycle before enrolment. Normal safer-recruitment, right-to-work and role-competency requirements still applied; apprenticeship status did not authorise unsupervised work beyond demonstrated competence."),
        ("Progress and support", "Managers held documented progress reviews with the provider at least every twelve weeks and acted on missed learning, welfare concerns or placement barriers. Reasonable adjustments and additional learning support were considered promptly. Off-the-job learning was planned within paid time and recorded accurately rather than reconstructed at the end of the programme."),
        ("Pause, withdrawal and relaunch", "Where the programme was paused, no new enrolment or informal promise of a place could be made. Existing apprentices received an individual continuity plan covering provider support, supervision and any break in learning. A relaunch required a newly approved policy, confirmed budget and provider due diligence; a draft proposal alone carried no current authority."),
    ],
    "v4b.infogov.website-social-media-publishing-policy": [
        ("Publishing authority", "Only named communications staff or an explicitly authorised delegate could publish through an organisational account. Content required an identified owner, purpose and approval route. Staff did not create unofficial accounts using the organisation's name, publish resident information from personal devices, or treat a private group as exempt from confidentiality and records obligations."),
        ("Consent, accuracy and accessibility", "Images, case studies and quotations required recorded, purpose-specific consent and a check that the person understood the intended channel and likely audience. Published facts, links and contact details were checked before release, and accessibility requirements applied to text, images, video and downloadable documents. Consent withdrawal or a material error triggered prompt review and correction."),
        ("Withdrawal and replacement", "Withdrawal of this policy removed authority to publish under it; it did not delete prior records or permit an unapproved outsourced arrangement to begin. Existing channels were placed under controlled administration while a successor model was reviewed. Publication approvals, consent evidence, corrections, access changes and archived content were retained according to the Records Retention Schedule."),
    ],
    "v4b.infogov.email-retention-policy": [
        ("Classification and filing", "Email is a communication channel, not an indefinite records store. A message evidencing a care, employment, contractual, complaint, safeguarding or governance decision is transferred promptly to the approved record system and classified under the applicable retention schedule. Routine coordination, duplicates, alerts and transient working messages are deleted when no longer needed."),
        ("Retention and disposal", "Mailbox retention settings support, but do not replace, the duty to file a business record correctly. Automatic deletion is suspended for a legal hold, investigation, subject-access search or other authorised preservation requirement. When the hold ends, disposal resumes under the relevant schedule and is recorded where the record class requires evidence of destruction."),
        ("Access and assurance", "Managers arrange controlled mailbox access for absence, leavers or investigations through the documented authorisation route; passwords are never shared. Information Governance reviews retention configuration, preservation holds and exception reports at least annually. Staff report misdirected sensitive email immediately under the Data Breach Procedure rather than attempting to resolve it silently."),
    ],
    "v4b.it.software-licensing-policy": [
        ("Acquisition and inventory", "Software is obtained through the approved procurement route and recorded against its licence owner, permitted users or devices, renewal date and contractual restrictions. Free, trial and open-source products still require security, data-protection and licence review before organisational use. Staff must not accept online terms or install browser extensions on behalf of the organisation without authority."),
        ("Deployment and use", "IT deploys software through managed tooling and assigns only the entitlements purchased. Shared credentials, copied licence keys and installations beyond the licensed count are prohibited. A role change, device replacement or leaver event triggers entitlement review so access can be reassigned or removed without retaining an unauthorised duplicate installation."),
        ("Audit and renewal", "IT reconciles supplier records, deployment inventory and active accounts at least quarterly and investigates unmatched installations. Renewal owners review continuing need, price, security support and data handling before commitment. Evidence of purchase, licence terms, allocation, reconciliation and disposal is retained so compliance can be demonstrated without relying on an individual's memory."),
    ],
    "v4b.incident.serious-incident-review-policy": [
        ("Review initiation", "A serious incident review begins when harm, credible risk, repeated failure or an external notification threshold indicates that routine local follow-up is insufficient. The commissioning manager records the scope, review lead, independence considerations, people to involve and target dates. Immediate safety action proceeds without waiting for the review, while evidence is preserved proportionately."),
        ("Evidence and involvement", "The review considers records, chronology, policies, staffing, equipment, decisions and relevant testimony without treating the first account as conclusive. Residents, representatives and staff are offered an appropriate opportunity to contribute and are told how their information will be used. The process remains learning-focused while preserving separate disciplinary, safeguarding or legal routes where those are required."),
        ("Actions and closure", "Findings distinguish individual acts, system conditions and uncertainty. Each action has an owner, due date and measurable completion evidence; an action is not closed merely because a document was issued. The Quality Lead verifies completion and effectiveness, records any overdue escalation and communicates the outcome through the correct candour and governance arrangements."),
    ],
    "v4b.safeguarding.missing-person-procedure": [
        ("Immediate response", "Staff confirm the person is not elsewhere on site, note the last verified sighting, clothing, mobility, communication needs and likely destinations, and preserve relevant CCTV or access records. The registered manager assesses immediate vulnerability and calls emergency services without delay where risk is high; local searching never postpones a necessary police report."),
        ("Search and communication", "The search is coordinated, logged and allocated so unsafe duplication and unsearched areas are visible. Staff maintain safe staffing for residents who remain on site. Family, commissioners and safeguarding contacts are informed according to the person's plan and the circumstances, while public communication and photographs are released only through the police-led or otherwise authorised route."),
        ("Return and learning", "On return, immediate welfare and medical needs are assessed before a calm account is sought. The care plan, risk assessment and known triggers are reviewed with the person and relevant representatives. The incident record includes timings, decisions, notifications and search activity, and repeated episodes or control failures are escalated for safeguarding and service-level review."),
    ],
    "v4b.hr.key-performance-indicator-reporting-policy": [
        ("Indicator ownership", "Each approved indicator has a definition, source system, reporting frequency, accountable owner and named reviewer. The definition states inclusions, exclusions, numerator, denominator and treatment of missing data so sites cannot improve a result by changing interpretation. A proposed indicator or target has no reporting authority until the scheduled successor version becomes effective."),
        ("Validation and submission", "Owners reconcile source totals, investigate material variance and record corrections before submission. Estimates are visibly labelled and replaced when verified data becomes available. Local commentary explains unusual movement without suppressing an adverse result, and access to resident or workforce detail remains limited to people who need it."),
        ("Review and action", "The governance meeting considers trend, comparison, data quality and whether existing actions are effective. A threshold breach receives an owner and due date rather than being explained away in narrative. Reports, validation evidence, corrections and meeting decisions are retained together, allowing the published position to be reproduced from its source data."),
    ],
    "v4b.training.dignity-in-care-audit-procedure": [
        ("Audit preparation", "The auditor samples different times, locations and care interactions and checks prior actions before observation begins. Residents are told the purpose in an accessible way and may decline involvement. The audit tool covers privacy, choice, communication, personal presentation, mealtime support, confidential records and the physical environment rather than relying on a single general impression."),
        ("Evidence and escalation", "Findings cite the observed or recorded evidence and distinguish an isolated lapse from a repeated or systemic concern. Immediate risk, degrading treatment or possible abuse is escalated at once through safeguarding and management routes; it is not left as a routine audit action. Positive practice is recorded specifically enough to be repeated elsewhere."),
        ("Action and follow-up", "Each shortfall receives an accountable owner, due date and completion evidence. The registered manager reviews the action plan with residents or representatives where appropriate. Follow-up tests whether practice changed in reality, and overdue or ineffective actions are escalated to the Quality Lead. Audit tools, evidence, responses and closure decisions form one retained record."),
    ],
    "v4b.hs.dols-renewal-tracking-procedure": [
        ("Register controls", "The site register records the authorisation reference, restrictions, conditions, start and expiry dates, representative, review events and renewal status for each resident. The registered manager reconciles the register with current authorisation documents monthly. A missing document, inconsistent date or unrecorded condition is investigated immediately rather than assumed to be an administrative delay."),
        ("Renewal workflow", "Preparation starts far enough ahead to gather the current care plan, capacity assessment, restrictions and evidence of less restrictive alternatives. The application date, receiving authority and acknowledgement are recorded. Staff continue to follow the current lawful conditions while a renewal is considered and seek advice promptly where authority may expire before a decision."),
        ("Escalation and evidence", "An approaching expiry without acknowledgement, a changed restriction or a condition that cannot be met is escalated to the registered manager and governance lead. The resident and representative are kept informed through the appropriate route. Applications, decisions, correspondence, reviews and escalation records are retained together so the authority position at any date can be reconstructed."),
    ],
    "v4b.hs.key-safe-procedure": [
        ("Authorisation and coding", "A key safe is installed only after property-owner consent, resident or representative agreement where applicable, and a recorded risk assessment. The code is disclosed only to authorised workers who need access and is not written in general notes, visit lists or an unprotected message. Each safe has a unique register entry linked to the address without exposing the code itself."),
        ("Use and security", "Staff shield the keypad, return the key immediately, scramble the display and confirm the safe has locked before leaving. A missing key, damaged safe, observed code or unexplained access is reported immediately and the premises secured through the agreed contingency route. The code is changed after compromise and at other defined review points."),
        ("Review and removal", "The responsible manager reviews continuing need, authorised recipients and physical condition at least annually and after a tenancy, care-package or risk change. When the safe is no longer required it is removed or disabled promptly, keys are returned and access records are closed. Installation, code-change, incident, review and removal evidence is retained securely."),
    ],
    "v4b.facilities.pet-visiting-policy": [
        ("Agreement before a visit", "A proposed pet visit is agreed with the registered manager in advance, considering resident preference, allergies, phobias, infection risk, mobility, behaviour and the areas to be used. The owner confirms that the animal is healthy, appropriately vaccinated where relevant, controllable and covered by suitable insurance. An assistance animal is considered under its distinct legal and access context."),
        ("Managing the visit", "The owner remains responsible and keeps the animal under control. Staff identify a suitable route and area, protect food preparation and clinical spaces, and ensure residents can choose not to participate. Hand hygiene and prompt cleaning apply after contact or an accident. A distressed resident or animal, unsafe behaviour or loss of control ends the visit immediately."),
        ("Review and incidents", "Regular visiting arrangements are reviewed after any change in health, behaviour, resident population or environmental risk. Bites, scratches, falls, contamination and near misses are recorded and escalated through the relevant incident route. Agreements, risk assessments and restrictions are documented so visiting expectations remain consistent across shifts."),
    ],
    "v4b.medication.fridge-breakdown-procedure": [
        ("Immediate containment", "When the medicines-fridge temperature is outside range or the unit fails, staff keep the door closed, note the current and available minimum/maximum readings, label the unit not for use and inform the responsible nurse or manager. Stock is not moved into a domestic refrigerator or discarded on assumption. A validated alternative refrigerator or insulated container is prepared where authorised."),
        ("Clinical and pharmacy advice", "Staff list every affected medicine, batch where available, storage requirement and estimated exposure time and obtain product-specific pharmacy or manufacturer advice. The decision to use, quarantine or replace each item is recorded. Time-critical doses are escalated so an alternative supply or clinically appropriate plan can be arranged without bypassing prescribing controls."),
        ("Recovery and assurance", "The failed unit is inspected and must demonstrate a stable compliant temperature before return to service. Quarantined stock remains segregated until a documented decision is made. Temperature records, exposure assessment, advice, stock disposition, engineer report and any omitted-dose or incident record are retained together, and repeated failures trigger equipment replacement review."),
    ],
}

RELABELLED_FAMILIES = {
    "v4b.care.continence-care-policy": "tightened_requirement_with_broader_section_rewrite",
    "v4b.facilities.ladder-stepladder-use-guidance": "tightened_permission_with_consequential_rewrite",
    "v4b.hr.dbs-renewal-procedure": "mandatory_registration_with_consequential_rewrite",
    "v4b.hr.right-to-work-checks-procedure": "mandatory_precondition_with_consequential_rewrite",
    "v4b.training.induction-buddy-scheme-guidance": "mandatory_assignment_with_consequential_rewrite",
}


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def replace_realism_sections(path: Path, additions: list[tuple[str, str]]) -> None:
    text = path.read_text(encoding="utf-8")
    start = "<!-- freeze-correction-realism-start -->"
    end = "<!-- freeze-correction-realism-end -->"
    if start in text:
        prefix, remainder = text.split(start, 1)
        _, suffix = remainder.split(end, 1)
        text = prefix.rstrip() + "\n\n" + suffix.lstrip()
    body = [start]
    for heading, paragraph in additions:
        body.extend([f"## {heading}", "", paragraph, ""])
    body.append(end)
    insertion = "\n".join(body) + "\n\n"
    separator = "\n---\n"
    if separator not in text:
        raise ValueError(f"missing footer separator in {path}")
    text = text.replace(separator, "\n\n" + insertion + "---\n", 1)
    path.write_text(text, encoding="utf-8")


def normalize_formatting_only_pair() -> None:
    family = ROOT / "semantic-masters/v4b.hr.staff-handover-procedure"
    v1 = (family / "v1.md").read_text(encoding="utf-8")
    v2 = re.sub(
        r"^<!-- v4-authoring-draft family=v4b\.hr\.staff-handover-procedure version=v1 -->",
        "<!-- v4-authoring-draft family=v4b.hr.staff-handover-procedure version=v2 -->",
        v1,
        count=1,
    )
    (family / "v2.md").write_text(v2, encoding="utf-8")


def strip_master_metadata(text: str) -> str:
    text = re.sub(r"^<!--.*?-->\s*", "", text, count=1, flags=re.DOTALL)
    text = re.sub(r"\n---\n[^\n]+\s*$", "", text)
    return text.strip()


def master_to_doc(entry: dict, master_path: Path, brand: str) -> dict:
    lines = master_path.read_text(encoding="utf-8").splitlines()
    if lines and lines[0].startswith("<!--"):
        lines.pop(0)
    if not lines or not lines[0].startswith("# "):
        raise ValueError(f"missing master title: {master_path}")
    title = lines.pop(0)[2:].strip()
    while lines and not lines[0].strip():
        lines.pop(0)
    front_matter = None
    if lines and lines[0].startswith("*") and lines[0].endswith("*"):
        front_matter = lines.pop(0).strip("*")
    if "---" in lines:
        lines = lines[: lines.index("---")]

    sections: list[tuple] = []
    heading = ""
    block: list[str] = []

    def flush() -> None:
        nonlocal block, heading
        if not block and not heading:
            return
        while block and not block[0].strip():
            block.pop(0)
        while block and not block[-1].strip():
            block.pop()

        i = 0
        paragraph: list[str] = []
        heading_pending = heading  # combined into the FIRST paragraph/None below,
        # matching the original doc-dict convention of one (heading, body) tuple
        # per section rather than splitting heading and body into two entries
        # (a prior version of this reparse did split them, which changed PDF
        # flowable byte layout on a reparse-then-rerender round trip without
        # changing extracted text; fixed to preserve true render byte-fidelity).

        def flush_paragraph() -> None:
            nonlocal paragraph, heading_pending
            if paragraph:
                body = " ".join(x.strip() for x in paragraph)
                sections.append((heading_pending, body))
                heading_pending = ""
                paragraph = []

        while i < len(block):
            line = block[i]
            if not line.strip():
                flush_paragraph()
                i += 1
                continue
            if line.startswith("| "):
                flush_paragraph()
                if heading_pending:
                    sections.append((heading_pending, None))
                    heading_pending = ""
                rows: list[list[str]] = []
                while i < len(block) and block[i].startswith("|"):
                    cells = [c.strip() for c in block[i].strip().strip("|").split("|")]
                    if not all(re.fullmatch(r"-+", c) for c in cells):
                        rows.append(cells)
                    i += 1
                if rows:
                    sections.append(("__table__", rows))
                continue
            if line.startswith("- "):
                flush_paragraph()
                if heading_pending:
                    sections.append((heading_pending, None))
                    heading_pending = ""
                items = []
                while i < len(block) and block[i].startswith("- "):
                    items.append(block[i][2:].strip())
                    i += 1
                sections.append(("__list__", items))
                continue
            if re.match(r"^\d+\. ", line):
                flush_paragraph()
                if heading_pending:
                    sections.append((heading_pending, None))
                    heading_pending = ""
                items = []
                while i < len(block) and re.match(r"^\d+\. ", block[i]):
                    items.append(re.sub(r"^\d+\. ", "", block[i]).strip())
                    i += 1
                sections.append(("__numbered__", items))
                continue
            paragraph.append(line)
            i += 1
        flush_paragraph()
        if heading_pending:
            # a heading with no following content at all (rare)
            sections.append((heading_pending, ""))
        block = []
        heading = ""

    for line in lines:
        if line.startswith("## "):
            flush()
            heading = line[3:].strip()
        else:
            block.append(line)
    flush()

    doc = dict(entry)
    doc.update(
        human_title=title,
        front_matter=front_matter,
        sections=sections,
        brand_identity=brand,
        footer_boilerplate=True,
    )
    if entry["family_id"] == "v4b.hr.staff-handover-procedure" and entry["version_id"] == "v2":
        doc["presentation_variant"] = "formatting-only-v2"
    return doc


def render_pack(manifest_path: Path, brand: str, pack_root: Path | None = None) -> None:
    manifest = read_json(manifest_path)
    pack_root = pack_root or ROOT
    for entry in manifest["documents"]:
        master_rel = entry.get("semantic_master_path")
        if master_rel:
            master_path = ROOT / master_rel
        else:
            master_path = pack_root / "semantic-masters" / entry["family_id"] / f"{entry['version_id']}.md"
        doc = master_to_doc(entry, master_path, brand)
        fmt = entry["format"]
        md = master_path.read_text(encoding="utf-8")
        if fmt == "pdf":
            data = render.render_pdf(doc)
        elif fmt == "docx":
            data = render.render_docx(doc)
        elif fmt == "txt":
            data = render.render_txt(doc, md)
        else:
            raise ValueError(f"unexpected governed format: {fmt}")
        artefact = ROOT / entry["artefact_path"]
        artefact.write_bytes(data)
        entry["sha256"] = hashlib.sha256(data).hexdigest()
        entry["byte_count"] = len(data)
        entry["renderer_tool"] = render.RENDERER_VERSION[fmt]
        entry["word_count_approx"] = len(render.markdown_to_plaintext(md).split())
    write_json(manifest_path, manifest)


def correct_metadata() -> None:
    manifest_path = ROOT / "source-manifest.json"
    manifest = read_json(manifest_path)
    stale_domain = "health" + "_safety"
    for entry in manifest["documents"]:
        if entry["domain"] == stale_domain:
            entry["domain"] = "health-safety"
        if entry["family_id"] in RELABELLED_FAMILIES:
            entry["version_change_type"] = RELABELLED_FAMILIES[entry["family_id"]]
        if entry["family_id"] == "v4b.hr.staff-handover-procedure":
            entry["version_change_type"] = "formatting_only_honest_gap"
            entry["presentation_variant"] = (
                "formatting-only-v2" if entry["version_id"] == "v2" else "formatting-only-v1"
            )
    write_json(manifest_path, manifest)

    plan_path = ROOT / "document-family-plan.json"
    plan = read_json(plan_path)
    for family in plan["families"]:
        if family.get("domain") == stale_domain:
            family["domain"] = "health-safety"
        if family["family_id"] in RELABELLED_FAMILIES:
            family["version_change_types"] = [RELABELLED_FAMILIES[family["family_id"]]]
    write_json(plan_path, plan)


def generate_version_diff_report() -> None:
    """Delegate to the real per-comparison fidelity validator
    (generate/validate_version_fidelity.py, driven by the canonical
    version-change-type-registry.json and version-diff-contracts.json),
    replacing the previous "non-identical means pass" logic. This function
    now only re-exports that validator's result in the schema
    validate_freeze.py expects; it does not implement its own, separate
    (and weaker) pass/fail rule.
    """
    import validate_version_fidelity as vvf

    manifest = read_json(ROOT / "source-manifest.json")
    grouped: dict[str, list[dict]] = defaultdict(list)
    for entry in manifest["documents"]:
        grouped[entry["family_id"]].append(entry)
    comparison_count = sum(len(v) - 1 for v in grouped.values() if len(v) >= 2)

    checked, problems = vvf.run()
    report = {
        "schema_version": "v4-freeze-version-diff-2",
        "validator": "generate/validate_version_fidelity.py",
        "registry": "authoring-governance/version-change-type-registry.json",
        "contracts": "authoring-governance/version-diff-contracts.json",
        "comparison_count": checked,
        "failure_count": len(problems),
        "failures": problems,
    }
    write_json(ROOT / "version-diff-report.json", report)
    if problems:
        raise ValueError(f"version diff fidelity validation failed: {problems}")


def main() -> None:
    for family_id, additions in REALISM_ADDITIONS.items():
        family_dir = ROOT / "semantic-masters" / family_id
        for master in sorted(family_dir.glob("*.md")):
            replace_realism_sections(master, additions)
    normalize_formatting_only_pair()
    correct_metadata()
    render_pack(ROOT / "source-manifest.json", "Alderbridge Care Group")
    render_pack(
        ROOT / "foreign-tenant/source-manifest.json",
        "Thornfield Support Services",
        ROOT / "foreign-tenant",
    )
    render_pack(
        ROOT / "prompt-injection-pack/source-manifest.json",
        "Dolved Synthetic Security Fixture",
        ROOT / "prompt-injection-pack",
    )
    generate_version_diff_report()
    print("Freeze corrections applied and governed artefacts rebuilt.")


if __name__ == "__main__":
    main()
