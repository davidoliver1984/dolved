"""Create a deterministic, hygienic V4 checkpoint archive."""
from __future__ import annotations

import argparse
import gzip
import io
import os
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE_ROOT = "eval-corpus-v4-authoring"


def validate_hygiene() -> list[Path]:
    files = []
    for path in ROOT.rglob("*"):
        rel = path.relative_to(ROOT)
        if path.is_symlink():
            raise ValueError(f"links are forbidden in freeze archives: {rel}")
        if path.name == ".DS_Store" or path.name.startswith("._") or path.suffix == ".pyc":
            raise ValueError(f"transient file is forbidden: {rel}")
        if "__pycache__" in path.parts:
            raise ValueError(f"cache directory is forbidden: {rel}")
        if path.is_file():
            files.append(path)
    return sorted(files, key=lambda p: p.relative_to(ROOT).as_posix())


def add_file(tar: tarfile.TarFile, path: Path) -> None:
    rel = path.relative_to(ROOT).as_posix()
    info = tarfile.TarInfo(f"{ARCHIVE_ROOT}/{rel}")
    data = path.read_bytes()
    info.size = len(data)
    info.mtime = 0
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    info.mode = 0o644
    tar.addfile(info, io.BytesIO(data))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    if ROOT in output.parents:
        raise ValueError("checkpoint output must be outside the corpus tree")
    files = validate_hygiene()
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0, compresslevel=9) as gz:
            with tarfile.open(fileobj=gz, mode="w", format=tarfile.USTAR_FORMAT) as tar:
                for path in files:
                    add_file(tar, path)
    print(f"Created deterministic checkpoint with {len(files)} files: {output}")


if __name__ == "__main__":
    main()
