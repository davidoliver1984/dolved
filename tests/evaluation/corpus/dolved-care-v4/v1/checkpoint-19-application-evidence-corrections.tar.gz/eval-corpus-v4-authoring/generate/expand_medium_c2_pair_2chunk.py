"""Medium tier batch C2: 4 more two-version family pairs targeting 2
real chunks per version, preserving each pair's existing diff exactly:
- staff-benefits-guidance: discount range 5-10% -> 5-15%, new provider
- induction-buddy-scheme-guidance: 'should' -> 'must' (mandatory)
- safeguarding-champion-role-guidance: 'safeguarding lead' -> 'safeguarding champion' (renamed throughout)
- data-encryption-standard: 'Laptop encryption' -> 'Device encryption' (now explicitly covers tablets)
"""

DOCS = [
{
    "family_id": "v4b.hr.staff-benefits-guidance", "version_id": "v1",
    "front_matter": None,
    "sections": [
        ("Purpose and scope", "This guidance explains the retail discount scheme available to Alderbridge staff. It applies to every member of staff across every site."),
        ("Policy statement", "Staff can access a retail discount scheme offering typically 5-10% off at participating retailers, a straightforward benefit available to every staff member from their start date."),
        ("Definitions", "**Participating retailer** a retailer that has agreed to offer the scheme's discount to an Alderbridge staff member. **Scheme provider** the third-party company that administers the discount scheme and its list of participating retailers."),
        ("__numbered__", [
            "Register for the discount scheme through the staff portal using a personal email address.",
            "Browse the current list of participating retailers and their specific discount rate, typically 5-10%, through the scheme provider's own platform.",
            "Present the scheme's digital or physical card, as the retailer requires, at the point of purchase to receive the discount.",
            "Report any issue redeeming a discount to HR, who liaises with the scheme provider on the staff member's behalf.",
        ]),
        ("Interaction with other Alderbridge policies", "This guidance works alongside the Long Service Recognition Scheme and the pension scheme guidance as part of the wider set of staff benefits Alderbridge offers."),
        ("Worked example", "A worked example illustrates typical use. A staff member registers for the scheme in their first week, browses the participating retailer list, and uses the discount card for a purchase at a participating supermarket, receiving the retailer's specific discount rate within the 5-10% range the scheme offers."),
        ("Frequently asked questions", "**Does the discount scheme cost anything for a staff member to join?** No, it is a free benefit provided by Alderbridge. **Does an agency worker have access to the discount scheme?** No, it is available to a direct Alderbridge employee only."),
        ("Promoting the scheme", "HR promotes the discount scheme periodically through the staff newsletter and at induction, since a genuinely useful benefit provides little value if staff are not aware it exists or have forgotten how to access it since their initial registration."),
        ("Feedback on the scheme", "Staff feedback on the discount scheme, including a suggestion for a retailer not currently participating, is welcomed by HR and passed to the scheme provider to consider, since the scheme is more valuable to staff when it reflects the retailers they actually want to use."),
        ("Closing note", "A simple, genuinely useful discount scheme is a small but real way Alderbridge supports staff day to day, and this guidance exists to make it easy to find and use."),
    ],
},
{
    "family_id": "v4b.hr.staff-benefits-guidance", "version_id": "v2",
    "front_matter": "Supersedes the version effective 1 April 2025. New scheme provider, wider discount range.",
    "sections": [
        ("Purpose and scope", "This guidance explains the retail discount scheme available to Alderbridge staff. It applies to every member of staff across every site."),
        ("Policy statement", "Staff can access a retail discount scheme offering typically 5-15% off at a wider range of participating retailers, following a change of scheme provider, a straightforward benefit available to every staff member from their start date."),
        ("Definitions", "**Participating retailer** a retailer that has agreed to offer the scheme's discount to an Alderbridge staff member, now a wider range following the provider change. **Scheme provider** the third-party company that administers the discount scheme and its list of participating retailers, changed in this version."),
        ("__numbered__", [
            "Register for the discount scheme through the staff portal using a personal email address; an existing registration under the previous provider is migrated automatically.",
            "Browse the current, wider list of participating retailers and their specific discount rate, now typically 5-15%, through the new scheme provider's platform.",
            "Present the scheme's digital or physical card, as the retailer requires, at the point of purchase to receive the discount.",
            "Report any issue redeeming a discount to HR, who liaises with the new scheme provider on the staff member's behalf.",
        ]),
        ("Interaction with other Alderbridge policies", "This guidance works alongside the Long Service Recognition Scheme and the pension scheme guidance as part of the wider set of staff benefits Alderbridge offers."),
        ("Worked example", "A worked example illustrates the wider range now available. A staff member who previously found few participating retailers relevant to them checks the new, wider list following the provider change, and finds a retailer they regularly use now participates at a 12% discount, within the new 5-15% range this version introduces."),
        ("Frequently asked questions", "**Why did the scheme provider change?** A review found the new provider offers a meaningfully wider retailer range and higher typical discount; existing staff registrations were migrated automatically. **Does a staff member need to re-register after the provider change?** No, migration was automatic, though staff are encouraged to log in and confirm their details are current."),
        ("Promoting the scheme", "HR promotes the discount scheme periodically through the staff newsletter and at induction, now highlighting the wider retailer range this version introduces, since a genuinely useful benefit provides little value if staff are not aware of what has actually changed since they last checked it."),
        ("Closing note", "A simple, genuinely useful discount scheme is a small but real way Alderbridge supports staff day to day, and the wider range in this version exists to make that benefit even more useful."),
    ],
},
{
    "family_id": "v4b.training.induction-buddy-scheme-guidance", "version_id": "v1",
    "front_matter": None,
    "sections": [
        ("Purpose and scope", "This guidance explains the induction buddy scheme offered to a new starter at Alderbridge Care Group. It applies to every new starter across every site."),
        ("Policy statement", "New starters should be assigned an experienced buddy for their first 4 weeks, giving them an approachable, informal point of contact alongside their formal induction programme."),
        ("Definitions", "**Buddy** an experienced staff member paired with a new starter to offer informal support and answer day-to-day questions. **Buddy period** the first 4 weeks of a new starter's employment, during which the buddy pairing is in place."),
        ("__numbered__", [
            "Identify a suitable experienced staff member as a buddy before the new starter's first day, where practicable.",
            "Introduce the buddy to the new starter on their first day, explaining the buddy's role as an informal, approachable point of contact.",
            "Check in with both the buddy and the new starter partway through the 4-week period to see how the pairing is working.",
            "Extend the buddy period beyond 4 weeks where both the buddy and new starter feel this would be helpful.",
        ]),
        ("Exceptions and professional judgement", "Where no suitable experienced staff member is available at a small site, the registered manager may arrange a buddy from a neighbouring site for informal telephone or message support, rather than the new starter having no buddy at all."),
        ("Interaction with other Alderbridge policies", "This guidance works alongside the New Starter Induction Programme Outline (the formal induction this scheme complements) and the Staff Supervision and Appraisal Policy (the more formal line management relationship this scheme sits alongside)."),
        ("Worked example", "A worked example illustrates the buddy relationship in practice. A new care assistant is paired with an experienced colleague on their first day. Over the following weeks, the new starter asks the buddy informal, practical questions they might otherwise have felt hesitant to raise with their line manager, and the mid-point check-in confirms the pairing is working well for both."),
        ("Frequently asked questions", "**Is being a buddy a paid additional responsibility?** No, it is recognised informally as part of being a supportive, experienced colleague rather than a separate paid role. **What happens if a buddy pairing genuinely is not working well?** The registered manager arranges a different buddy rather than persisting with a pairing that is not helping the new starter settle in."),
        ("Closing note", "A good buddy relationship can make a real difference to how quickly and confidently a new starter settles in, and this guidance exists to make that relationship a genuine, supported part of every new starter's early weeks."),
    ],
},
{
    "family_id": "v4b.training.induction-buddy-scheme-guidance", "version_id": "v2",
    "front_matter": "Supersedes the version effective 1 September 2025. 'Should' becomes 'must' — the buddy assignment is no longer discretionary.",
    "sections": [
        ("Purpose and scope", "This guidance explains the induction buddy scheme offered to a new starter at Alderbridge Care Group. It applies to every new starter across every site."),
        ("Policy statement", "New starters must be assigned an experienced buddy for their first 4 weeks — no longer discretionary — giving every new starter an approachable, informal point of contact alongside their formal induction programme."),
        ("Definitions", "**Buddy** an experienced staff member paired with a new starter to offer informal support and answer day-to-day questions. **Buddy period** the first 4 weeks of a new starter's employment, during which the buddy pairing is now mandatory."),
        ("__numbered__", [
            "Identify a suitable experienced staff member as a buddy before the new starter's first day; this assignment is now mandatory rather than discretionary as under the previous version.",
            "Introduce the buddy to the new starter on their first day, explaining the buddy's role as an informal, approachable point of contact.",
            "Check in with both the buddy and the new starter partway through the 4-week period to see how the pairing is working.",
            "Extend the buddy period beyond 4 weeks where both the buddy and new starter feel this would be helpful.",
        ]),
        ("Exceptions and professional judgement", "Where no suitable experienced staff member is available at a small site, the registered manager arranges a buddy from a neighbouring site for informal telephone or message support; since assignment is now mandatory, the absence of an obvious on-site buddy is no longer treated as grounds to skip the scheme entirely."),
        ("Interaction with other Alderbridge policies", "This guidance works alongside the New Starter Induction Programme Outline (the formal induction this scheme complements) and the Staff Supervision and Appraisal Policy (the more formal line management relationship this scheme sits alongside)."),
        ("Worked example", "A worked example illustrates the mandatory standard. A site with an unusually high number of new starters in the same month previously might have let a buddy pairing slip for the last arrival given the administrative load; under this version, every new starter receives a buddy without exception, with the registered manager arranging cross-site support if needed rather than treating it as optional when capacity is stretched."),
        ("Frequently asked questions", "**Why was buddy assignment made mandatory?** A review found an occasional new starter missed out on a buddy during a busy period under the discretionary wording; making it mandatory closes that gap. **Is being a buddy a paid additional responsibility?** No, it is recognised informally as part of being a supportive, experienced colleague rather than a separate paid role."),
        ("Closing note", "A good buddy relationship can make a real difference to how quickly and confidently a new starter settles in, and making the assignment mandatory in this version exists to make sure every new starter benefits from one, not just most."),
    ],
},
{
    "family_id": "v4b.training.safeguarding-champion-role-guidance", "version_id": "v1",
    "front_matter": None,
    "sections": [
        ("Purpose and scope", "This guidance explains the safeguarding lead role at each Alderbridge site. It applies to every registered manager deciding who to nominate."),
        ("Policy statement", "Each site nominates a safeguarding lead who acts as the first point of contact for safeguarding questions, providing local expertise and support to colleagues raising a concern."),
        ("Definitions", "**Safeguarding lead** the Level 3 trained staff member nominated at each site as the local point of safeguarding expertise. **First point of contact** the role of being the person a colleague approaches first with a safeguarding question or concern, before wider escalation."),
        ("__numbered__", [
            "Nominate a staff member holding, or willing to complete, Level 3 safeguarding training as the site's safeguarding lead.",
            "Make the safeguarding lead's identity clearly known to every staff member, including on the site's safeguarding noticeboard.",
            "Support the safeguarding lead to attend the wider Alderbridge safeguarding network meeting, sharing learning across sites.",
            "Arrange cover for the safeguarding lead role during their absence, so the first point of contact function is never left unfilled.",
        ]),
        ("Interaction with other Alderbridge policies", "This guidance works alongside the Adult Safeguarding Policy (the wider framework the safeguarding lead supports) and the Safeguarding Training Levels Guidance (governing the Level 3 training this role requires)."),
        ("Worked example", "A worked example illustrates the first point of contact function. A care assistant notices something that concerns them but is unsure whether it meets the safeguarding referral threshold. They raise it informally with the site's safeguarding lead first, who provides an experienced view and, where appropriate, supports them through the formal referral process."),
        ("Frequently asked questions", "**Can a site have more than one safeguarding lead?** Yes, a larger site may nominate more than one to ensure cover, though one is always clearly the primary point of contact. **Does the safeguarding lead role replace the registered manager's own safeguarding responsibility?** No, the registered manager retains overall responsibility; the safeguarding lead provides local, everyday expertise and a first point of contact."),
        ("Reviewing the nomination periodically", "The registered manager reviews the safeguarding lead nomination annually, or sooner if the current post-holder moves role or leaves, confirming the site always has a clearly identified, currently-trained person filling this function rather than an outdated name remaining on the noticeboard."),
        ("Closing note", "Having a known, approachable local expert makes a colleague more likely to raise an early concern, and this guidance exists to make that role a genuine, visible presence at every site."),
    ],
},
{
    "family_id": "v4b.training.safeguarding-champion-role-guidance", "version_id": "v2",
    "front_matter": "Supersedes the version effective 1 June 2025. 'Safeguarding lead' renamed to 'Safeguarding champion' throughout — the role and its responsibilities are unchanged.",
    "sections": [
        ("Purpose and scope", "This guidance explains the safeguarding champion role at each Alderbridge site. It applies to every registered manager deciding who to nominate."),
        ("Policy statement", "Each site nominates a safeguarding champion who acts as the first point of contact for safeguarding questions, providing local expertise and support to colleagues raising a concern."),
        ("Definitions", "**Safeguarding champion** the Level 3 trained staff member nominated at each site as the local point of safeguarding expertise, renamed in this version from the previous term 'safeguarding lead' — the role itself is unchanged. **First point of contact** the role of being the person a colleague approaches first with a safeguarding question or concern, before wider escalation."),
        ("__numbered__", [
            "Nominate a staff member holding, or willing to complete, Level 3 safeguarding training as the site's safeguarding champion.",
            "Make the safeguarding champion's identity clearly known to every staff member, including on the site's safeguarding noticeboard, updated to reflect the new title.",
            "Support the safeguarding champion to attend the wider Alderbridge safeguarding network meeting, sharing learning across sites.",
            "Arrange cover for the safeguarding champion role during their absence, so the first point of contact function is never left unfilled.",
        ]),
        ("Interaction with other Alderbridge policies", "This guidance works alongside the Adult Safeguarding Policy (the wider framework the safeguarding champion supports) and the Safeguarding Training Levels Guidance (governing the Level 3 training this role requires)."),
        ("Worked example", "A worked example illustrates that only the title has changed. A care assistant notices something that concerns them but is unsure whether it meets the safeguarding referral threshold. They raise it informally with the site's safeguarding champion, who provides the same experienced first-point-of-contact support the role always has, under its new name."),
        ("Frequently asked questions", "**Why was the role renamed?** A review found 'champion' better reflects the role's supportive, promotional nature within the site, whereas 'lead' was sometimes mistaken for a formal management title; the responsibilities themselves have not changed. **Does a site need to re-nominate its safeguarding champion following the rename?** No, an existing safeguarding lead simply continues under the new title without needing to be re-nominated or retrained."),
        ("Reviewing the nomination periodically", "The registered manager reviews the safeguarding champion nomination annually, or sooner if the current post-holder moves role or leaves, confirming the site always has a clearly identified, currently-trained person filling this function under its current title rather than an outdated name remaining on the noticeboard."),
        ("Closing note", "Having a known, approachable local expert makes a colleague more likely to raise an early concern, and this guidance exists to make that role a genuine, visible presence at every site, under whichever name it is known by."),
    ],
},
{
    "family_id": "v4b.it.data-encryption-standard", "version_id": "v1",
    "front_matter": None,
    "sections": [
        ("Purpose and scope", "This standard sets out how Alderbridge encrypts data held on a laptop. It applies to every Alderbridge-issued laptop."),
        ("Policy statement", "All Alderbridge laptops use full-disk encryption enabled by IT before issue, protecting resident and staff data if a laptop is lost or stolen."),
        ("Definitions", "**Full-disk encryption** encryption applied to an entire device's storage, so data cannot be read without the correct credentials, even if the physical storage is removed. **Enabled before issue** the requirement that encryption is confirmed active before a laptop reaches its user, never enabled retrospectively after use has begun."),
        ("__numbered__", [
            "Enable full-disk encryption on every laptop before it is issued to a staff member.",
            "Verify encryption status as part of IT's pre-issue checklist, never issuing a laptop where this check has not passed.",
            "Report a laptop suspected to have been issued without encryption enabled to IT immediately for urgent remediation.",
            "Include encryption verification in the annual device audit across all sites.",
        ]),
        ("Interaction with other Alderbridge policies", "This standard works alongside the Mobile Device Management Policy (governing the wider device management framework encryption sits within) and the Cyber Incident Response Plan (relevant where a lost device's encryption status affects the incident response)."),
        ("Worked example", "A worked example illustrates the value of pre-issue verification. A laptop is later reported lost by a staff member. Because IT's pre-issue checklist confirmed full-disk encryption was active before it was issued, the data on it remains protected, and this is confirmed and recorded as part of the lost-device response rather than being an open question at that stressful moment."),
        ("Frequently asked questions", "**Can a staff member disable encryption on their own laptop for any reason?** No, this is technically restricted and never permitted regardless of the reason given. **What happens to an older laptop still in use that was issued before this standard was introduced?** IT verifies and enables encryption retrospectively as part of a rolling remediation programme."),
        ("Training and competency", "IT staff completing the pre-issue checklist are trained on verifying encryption status correctly as part of their onboarding."),
        ("Closing note", "Full-disk encryption is one of the simplest, most effective protections against data loss from a lost or stolen device, and this standard exists to make sure it is never missed at the point a laptop is issued."),
    ],
},
{
    "family_id": "v4b.it.data-encryption-standard", "version_id": "v2",
    "front_matter": "Supersedes the version effective 1 January 2025. 'Laptop encryption' renamed to 'Device encryption' to reflect coverage of tablets as well as laptops — no requirement changed for laptops specifically.",
    "sections": [
        ("Purpose and scope", "This standard sets out how Alderbridge encrypts data held on a laptop or tablet. It applies to every Alderbridge-issued laptop and, newly reflected in this version's title, every issued tablet."),
        ("Policy statement", "All Alderbridge laptops, and as before any issued tablet, use full-disk encryption enabled by IT before issue, protecting resident and staff data if a device is lost or stolen."),
        ("Definitions", "**Full-disk encryption** encryption applied to an entire device's storage, so data cannot be read without the correct credentials, even if the physical storage is removed. **Device** covers both a laptop and an issued tablet under this version's renamed title; the underlying laptop requirement is unchanged from the previous version. **Enabled before issue** the requirement that encryption is confirmed active before a device reaches its user, never enabled retrospectively after use has begun."),
        ("__numbered__", [
            "Enable full-disk encryption on every laptop and issued tablet before it is issued to a staff member.",
            "Verify encryption status as part of IT's pre-issue checklist, never issuing a device where this check has not passed.",
            "Report a device suspected to have been issued without encryption enabled to IT immediately for urgent remediation.",
            "Include encryption verification for both laptops and tablets in the annual device audit across all sites.",
        ]),
        ("Interaction with other Alderbridge policies", "This standard works alongside the Mobile Device Management Policy (governing the wider device management framework encryption sits within) and the Cyber Incident Response Plan (relevant where a lost device's encryption status affects the incident response)."),
        ("Worked example", "A worked example illustrates the tablet coverage this version makes explicit. A community-visiting staff member's issued tablet, used to access resident records during a home visit, is later reported lost. Because it was covered by the same pre-issue encryption checklist as a laptop, its data remains protected, confirming this version's renamed title reflects a coverage that already applied in practice."),
        ("Frequently asked questions", "**Did the actual encryption requirement for a laptop change in this version?** No, only the title and defined term changed to explicitly name tablets; a laptop's own requirement is identical to the previous version. **Why was 'tablet' not named explicitly in the original version?** The original title focused on laptops as they were the more common device at the time; this version's rename reflects tablets becoming a more significant part of the device fleet."),
        ("Training and competency", "IT staff completing the pre-issue checklist are trained on verifying encryption status correctly for both a laptop and a tablet as part of their onboarding."),
        ("Closing note", "Full-disk encryption is one of the simplest, most effective protections against data loss from a lost or stolen device, and the renamed title in this version exists to make sure that protection is understood to cover the full device fleet, not laptops alone."),
    ],
},
]
