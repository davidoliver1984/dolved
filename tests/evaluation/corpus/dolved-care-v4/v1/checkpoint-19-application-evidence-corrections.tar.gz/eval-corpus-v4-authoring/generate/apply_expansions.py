"""Apply expansion sections to existing documents in place: re-render the
same family_id/version_id/filename/format, update the manifest entry's
byte/word counts and checksum. Does not change governance metadata,
identities, or tranche.
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import render  # noqa: E402
from render import markdown_to_plaintext, build_markdown

ROOT = render.ROOT


def apply_expansions(expansion_modules, manifest_path="source-manifest.json"):
    manifest_file = ROOT / manifest_path
    manifest = json.loads(manifest_file.read_text())
    by_key = {(d["family_id"], d["version_id"]): d for d in manifest["documents"]}

    updated = 0
    for mod in expansion_modules:
        for expansion in mod.DOCS:
            key = (expansion["family_id"], expansion["version_id"])
            entry = by_key.get(key)
            if entry is None:
                print(f"WARNING: no existing manifest entry for {key}, skipping")
                continue

            # Reconstruct a full doc dict for rendering: reuse existing metadata,
            # replace only the 'sections' content.
            doc = {
                "family_id": entry["family_id"],
                "family_title": entry["family_title"],
                "version_id": entry["version_id"],
                "human_title": entry["human_title"],
                "filename": entry["filename"],
                "format": entry["format"],
                "domain": entry["domain"],
                "content_type": entry["content_type"],
                "governance_status": entry["governance_status"],
                "applicability_scope": entry["applicability_scope"],
                "applicability_locations": entry.get("applicability_locations", []),
                "effective_date": entry.get("effective_date"),
                "superseded_date": entry.get("superseded_date"),
                "messiness_level": entry["messiness_level"],
                "messiness_axes": entry["messiness_axes"],
                "prompt_injection": entry.get("prompt_injection", False),
                "sections": expansion["sections"],
                "front_matter": expansion.get("front_matter"),
            }

            new_entry = render.build_one(doc, tranche=entry["tranche"])
            new_entry["version_change_type"] = entry.get("version_change_type")
            new_entry["content_depth_corrected"] = True
            by_key[key] = new_entry
            updated += 1
            print(f"expanded {key[0]}::{key[1]} -> {new_entry['word_count_approx']} words, "
                  f"{new_entry['byte_count']} bytes")

    manifest["documents"] = list(by_key.values())
    manifest_file.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"\nUpdated {updated} manifest entries.")


if __name__ == "__main__":
    import expand_very_long_4
    import expand_very_long_5
    import expand_very_long_6

    apply_expansions([expand_very_long_4, expand_very_long_5, expand_very_long_6])
