"""Medium tier, second calibration batch: three naturally smaller
single-version guidance/FAQ/compact-procedure documents, targeting
exactly 2 real chunks (comfortably inside the 501-900 token band, away
from both the 500-token ceiling and the 900-token transition to 3)."""

DOCS = [
{
    "family_id": "v4.safeguarding.body-mapping-guidance", "version_id": "v1",
    "front_matter": None,
    "sections": [
        ("Purpose and scope", "This guidance explains how staff complete a body map when they notice or are told about a mark, bruise or skin change on a resident. It applies to every care staff member."),
        ("Policy statement", "A body map provides a clear, dated, consistent record of a mark's location, size and appearance, supporting both good skin care and, where relevant, a safeguarding referral, since a vague written description alone can be hard to compare accurately over time."),
        ("Definitions", "**Body map** the standard diagram used to mark the exact location of a mark or injury on a resident's body. **Unexplained mark** a bruise, cut or skin change without an obvious, witnessed cause. **Baseline body map** the body map completed at admission, recording a resident's existing marks before any new one can be compared against it."),
        ("Roles and responsibilities", "**Any care staff member** noticing a mark completes a body map the same shift, or reports it immediately to a colleague able to do so. **The registered manager** reviews an unexplained mark's body map to decide whether a safeguarding referral is needed. **New staff** are shown how to complete a body map correctly during induction."),
        ("__numbered__", [
            "Complete a body map for any new mark, bruise or skin change, marking its exact location, approximate size, and a brief description of its appearance.",
            "Complete a baseline body map for every resident at admission, recording any existing mark before it could be mistaken for a new one later.",
            "Take a photograph only where the resident consents and where photography is the site's approved method for the record, filed with the body map rather than kept separately.",
            "Report an unexplained mark to the registered manager the same day, regardless of how minor it appears.",
        ]),
        ("Exceptions and professional judgement", "Where a resident cannot consent to a mark being examined or photographed, staff use their best judgement in the resident's interest, recording the reason clearly rather than skipping the body map because consent could not be directly confirmed."),
        ("Interaction with other Alderbridge policies", "This guidance works alongside the Adult Safeguarding Policy (governing the referral an unexplained mark may trigger) and the Allegations Against Staff Procedure (relevant where a mark's cause is suspected to involve a staff member)."),
        ("Worked example", "A worked example illustrates baseline recording. A new resident is found to have an existing bruise on their forearm during admission. This is recorded on their baseline body map immediately, so that if a similar bruise is later noticed elsewhere, staff can clearly see it is a new, separate mark rather than mistakenly treating the original bruise as unexplained."),
        ("Frequently asked questions", "**Does every mark need a safeguarding referral?** No, only one that is genuinely unexplained or gives cause for concern; a clearly explained, witnessed minor bump does not automatically require one, though it is still recorded. **Who can complete a body map?** Any care staff member trained at induction, not only a nurse or senior carer."),
        ("Training and competency", "Body mapping is covered during safeguarding induction, with a practical demonstration of completing the diagram accurately."),
        ("Record keeping and retention", "Completed body maps are retained in the resident's care record per the Records Retention Schedule."),
        ("Closing note", "A clear, consistent body map protects a resident by making a genuine pattern visible over time, and this guidance exists to make that record easy to complete correctly under normal working conditions."),
    ],
},
{
    "family_id": "v4.ipc.clinical-waste-procedure", "version_id": "v1",
    "front_matter": None,
    "sections": [
        ("Purpose and scope", "This procedure sets out how staff handle clinical waste at the point it is produced during a care task. It applies to every member of care staff, and complements the site's wider Waste Management Policy."),
        ("Policy statement", "Clinical waste is segregated into the correct stream at the moment it is produced, protecting staff, residents and visitors from an infection risk that incorrect handling could otherwise create."),
        ("Definitions", "**Clinical waste** waste contaminated with bodily fluid or a used medical item, such as a dressing or continence product. **Sharp** a used needle or other sharp item. **Point-of-care segregation** placing waste into the correct stream immediately at the location it is produced, rather than sorting it later."),
        ("Roles and responsibilities", "**Care staff** segregate clinical waste at the point of care, into the correct colour-coded bag. **Housekeeping** moves segregated bags to the designated external storage area covered by the wider Waste Management Policy. **The registered manager** spot-checks segregation practice as part of routine infection control monitoring."),
        ("__numbered__", [
            "Place clinical waste directly into the orange or yellow clinical waste bag at the point it is produced, never into a general waste bin.",
            "Dispose of a used sharp immediately into an approved sharps bin at the point of use; a sharp is never carried to a bin elsewhere.",
            "Seal a clinical waste bag once it is two-thirds full, rather than compressing it further to fit more in.",
            "Report a split or leaking bag immediately so it can be double-bagged and the area cleaned, following the wider Waste Management Policy's spill-handling step.",
        ]),
        ("Exceptions and professional judgement", "Where a task produces an unusually large amount of clinical waste at once (for example, a wound dressing change), staff use additional bags as needed rather than overfilling a single bag to avoid asking for more."),
        ("Interaction with other Alderbridge policies", "This procedure works alongside the Waste Management Policy (governing storage, collection and contractor arrangements once waste leaves the point of care) and the Infection Prevention and Control Policy (the wider standard this procedure supports)."),
        ("Worked example", "A worked example illustrates point-of-care segregation. During a dressing change, the used dressing goes directly into the orange bag kept in the treatment room, and the tape and packaging that touched no bodily fluid goes into general waste instead, illustrating that segregation depends on what an item actually is, not simply everything from the same task being treated identically."),
        ("Frequently asked questions", "**Are continence products always clinical waste?** Yes, given their contamination risk, they are treated as clinical waste under this procedure. **Can clinical waste bags be stored in a resident's room between changes?** No, a filled bag is moved to the designated point promptly rather than left in a resident's room."),
        ("Training and competency", "All care staff complete point-of-care waste segregation training at induction, refreshed annually alongside infection prevention and control training."),
        ("Record keeping and retention", "Segregation spot-check outcomes are retained per the Records Retention Schedule."),
        ("Closing note", "Correct segregation at the point of care is the first and most important step in safe clinical waste handling, and this procedure exists to make that first step second nature for every member of staff."),
    ],
},
{
    "family_id": "v4.contractors.visiting-arrangements-policy", "version_id": "v1",
    "front_matter": None,
    "sections": [
        ("Purpose and scope", "This policy sets out how family and friends visit a resident at Alderbridge Care Group. It applies to every site and every visitor other than a contractor, who is covered separately by the Contractor Management Policy."),
        ("Policy statement", "Open, flexible visiting is supported as a resident's normal right, restricted only where a specific, documented safeguarding or infection control reason genuinely requires it, never as a blanket default."),
        ("Definitions", "**Open visiting** the standard approach of welcoming a visitor at a time that suits the resident and visitor, without a fixed visiting-hours restriction. **Restricted visiting** a documented, resident-specific limitation applied only for a genuine safeguarding or infection control reason. **Sign-in** the reception record every visitor completes on arrival."),
        ("Roles and responsibilities", "**Reception or the shift lead** greets a visitor, ensures they sign in, and directs them appropriately. **The registered manager** decides and documents any restricted visiting arrangement for a specific resident. **Care staff** raise a concern about a visitor's conduct promptly rather than managing it informally themselves."),
        ("__numbered__", [
            "Welcome a visitor at a time that suits the resident, without requiring advance notice for a routine visit.",
            "Ensure every visitor signs in at reception, supporting an accurate record of who is on site.",
            "Apply a restricted visiting arrangement only where the registered manager has documented a specific safeguarding or infection control reason for that resident.",
            "Support a resident to decline a visit from anyone they do not wish to see, including a family member, without requiring them to justify this wish.",
        ]),
        ("Exceptions and professional judgement", "Where a visitor's conduct raises an immediate concern, such as appearing intoxicated or behaving aggressively, staff may ask them to leave that day pending a documented review, without this constituting a standing restricted visiting arrangement unless the registered manager subsequently decides one is needed."),
        ("Interaction with other Alderbridge policies", "This policy works alongside the Adult Safeguarding Policy (governing a concern about a specific visitor) and the Pet Visiting Policy (governing a visitor bringing a pet)."),
        ("Worked example", "A worked example illustrates the default-to-open standard. A family member wishes to visit outside what might traditionally be considered normal visiting hours to fit around their own work schedule. This is accommodated without question, since no fixed visiting-hours restriction applies under this policy, and the visit proceeds as any other would."),
        ("Frequently asked questions", "**Can a resident's family request that a specific person never be allowed to visit?** This is discussed with the resident directly wherever they have capacity to express their own wish, since the decision belongs to the resident, not automatically to their family. **Are children allowed to visit?** Yes, a child visitor is welcomed in the same way as any other, with staff sensitivity to a resident's specific circumstances where relevant."),
        ("Training and competency", "Reception and shift-lead staff receive guidance on the sign-in process and on recognising when a visitor conduct concern should be escalated."),
        ("Record keeping and retention", "Sign-in records and any documented restricted visiting arrangement are retained per the Records Retention Schedule."),
        ("Closing note", "A resident's relationships with the people who matter to them are part of their wellbeing, not a risk to be managed by default, and this policy exists to keep visiting genuinely open except where a specific, documented reason says otherwise."),
    ],
},
]
