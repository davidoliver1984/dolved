"""Provider-free validation for V4-A. No network calls, no OpenAI/Voyage use."""
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

FORBIDDEN_STRINGS = [
    "OPENAI_API_KEY", "VOYAGE_API_KEY", "sk-proj-", "AKIA",
    "@nhs.net",  # placeholder heuristic for accidental real-looking identifiers
]

EVAL_QUESTION_MARKERS = ["expected_answer", "relevance_judgement", "relevance_label", "gold_answer"]


def fail(msgs, m):
    msgs.append(f"FAIL: {m}")


def main():
    problems = []
    warnings = []

    # Freeze hygiene is root-wide, not limited to rendered/master directories.
    for path in ROOT.rglob("*"):
        if path.is_symlink():
            fail(problems, f"symbolic link is not permitted in the corpus tree: {path.relative_to(ROOT)}")
        if (
            path.name == ".DS_Store"
            or path.name.startswith("._")
            or path.suffix == ".pyc"
            or "__pycache__" in path.parts
        ):
            fail(problems, f"transient artefact is not permitted: {path.relative_to(ROOT)}")

    manifest = json.loads((ROOT / "source-manifest.json").read_text())
    docs = manifest["documents"]

    # 1. exact count
    expected_count = int(sys.argv[1]) if len(sys.argv) > 1 else 300
    if len(docs) != expected_count:
        fail(problems, f"expected {expected_count} documents, found {len(docs)}")

    # 2. unique (family_id, version_id) / filenames / checksums
    fam_ver_ids = [d["family_id"] + "::" + d["version_id"] for d in docs]
    if len(set(fam_ver_ids)) != len(fam_ver_ids):
        fail(problems, "duplicate (family_id, version_id) pair in manifest")
    fnames = [d["filename"] for d in docs]
    if len(set(fnames)) != len(fnames):
        fail(problems, "duplicate filename in manifest")
    checksums = [d["sha256"] for d in docs]
    dup_checksums = {c for c in checksums if checksums.count(c) > 1}
    if dup_checksums:
        fail(problems, f"duplicate sha256 (unintended byte-identical files): {dup_checksums}")

    # 3. manifest-to-file completeness + checksum correctness + format conformance
    allowed_media = {
        "txt": "text/plain",
        "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "pdf": "application/pdf",
    }
    for d in docs:
        artefact_path = ROOT / d["artefact_path"]
        master_path = ROOT / d["semantic_master_path"]
        if not artefact_path.exists():
            fail(problems, f"missing artefact file: {artefact_path}")
            continue
        if not master_path.exists():
            fail(problems, f"missing semantic master: {master_path}")
        actual_sha = hashlib.sha256(artefact_path.read_bytes()).hexdigest()
        if actual_sha != d["sha256"]:
            fail(problems, f"checksum mismatch for {artefact_path}")
        if d["media_type"] != allowed_media.get(d["format"]):
            fail(problems, f"media type mismatch for {artefact_path}")
        # format conformance: accepted extension per apps/api/config/documents.php
        if d["format"] not in ("txt", "docx", "pdf"):
            fail(problems, f"format {d['format']} not in the accepted primary-corpus set")

    # 4. no unexpected password protection or corruption in the successful set
    try:
        import pdfplumber
        for d in docs:
            if d["format"] != "pdf":
                continue
            p = ROOT / d["artefact_path"]
            try:
                with pdfplumber.open(p) as pdf:
                    text = "\n".join((pg.extract_text() or "") for pg in pdf.pages)
                    if len(text.strip()) < 10:
                        fail(problems, f"PDF extracted almost no text (possible image-only/corrupt): {p}")
            except Exception as e:  # noqa: BLE001
                fail(problems, f"PDF failed to open/extract with pdfplumber: {p} ({e})")
    except ImportError:
        warnings.append("pdfplumber not installed — PDF extractability not verified")

    try:
        import docx as docx_lib
        for d in docs:
            if d["format"] != "docx":
                continue
            p = ROOT / d["artefact_path"]
            try:
                doc = docx_lib.Document(str(p))
                text = "\n".join(par.text for par in doc.paragraphs)
                if len(text.strip()) < 5:
                    fail(problems, f"DOCX extracted almost no text: {p}")
            except Exception as e:  # noqa: BLE001
                fail(problems, f"DOCX failed to open with python-docx: {p} ({e})")
    except ImportError:
        warnings.append("python-docx not installed — DOCX extractability not verified")

    for d in docs:
        if d["format"] != "txt":
            continue
        p = ROOT / d["artefact_path"]
        try:
            content = p.read_text(encoding="utf-8")
            if len(content.strip()) < 5:
                fail(problems, f"TXT file nearly empty: {p}")
        except UnicodeDecodeError:
            fail(problems, f"TXT file not valid UTF-8: {p}")

    # 5. no real personal data / provider credentials (heuristic scan across masters)
    for md_file in (ROOT / "semantic-masters").rglob("*.md"):
        text = md_file.read_text(encoding="utf-8")
        for bad in FORBIDDEN_STRINGS:
            if bad in text:
                fail(problems, f"forbidden string '{bad}' found in {md_file}")

    # 6. no evaluation questions / expected answers / relevance labels anywhere in this tree
    for json_file in ROOT.rglob("*.json"):
        text = json_file.read_text(encoding="utf-8")
        for marker in EVAL_QUESTION_MARKERS:
            if marker in text:
                fail(problems, f"possible evaluation-question artefact marker '{marker}' in {json_file}")

    # 7. governance/effective-date consistency (draft/withdrawn should not have both effective_date
    #    unset and be marked expected_ingestible without a superseded/withdrawn note where relevant)
    for d in docs:
        if d["governance_status"] == "withdrawn" and not d.get("superseded_date"):
            warnings.append(f"withdrawn doc without superseded_date: {d['family_id']}")

    # 8. applicability location references resolve against organisation.json
    org = json.loads((ROOT / "organisation.json").read_text())
    valid_location_ids = {loc["location_id"] for loc in org["locations"]}
    for d in docs:
        for loc in d.get("applicability_locations", []):
            if loc not in valid_location_ids:
                fail(problems, f"unknown location_id '{loc}' referenced by {d['family_id']}")

    # 9. version-family lineage: no overlapping "approved" authority intervals within a family,
    #    and a v1->v2 supersession date should line up (v1.superseded_date == v2.effective_date)
    #    unless v2 is an explicitly scheduled, not-yet-effective successor.
    from collections import defaultdict
    by_family = defaultdict(list)
    for d in docs:
        by_family[d["family_id"]].append(d)

    for fam_id, versions in by_family.items():
        approved = [v for v in versions if v["governance_status"] == "approved" and v.get("effective_date")]
        approved_sorted = sorted(approved, key=lambda v: v["effective_date"])
        for i in range(len(approved_sorted) - 1):
            a, b = approved_sorted[i], approved_sorted[i + 1]
            a_end = a.get("superseded_date")
            b_is_scheduled = "scheduled" in b["version_id"]
            if a_end is None and not b_is_scheduled:
                fail(problems, f"family {fam_id}: version {a['version_id']} is approved with a later "
                                f"approved, already-effective sibling {b['version_id']} but has no "
                                f"superseded_date (would overlap authority intervals)")
            elif a_end is None and b_is_scheduled:
                pass  # correct: v1 remains currently authoritative; the scheduled successor is not yet effective
            elif a_end > b["effective_date"]:
                fail(problems, f"family {fam_id}: version {a['version_id']} superseded_date "
                                f"{a_end} is after sibling {b['version_id']}'s effective_date "
                                f"{b['effective_date']} (overlapping authority)")
            elif a_end != b["effective_date"] and "scheduled" not in b["version_id"]:
                warnings.append(f"family {fam_id}: gap between {a['version_id']} superseded_date "
                                 f"{a_end} and {b['version_id']} effective_date {b['effective_date']}")

    # 10. governed artefact/semantic-master directories contain no undeclared files
    #     (e.g. a stray .DS_Store or other hidden Finder metadata file). Scope is the
    #     rendered-artefact and semantic-master trees for the primary corpus and any
    #     present auxiliary pack (foreign-tenant, prompt-injection-pack) — every file
    #     in these directories must be traceable to a manifest-declared path.
    declared_paths = {(ROOT / d["artefact_path"]).resolve() for d in docs}
    declared_paths |= {(ROOT / d["semantic_master_path"]).resolve() for d in docs}
    governed_dirs = [ROOT / "artifacts", ROOT / "semantic-masters"]

    for pack_dir_name in ("foreign-tenant", "prompt-injection-pack"):
        pack_manifest_path = ROOT / pack_dir_name / "source-manifest.json"
        if not pack_manifest_path.exists():
            continue
        pack_docs = json.loads(pack_manifest_path.read_text())["documents"]
        declared_paths |= {(ROOT / d["artefact_path"]).resolve() for d in pack_docs}
        # these packs' manifests don't carry a semantic_master_path field; the build
        # scripts always write one .md per doc at <pack>/semantic-masters/<family_id>/<version_id>.md
        declared_paths |= {
            (ROOT / pack_dir_name / "semantic-masters" / d["family_id"] / f"{d['version_id']}.md").resolve()
            for d in pack_docs
        }
        governed_dirs.append(ROOT / pack_dir_name / "artifacts")
        governed_dirs.append(ROOT / pack_dir_name / "semantic-masters")

    for gdir in governed_dirs:
        if not gdir.exists():
            continue
        for f in gdir.rglob("*"):
            if f.is_file() and f.resolve() not in declared_paths:
                fail(problems, f"undeclared file in governed directory: {f.relative_to(ROOT)}")

    # Report
    print(f"Documents checked: {len(docs)}")
    print(f"Problems: {len(problems)}")
    for p in problems:
        print(" ", p)
    print(f"Warnings: {len(warnings)}")
    for w in warnings:
        print(" ", w)

    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
