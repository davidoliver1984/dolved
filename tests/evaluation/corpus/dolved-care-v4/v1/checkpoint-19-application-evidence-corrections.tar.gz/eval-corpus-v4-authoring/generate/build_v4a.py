"""Build V4-A: render all 100 documents to semantic masters + upload artefacts,
then write document-family-plan.json and source-manifest.json."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import render  # noqa: E402

import batch1_hr_core as b1
import batch2_health_safety as b2
import batch3_ipc_medication_safeguarding as b3
import batch4_fire_incidents_complaints as b4
import batch5_infogov_it_bcp as b5
import batch6_procurement_facilities_payroll as b6
import batch7_drafts_minutes_misc as b7

ROOT = render.ROOT

ALL_DOCS = b1.DOCS + b2.DOCS + b3.DOCS + b4.DOCS + b5.DOCS + b6.DOCS + b7.DOCS

assert len(ALL_DOCS) == 100, f"expected 100 docs, got {len(ALL_DOCS)}"
ids = [d["family_id"] for d in ALL_DOCS]
assert len(set(ids)) == len(ids), "duplicate family_id"
fns = [d["filename"] for d in ALL_DOCS]
assert len(set(fns)) == len(fns), "duplicate filename"

manifest_entries = []
for doc in ALL_DOCS:
    entry = render.build_one(doc, tranche="V4-A")
    manifest_entries.append(entry)
    print(f"built {doc['family_id']} -> {entry['artefact_path']}")

source_manifest = {
    "schema_version": "v4-draft",
    "corpus_id": "dolved-care-alderbridge-v4",
    "status": "AUTHORING_DRAFT",
    "tranche": "V4-A",
    "document_count": len(manifest_entries),
    "documents": manifest_entries,
}
(ROOT / "source-manifest.json").write_text(
    json.dumps(source_manifest, indent=2), encoding="utf-8"
)

family_plan = {
    "schema_version": "v4-draft",
    "corpus_id": "dolved-care-alderbridge-v4",
    "status": "AUTHORING_DRAFT",
    "target": {
        "total_families": 185, "total_versions": 300,
        "single_version_families": 100, "two_version_families": 60,
        "three_version_families": 20, "four_version_families": 5,
    },
    "tranches": {
        "V4-A": {"target_versions": 100, "status": "built_this_session"},
        "V4-B": {"target_versions": 225, "status": "not_started"},
        "V4-C": {"target_versions": 300, "status": "not_started"},
    },
    "families": [
        {
            "family_id": d["family_id"],
            "family_title": d["family_title"],
            "domain": d["domain"],
            "planned_version_count": 1,
            "tranche_assignment": {"v1": "V4-A"},
            "versions_built_this_session": ["v1"],
        }
        for d in ALL_DOCS
    ],
}
(ROOT / "document-family-plan.json").write_text(
    json.dumps(family_plan, indent=2), encoding="utf-8"
)

print(f"\nDone. {len(manifest_entries)} documents built.")
