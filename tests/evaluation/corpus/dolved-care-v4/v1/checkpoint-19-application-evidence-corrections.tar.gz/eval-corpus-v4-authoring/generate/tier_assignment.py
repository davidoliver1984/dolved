"""Deterministic length-tier assignment for the 225 existing V4-A+V4-B documents.

Selection principle (per David's correction): genuinely short operational
artefacts (forms, notices, checklists, minutes/memos, schedules, drafts,
and quick-reference FAQ pages) may remain short. Policies, procedures, and
substantive guidance/handbook material must be re-authored to realistic
length. Both versions of a two-version family are kept in the same tier so
the intended version-to-version difference stays legible against a
comparable backdrop, not diluted by one sibling being much longer.
"""

# faq_guidance families that are substantive guidance/handbook material,
# not a one-page quick-reference — these are EXPANDED, not kept short.
FAQ_EXPAND_FAMILIES = {
    "v4.hr.recruitment-safer-recruitment-guidance",
    "v4.hr.staff-wellbeing-guidance",
    "v4.safeguarding.mental-capacity-guidance",
    "v4.it.phishing-awareness-guidance",
    "v4.it.remote-working-security-guidance",
    "v4.payroll.pension-scheme-guidance",
    "v4b.complaints.compliments-escalation-guidance",
    "v4b.hr.staff-benefits-guidance",
    "v4b.training.safeguarding-champion-role-guidance",
}

VERY_LONG_FAMILIES = {
    # Final set of 15 CONFIRMED at 9+ real chunks (tiktoken o200k_base,
    # target_tokens=400) as of the second very-long checkpoint. Verified
    # directly against the rendered files, not estimated.
    "v4.medication.safe-administration-policy",
    "v4.medication.controlled-drugs-procedure",
    "v4.infogov.data-protection-policy",
    "v4.hs.health-safety-policy-statement",
    "v4.fire.fire-safety-policy",
    "v4.hr.equality-dignity-policy",
    "v4.complaints.complaints-policy",
    "v4.hr.sickness-absence-policy",
    "v4.hs.manual-handling-policy",
    "v4.hs.coshh-procedure",
    "v4.hs.lone-working-policy",
    "v4.ipc.outbreak-management-procedure",
    "v4.infogov.sar-handling-procedure",
    "v4.infogov.data-breach-procedure",
    "v4.hr.recruitment-safer-recruitment-guidance",
}

# Reclassified as "long": deepened in the first very-long attempt but
# capped at 4-8 real chunks, not padded further to force a 9+ result,
# per David's explicit instruction to accept their genuine depth.
LONG_RECLASSIFIED_FROM_VERY_LONG = {
    "v4.safeguarding.adult-safeguarding-policy",
    "v4.hr.disciplinary-procedure",
    "v4.hr.grievance-procedure",
    "v4.safeguarding.whistleblowing-policy",
    "v4.bcp.business-continuity-plan-summary",
}

# Formerly "not yet expanded" (~80-120 words): corrected 2026-09-01
# (expand_long_1.py, applied before the 164207 checkpoint). Verified
# against the live manifest at 4 real chunks each. Kept as a separate
# named set for provenance/history; now merged into LONG_SINGLE_FAMILIES.
POLICY_NOT_YET_EXPANDED = set()

_BATCH1_CORRECTED_POLICIES = {
    "v4.it.acceptable-use-policy",
    "v4.hs.risk-assessment-procedure",
    "v4c.hr.recruitment-and-selection-policy",
}

LONG_SINGLE_FAMILIES = LONG_RECLASSIFIED_FROM_VERY_LONG | _BATCH1_CORRECTED_POLICIES | {
    "v4.hr.annual-leave-policy",
    "v4.hr.flexible-working-policy",
    "v4.hr.family-leave-policy",
    "v4.incident.incident-reporting-policy",
    "v4.hr.probation-policy",
    "v4.hr.employee-handbook-conduct-section",
    "v4.hr.dress-code-uniform-policy",
    "v4.infogov.cctv-policy",
    "v4.safeguarding.mental-capacity-guidance",
    "v4.hr.staff-wellbeing-guidance",
    "v4.it.phishing-awareness-guidance",
    "v4.it.remote-working-security-guidance",
}

LONG_TWO_VERSION_FAMILIES = {
    "v4b.hr.agency-staff-usage-policy",
    "v4b.medication.medication-ordering-stock-policy",
    "v4b.safeguarding.allegations-against-staff-procedure",
    "v4b.it.mobile-device-management-policy",
    "v4b.complaints.cqc-notification-procedure",
    "v4b.facilities.waste-management-policy",
    "v4b.medication.self-administration-of-medication-policy",
    "v4b.hr.resident-finances-appointeeship-policy",
    "v4b.care.admissions-preadmission-assessment-policy",
    "v4b.care.falls-prevention-policy",
    "v4b.care.end-of-life-care-policy",
    "v4b.hr.staff-supervision-appraisal-policy",
}


def classify(family_id: str, content_type: str) -> str:
    """Return 'short', 'medium', 'long', or 'very_long' for a given family."""
    if family_id in VERY_LONG_FAMILIES:
        return "very_long"
    if family_id in LONG_SINGLE_FAMILIES or family_id in LONG_TWO_VERSION_FAMILIES:
        return "long"
    if content_type == "policy":
        return "medium"
    if content_type == "faq_guidance":
        return "medium" if family_id in FAQ_EXPAND_FAMILIES else "short"
    # form, minutes_memo, schedule_reference, draft_distractor, onboarding_training
    return "short"


TIER_WORD_TARGETS = {
    "short": (100, 350),
    "medium": (500, 1200),
    "long": (1500, 3500),
    "very_long": (4000, 8000),
}
