"""Reproducibility proof: reconstruct every governed document from its
current semantic-master .md file and re-render it into a fresh output
directory, independently, twice. Compare the resulting per-artefact
sha256 set between the two fresh renders and against the live checked-in
artefacts. Byte-identical across all three confirms the runtime-contract's
byte-reproducibility claim for the current corrected corpus state.

Provider-free, local-only, writes only under the given temp output dirs.
"""
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import render  # noqa: E402
import finalize_freeze_candidate as ffc  # noqa: E402

ROOT = render.ROOT


def load_all_entries():
    entries = []
    for manifest_rel, brand in (
        ("source-manifest.json", "Alderbridge Care Group"),
        ("foreign-tenant/source-manifest.json", "Thornfield Support Services"),
        ("prompt-injection-pack/source-manifest.json", "Dolved Synthetic Security Fixture"),
    ):
        manifest = json.loads((ROOT / manifest_rel).read_text())
        for entry in manifest["documents"]:
            entries.append((entry, brand))
    return entries


def render_pass(out_dir: Path) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    results = {}
    for entry, brand in load_all_entries():
        master_rel = entry.get("semantic_master_path")
        if master_rel:
            master_path = ROOT / master_rel
        else:
            pack_root = ROOT / entry["artefact_path"].split("/artifacts/")[0]
            master_path = pack_root / "semantic-masters" / entry["family_id"] / f"{entry['version_id']}.md"
        doc = ffc.master_to_doc(entry, master_path, brand)
        md = master_path.read_text(encoding="utf-8")
        fmt = entry["format"]
        if fmt == "pdf":
            data = render.render_pdf(doc)
        elif fmt == "docx":
            data = render.render_docx(doc)
        else:
            data = render.render_txt(doc, md)
        digest = hashlib.sha256(data).hexdigest()
        results[entry["artefact_path"]] = digest
        # Physically write it too, so this is a genuine independent render
        # pass producing real files, not just an in-memory hash.
        out_path = out_dir / entry["artefact_path"]
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_bytes(data)
    return results


def aggregate(results: dict) -> str:
    pairs = sorted(results.items())
    concat = "\n".join(f"{p}  {h}" for p, h in pairs)
    return hashlib.sha256(concat.encode("utf-8")).hexdigest()


def main():
    out1 = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("/tmp/v4_render_pass_1")
    out2 = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("/tmp/v4_render_pass_2")

    live_entries = {e["artefact_path"]: e["sha256"] for e, _ in load_all_entries()}

    print("Rendering independent pass 1...")
    pass1 = render_pass(out1)
    print("Rendering independent pass 2...")
    pass2 = render_pass(out2)

    agg_live = aggregate(live_entries)
    agg1 = aggregate(pass1)
    agg2 = aggregate(pass2)

    print(f"\nLive checked-in aggregate:  {agg_live}")
    print(f"Fresh render pass 1 aggregate: {agg1}")
    print(f"Fresh render pass 2 aggregate: {agg2}")

    all_match = agg_live == agg1 == agg2
    print(f"\nAll three aggregates identical: {all_match}")

    if not all_match:
        mismatches = []
        for path in sorted(live_entries):
            l, a, b = live_entries[path], pass1.get(path), pass2.get(path)
            if not (l == a == b):
                mismatches.append((path, l, a, b))
        print(f"Mismatched artefacts: {len(mismatches)}")
        for m in mismatches[:20]:
            print(" ", m)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
