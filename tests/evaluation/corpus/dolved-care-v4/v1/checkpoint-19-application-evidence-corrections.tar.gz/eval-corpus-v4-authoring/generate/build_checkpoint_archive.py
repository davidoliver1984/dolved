"""Deterministic checkpoint archive builder.

The sole normative implementation for producing a Dolved V4 corpus
checkpoint archive. Deliberately does NOT invoke the system `tar` binary,
because macOS bsdtar silently writes an AppleDouble ('._*') sidecar member
for every file that carries an extended attribute (quarantine flag, Finder
tag, ACL, resource fork) and a second, near-duplicate top-level directory
entry for the archive root itself. That defect is invisible to `tar -tzvf`
(bsdtar's own listing quietly reconciles it) and to any post-extraction
filesystem check (extraction silently merges the AppleDouble sidecar back
into its companion file) — it is visible ONLY by reading the raw archive
member stream directly (as `generate/validate_archive_raw.py` does).

This builder writes tar members directly via Python's `tarfile` module,
which never generates AppleDouble sidecars, and controls every byte that
could otherwise vary run to run:

- exactly one top-level directory member is implied by every entry's name
  prefix (no separate directory TarInfo entries are written at all, so
  there is nothing for a second root entry to duplicate);
- member order is the sorted POSIX-relative-path order of the governed file
  list, always identical for identical input;
- every TarInfo's mtime, mode, uid, gid, uname and gname are fixed
  constants, not read from the filesystem;
- the gzip wrapper is given mtime=0 and no embedded original filename, so
  the compressed bytes carry no wall-clock-time or hostname dependency;
- tar format is pinned to GNU_FORMAT (handles the corpus's longest real
  path — 93 chars plus the ~26-char root prefix — without needing PAX
  extended headers, which would themselves embed additional timestamp
  fields).

Governed file selection excludes `.corpus-venv` and any transient artefact
(`.DS_Store`, `._*`, `__pycache__`, `*.pyc`); it rejects a symlink, a device
file, or a path containing `..` outright rather than silently skipping it,
since any of those would itself be a defect worth stopping for.
"""
from __future__ import annotations

import gzip
import io
import sys
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE_ROOT_NAME = "eval-corpus-v4-authoring"

FIXED_MTIME = 0
FIXED_MODE_FILE = 0o644
FIXED_UID = 0
FIXED_GID = 0
FIXED_UNAME = ""
FIXED_GNAME = ""

EXCLUDED_DIR_NAMES = {".corpus-venv", "__pycache__"}
EXCLUDED_FILE_SUFFIXES = {".pyc"}
EXCLUDED_FILE_NAMES = {".DS_Store"}


def governed_files() -> list[Path]:
    files: list[Path] = []
    for path in ROOT.rglob("*"):
        if any(part in EXCLUDED_DIR_NAMES for part in path.parts):
            continue
        if path.is_symlink():
            raise ValueError(f"refusing to archive a symlink: {path}")
        if not path.is_file():
            continue
        if path.name in EXCLUDED_FILE_NAMES or path.name.startswith("._"):
            raise ValueError(f"refusing to archive a transient/AppleDouble-shaped file: {path}")
        if path.suffix in EXCLUDED_FILE_SUFFIXES:
            raise ValueError(f"refusing to archive a compiled artefact: {path}")
        rel = path.relative_to(ROOT).as_posix()
        if ".." in rel.split("/"):
            raise ValueError(f"refusing to archive a traversal path: {path}")
        files.append(path)
    files.sort(key=lambda p: p.relative_to(ROOT).as_posix())
    seen = set()
    for p in files:
        rel = p.relative_to(ROOT).as_posix()
        if rel in seen:
            raise ValueError(f"duplicate governed member: {rel}")
        seen.add(rel)
    return files


def build(output_path: Path) -> list[str]:
    files = governed_files()
    member_names: list[str] = []

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "wb") as raw_out:
        gz = gzip.GzipFile(filename="", mode="wb", fileobj=raw_out, mtime=FIXED_MTIME, compresslevel=9)
        with tarfile.open(fileobj=gz, mode="w|", format=tarfile.GNU_FORMAT) as tar:
            for path in files:
                rel = path.relative_to(ROOT).as_posix()
                arcname = f"{ARCHIVE_ROOT_NAME}/{rel}"
                data = path.read_bytes()
                info = tarfile.TarInfo(name=arcname)
                info.size = len(data)
                info.mtime = FIXED_MTIME
                info.mode = FIXED_MODE_FILE
                info.type = tarfile.REGTYPE
                info.uid = FIXED_UID
                info.gid = FIXED_GID
                info.uname = FIXED_UNAME
                info.gname = FIXED_GNAME
                tar.addfile(info, io.BytesIO(data))
                member_names.append(arcname)
        gz.close()
    return member_names


def main() -> int:
    output_path = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT.parent / "checkpoint-out.tar.gz"
    members = build(output_path)
    print(f"Wrote {len(members)} regular-file members to {output_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
