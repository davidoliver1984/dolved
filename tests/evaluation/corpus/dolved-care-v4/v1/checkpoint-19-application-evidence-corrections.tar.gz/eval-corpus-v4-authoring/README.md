# Dolved Evaluation Corpus V4 — Corrected Freeze Candidate

**Status: authoring candidate. Not frozen, accepted, calibrated or approved.**

This is fictional benchmark-source material for a later independently authored
evaluation. It contains no evaluation questions, expected answers, relevance
judgements, scoring thresholds or provider outputs.

## Candidate identity

- Internal checkpoint identity: `checkpoint-19-application-evidence-corrections`
  (supersedes `checkpoint-18-archive-and-fidelity-corrections`; checkpoints
  1-18 remain archived unchanged as historical evidence).
- The archive SHA-256 is recorded externally after archive creation because an
  archive cannot truthfully contain its own hash.
- `checksums/checksums.sha256` covers every ordinary archived file except
  itself; the external archive SHA covers the checksum inventory too.
- The archive itself is built by `generate/build_checkpoint_archive.py`, a
  pinned, versioned Python implementation — **not** the system `tar` command.
  Checkpoint 17's archive was found, on raw tar-member inspection (not
  post-extraction filesystem checks), to contain 969 macOS AppleDouble
  (`._*`) sidecar members, a duplicate top-level root directory entry, and
  1715 raw regular-file members instead of 746 — a defect invisible to
  `tar -tzvf`'s own listing and to extraction-based diffing. This checkpoint's
  archive is verified directly against its raw member stream by
  `generate/validate_archive_raw.py`, not only by extracting it.

## Reproducibility contract

`authoring-governance/runtime-contract.json` declares two separate, explicitly
named runtime profiles, because they do not share a dependency set:

- **`corpus_local_profile`** — rendering, local extraction, tokenizer-based
  chunk estimation, corpus validation, and deterministic checkpoint archive
  creation. Fully reconstructible offline from a fully pinned dependency lock
  (`authoring-governance/requirements.lock`). **Byte-reproducible output is
  claimed only under that exact locked runtime and dependency set** run
  against the same source document definitions — this corpus is not
  self-contained and does not vendor its dependencies; the pinned packages
  must be installed first. True PyPI-canonical package hashes were not
  produced (would require a network call); a locally-observed dist-info
  integrity fingerprint is provided instead in
  `authoring-governance/local-dist-info-fingerprints.json`, explicitly
  labelled as not equivalent to a PyPI wheel hash.
- **`application_pipeline_profile`** — the real Dolved application chunking
  pipeline (pydantic-based extraction/normalisation/`BaselineStructuralChunker`)
  that produced the measured chunk profile below. Its dependency stack
  (`pydantic`, `pydantic-core`, and a genuine Python 3.14 language-level
  feature the application source relies on) is explicitly **not** covered by
  `corpus_local_profile`'s lock. This checkpoint **successfully reproduced it**
  inside the precisely identified, already-locally-cached
  `rag-platform-ai:development` image (image ID
  `sha256:c5ab90de8d23e73d5b6cf78b4987189947957513c5531be8d8db5895e2509202`),
  run with `--network none` and the corpus bind-mounted read-only — see that
  profile's `reproduction_run`, `cached_image_identity` and
  `measured_output_evidence_identity` for the full command, image identity
  and result. A prior session's two failed offline reconstruction attempts
  (Python 3.13's missing PEP 649 support; the main repository's own
  pre-release Python 3.14.0rc2's pydantic incompatibility) are retained,
  clearly labelled historical, in `historical_reconstruction_attempts_prior_session`.
  The cached image is not vendored in this archive and must already be
  present in the verifier's own local Docker cache to re-run this
  reproduction; no cross-platform byte reproduction is claimed.

`generate/validate_freeze.py` enforces both profiles' presence and required
sections, that the archive builder is named (not the system `tar` binary),
dependency-lock agreement with the live environment,
`renderer_tool`/`renderer_version` coverage on every governed manifest entry,
independent reconstruction of the application-source aggregate from its own
recorded per-file hashes, and basic documentation/data agreement.

## Final inventory

- 300 primary versions across 185 families.
- Family distribution: 100 one-version,
  60 two-version, 20
  three-version and 5 four-version families.
- Primary formats: 94 PDF, 103 DOCX and
  103 TXT.
- V4-C is complete with 75 versions: 30 PDF,
  25 DOCX and 20 TXT.
- 12 physically separate Thornfield foreign-tenant documents.
- 9 prompt-injection documents: 3 inside the primary corpus and
  6 in the separate neutral synthetic-security pack.
- 13 negative/import fixtures, including deliberately corrupt,
  encrypted and unsupported inputs.

## Measured chunk distribution

The real repository extraction/normalisation/chunking pipeline measured:

- one chunk: 91
- exactly two chunks: 42
- exactly three chunks: 61
- four to eight chunks: 76
- nine or more chunks: 30

The complete exact distribution and tokenizer fingerprint are in
`chunk-profile.json`. This measured distribution replaces earlier author
estimates and is not a quota claim.

**Corrected this checkpoint**: this supersedes the prior 91/42/62/75/30
distribution (historical). `v4b.care.continence-care-policy::v2` moved from 3
to 4 chunks, and `v4b.hr.staff-supervision-appraisal-policy::v2` moved from 4
to 5 chunks — each a direct, expected consequence of restoring real,
load-bearing content a prior expansion or reordering pass had dropped.
`v4b.facilities.energy-utilities-policy` and `v4b.care.end-of-life-care-policy`
were also corrected this checkpoint and independently confirmed NOT to shift
tier. The measured `below_preferred_minimum` warning count is now 20
(historical prior figure: 22).

**Provenance**: this distribution was **independently reproduced this
session**, not carried forward and not copied from a supplied expected value.
It was measured by directly running the real extraction ->
structural-normalisation -> `BaselineStructuralChunker` sequence inside the
precisely identified, already-locally-cached `rag-platform-ai:development`
Docker image (image ID
`sha256:c5ab90de8d23e73d5b6cf78b4987189947957513c5531be8d8db5895e2509202`,
stable Python 3.14.6), with `--network none` and the corpus bind-mounted
read-only, at 2026-09-02T11:56:28Z, against application source at main-
repository commit `f27ff1b1d49b6eb7c555ffce3e278e22ad2eb6a4`. See
`authoring-governance/runtime-contract.json`'s `application_pipeline_profile`
for the exact command, the full per-document result, and the historical
record of a prior session's two failed offline reconstruction attempts
(superseded, not currently applicable — the cached image's stable Python
3.14.6 does not exhibit either failure).

## Reproducibility and tenant boundary

`generate/finalize_freeze_candidate.py` is the corpus-content build step;
`generate/build_checkpoint_archive.py` is the sole normative checkpoint
archive builder (see Candidate identity above — the system `tar` command is
retired from this claim). PDFs use ReportLab invariant output and stable
metadata; DOCX packages use fixed metadata, member ordering and ZIP
timestamps. Primary artefacts carry the Alderbridge identity, foreign
artefacts the Thornfield identity, and the separate injection pack a neutral
synthetic-security identity.

## Version-change-type governance

`authoring-governance/version-change-type-registry.json` is the closed,
versioned vocabulary for the `version_change_type` manifest field: a bounded
set of canonical values, each with a stated meaning, a machine-verifiable vs.
broader-semantic classification, and required invariants. It replaces
~89 previously free-text values (55 of them single-use, family-specific
labels carrying no information beyond what a per-comparison contract already
records) with 17 reusable canonical values plus null.
`authoring-governance/version-diff-contracts.json` records, for every one of
the 115 adjacent version comparisons in the primary corpus, the specific
declared allowed-changed-section set and a content digest per protected
section. `generate/validate_version_fidelity.py` checks every comparison's
*actual* current diff against its contract — rejecting an unknown type, a
missing contract, or any changed section outside the declared set — replacing
the previous "any non-identical pair passes" behaviour. Both governance files
are corpus-authoring evidence, not evaluation material, and are not inputs to
evaluation-question authoring.

This correction also fixed a genuine content defect found by re-audit:
`v4b.medication.fridge-breakdown-procedure` had a top-line instruction to
"move stock to the backup cool box immediately" that contradicted its own
detailed containment section ("keep the door closed... stock is not moved on
assumption"). Both versions now open with a single coherent sequence: keep
closed, do not move on assumption, escalate, then use a validated alternative
only once authorised. Three other families
(`continence-care-policy`, `dbs-renewal-procedure`,
`right-to-work-checks-procedure`) had an unrelated section silently dropped
from v2 during an earlier expansion pass; both sections were restored
verbatim in each, alongside the family's own intended tightened-requirement
change. The two other families sharing the same bounded canonical
"...with_consequential_rewrite" vocabulary
(`ladder-stepladder-use-guidance`, `induction-buddy-scheme-guidance`) were
re-checked against the same failure pattern and found already coherent, with
no unrelated removal.

## Formatting-only boundary

`v4b.hr.staff-handover-procedure` has identical normalized extracted text in
both versions but different deterministic DOCX presentation bytes. The current
accepted structured-extraction contract does not promise semantic detection of
presentation-only changes. It therefore remains an honest unavailable or
non-provable comparison case unless a future reviewed ADR extends extraction
and defines a re-extraction strategy.

## Safety

Everything is fictional. Prompt-injection strings are inert document content.
Negative fixtures are bounded test inputs, not malware. Do not ingest this
candidate outside the approved evaluation workflow, and do not author cases
from it until the exact archive has passed independent freeze review.
