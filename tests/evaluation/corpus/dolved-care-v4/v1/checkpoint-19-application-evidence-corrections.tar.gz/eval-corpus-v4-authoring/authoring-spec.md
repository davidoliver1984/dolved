# Authoring Spec — Dolved Evaluation Corpus V4 (DRAFT)

Frozen decisions for this authoring effort. Anything not written down here
is not yet decided and must not be assumed by a later authoring session.

## 1. Identity and universe

- Organisation: **Alderbridge Care Group** (reused unchanged from
  `dolved-care-engineering/v3/organisation.json`). No second fictional
  organisation is created for the primary tenant.
- All V4 identifiers are namespaced `v4.*` and are **structurally distinct**
  from every V3 identifier (`v3.*`) and from every V3 file path — this
  corpus does not add files into, or reuse IDs from,
  `tests/evaluation/benchmarks/dolved-care-engineering/v3/`.
- Locations reused as-is from V3: North West / Midlands / South West
  regions; Riverside House, Moorland View, Oakfield Lodge, Willow Bank,
  Harbour View, Meadow Court; Central Support Office. Aliases and
  terminology reused unchanged. Two new terminology entries were added
  (see `organisation.json`) for domains V3 did not cover (IT/cyber,
  business continuity) — additive only, nothing renamed or removed.

## 2. Governance vocabulary (reused from the accepted model, not reinvented)

- Version governance status: `draft` | `approved` | `withdrawn`
  (`App\Enums\DocumentGovernanceStatus`).
- Applicability scope: `universal` | `specific`
  (`App\Enums\DocumentApplicabilityScope`). `specific` versions carry an
  explicit location list; parent-location applicability is inherited
  according to the accepted location-hierarchy model — a version scoped to
  a region applies to every site under that region, never the reverse.
- No teams. No department/category/tag field is ever treated as affecting
  retrieval eligibility in this corpus — categories and tags exist purely
  as library-organisation metadata, exactly as the accepted model requires.
- No overlapping authority intervals are authored for two `approved`
  versions of the same family at the same location.
- Every deliberately invalid state (e.g. two files claiming to be the same
  version, an unsupported extension) lives only in `negative-fixtures/`,
  never mixed into the primary 300.

## 3. Upload formats and size limits (verified against the current
   accepted implementation, not assumed)

- Accepted upload extensions/media types (`apps/api/config/documents.php`):
  `pdf`, `docx`, `doc`, `rtf`, `txt`, `md`.
- Actually extractable today (`apps/ai/app/extraction/`): `pdf`
  (pdfplumber/pdfminer), `docx` (python-docx), plain text (`txt`/`md`, via
  `PlainTextExtractor`). No OCR extractor exists — an image-only PDF is
  never treated as searchable in this corpus.
- `doc` and `rtf` are accepted by upload validation but have no confirmed
  extractor in `apps/ai/app/extraction/` — **not used for the primary 300**;
  reserved as candidate negative/edge material only if a future session
  confirms their actual current behaviour.
- Max upload size: `DOCUMENT_MAX_UPLOAD_MB` (default 25 MB,
  `apps/api/config/documents.php`). The primary 300 all sit far below this;
  the "oversized" condition is represented as a **bounded fixture** that
  declares a size over the limit without actually allocating a 25MB+ binary
  (see `negative-fixtures/`).
- **Primary-corpus format mix**: plain text (`.txt`), DOCX (`.docx`), and
  PDF (`.pdf`, both simple text-based and more complex layouts) — exactly
  the three formats named in the task brief, all independently confirmed
  extractable.

## 4. Deterministic rendering pipeline

- One **semantic master** per version, authored as Markdown, is the single
  source of truth for that version's content
  (`semantic-masters/<family_id>/<version_id>.md`).
- Upload artefacts are generated deterministically from the semantic master
  by a local, isolated Python toolchain (`.corpus-venv/`, installed
  `python-docx` + `reportlab`), **never by hand-editing a binary**. The final
  reproducibility step is `generate/finalize_freeze_candidate.py`:
  - `.txt`: the master's plain-text rendering (Markdown syntax stripped).
  - `.docx`: built with `python-docx`, fixed core metadata, sorted package
    members and fixed ZIP timestamps.
  - `.pdf`: built with ReportLab invariant output, stable metadata and
    document identifiers, using either a simple flowing layout (clean/
    mildly-messy documents) or a denser, multi-section layout with tables
    and headers/footers (moderately/severely messy documents).
- Renderer versions and the exact generation script are recorded per
  artefact in `source-manifest.json` (`renderer_tool`, `renderer_version`).
  No deterministic random seed is needed — the rendering is a fixed
  deterministic function of the master content and explicit synthetic tenant
  identity, not sampled.
- `checksums/checksums.sha256` covers every governed ordinary file except
  itself. Its self-reference exclusion is deliberate and documented; the
  external archive SHA-256 covers the archive including that inventory.

## 5. Messiness axes actually used (external labels, never shown to the
   product)

Each authored document is labelled in `source-manifest.json` with a
messiness **level** (`clean`, `mild`, `moderate`, `severe`,
`extreme-supported`) and one or more messiness **axes** from:

`heading_inconsistency`, `mixed_numbering`, `nested_bullets`,
`dense_table`, `info_in_table_cell`, `header_footer_boilerplate`,
`footnote_appendix`, `vague_filename`, `filename_title_mismatch`,
`inconsistent_dates`, `abbreviation_heavy`, `late_defined_term`,
`buried_exception`, `cross_reference`, `near_duplicate_boilerplate`,
`similar_title_different_family`, `wording_change_only`,
`numeric_change_between_versions`, `local_vs_regional_variance`,
`minutes_precede_policy`, `obsolete_form_retained`,
`prompt_injection_text`.

Target distribution across the 300 primary documents (see
`document-family-plan.json` for the per-document assignment):
20% clean, 30% mild, 30% moderate, 15% severe, 5% extreme-supported.

## 6. Content-type proportions

35% formal policy/procedure, 15% forms/checklists, 10% minutes/memos/
notices, 10% FAQ/guidance/quick-reference, 10% onboarding/training, 10%
schedules/directories/appendices, 10% drafts/incomplete/distractor/
non-authoritative. Tracked per document in `document-family-plan.json`
(`content_type` field).

## 7. Family/version scale (exact target)

185 families → 300 versions: 100 single-version, 60 two-version, 20
three-version, 5 four-version (100·1 + 60·2 + 20·3 + 5·4 = 300). Split into
three independently reviewable tranches:

- **V4-A**: first 100 successfully ingestible versions.
- **V4-B**: historical cumulative milestone at 225 versions.
- **V4-C**: completed expansion to exactly 300 versions.

Excludes negative-fixture pack and foreign-tenant pack from the 300 count.

## 8. Evaluation-contamination boundary (self-certification)

This authoring session did **not** read, list, or open any of: held-out
cases, held-out questions/answers, calibration questions, relevance
judgements, threshold-tuning material, evaluator observations, provider
outputs, live-run answers, or any reserved evaluation population. Paths
under `tests/evaluation/{engineering-populations,calibration-populations}`
and `docs/evaluation/runs/` were not opened during this task. No evaluation
question, expected answer, relevance label, or threshold was authored here.

## 9. ACAS/external-source boundary

See `source-provenance.json` for the full record. Rule of thumb applied:
official ACAS pages were used only to confirm real-world topic structure
(what a disciplinary procedure or flexible-working policy typically
covers); all resulting document text is original fictional prose, not a
copy or close paraphrase of ACAS wording. No ACAS logo or endorsement claim
appears anywhere. Every resulting document explicitly states, in its own
front-matter, that it is fictional test material and not employment or
legal advice.
